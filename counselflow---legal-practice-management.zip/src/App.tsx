import React, { useState } from 'react';
import { PracticeProvider, usePractice } from './context/PracticeContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { DashboardView } from './components/dashboard/DashboardView';
import { MattersView } from './components/matters/MattersView';
import { TimeBillingView } from './components/billing/TimeBillingView';
import { InvoicesView } from './components/billing/InvoicesView';
import { TrustAccountingView } from './components/trust/TrustAccountingView';
import { DocumentAutomationView } from './components/documents/DocumentAutomationView';
import { ConflictCheckModal } from './components/conflicts/ConflictCheckModal';
import { LiveTimerWidget } from './components/timer/LiveTimerWidget';
import { CommandPalette } from './components/search/CommandPalette';
import { NewMatterModal } from './components/matters/NewMatterModal';
import { NewTimeModal } from './components/billing/NewTimeModal';

const AppContent: React.FC = () => {
  const { activeView } = usePractice();

  // Modals state
  const [isNewTimeModalOpen, setIsNewTimeModalOpen] = useState(false);
  const [isNewMatterModalOpen, setIsNewMatterModalOpen] = useState(false);
  const [isTimerDrawerOpen, setIsTimerDrawerOpen] = useState(false);

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-100 text-slate-900 overflow-hidden">
      {/* Strict Top Bar Contract */}
      <Header
        onOpenNewTimeModal={() => setIsNewTimeModalOpen(true)}
        onOpenTimerDrawer={() => setIsTimerDrawerOpen(true)}
      />

      {/* Main Workspace Body with Sidebar & Viewport */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar Navigation */}
        <Sidebar
          onOpenNewTimeModal={() => setIsNewTimeModalOpen(true)}
          onOpenNewMatterModal={() => setIsNewMatterModalOpen(true)}
        />

        {/* Dynamic Main Viewport */}
        <main className="flex-1 overflow-y-auto p-6 md:p-8 bg-slate-50">
          <div className="max-w-7xl mx-auto">
            {activeView === 'dashboard' && (
              <DashboardView
                onOpenNewTimeModal={() => setIsNewTimeModalOpen(true)}
                onOpenNewMatterModal={() => setIsNewMatterModalOpen(true)}
                onOpenTimerDrawer={() => setIsTimerDrawerOpen(true)}
              />
            )}

            {activeView === 'matters' && (
              <MattersView
                onOpenNewMatterModal={() => setIsNewMatterModalOpen(true)}
                onOpenNewTimeModal={() => setIsNewTimeModalOpen(true)}
              />
            )}

            {activeView === 'billing' && (
              <TimeBillingView
                onOpenNewTimeModal={() => setIsNewTimeModalOpen(true)}
              />
            )}

            {activeView === 'invoices' && (
              <InvoicesView />
            )}

            {activeView === 'trust' && (
              <TrustAccountingView />
            )}

            {activeView === 'documents' && (
              <DocumentAutomationView />
            )}

            {activeView === 'conflicts' && (
              <ConflictCheckModal />
            )}
          </div>
        </main>
      </div>

      {/* Live Timer Drawer Widget */}
      <LiveTimerWidget
        isOpen={isTimerDrawerOpen}
        onClose={() => setIsTimerDrawerOpen(false)}
      />

      {/* Global Command Palette (⌘K) */}
      <CommandPalette
        onOpenNewMatter={() => setIsNewMatterModalOpen(true)}
        onOpenNewTime={() => setIsNewTimeModalOpen(true)}
      />

      {/* New Matter Intake Modal with Conflict Screening */}
      <NewMatterModal
        isOpen={isNewMatterModalOpen}
        onClose={() => setIsNewMatterModalOpen(false)}
      />

      {/* New Time Entry Modal (UTBMS) */}
      <NewTimeModal
        isOpen={isNewTimeModalOpen}
        onClose={() => setIsNewTimeModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <PracticeProvider>
      <AppContent />
    </PracticeProvider>
  );
}
