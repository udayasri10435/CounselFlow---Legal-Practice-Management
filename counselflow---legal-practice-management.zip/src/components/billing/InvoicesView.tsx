import React, { useState } from 'react';
import { usePractice } from '../../context/PracticeContext';
import { formatCurrency, formatDate, generateLedes1998B } from '../../utils/formatters';
import { Invoice } from '../../types';
import { 
  Receipt, 
  Download, 
  Printer, 
  Scale, 
  CreditCard, 
  CheckCircle2, 
  AlertCircle, 
  Plus, 
  Eye, 
  Copy, 
  FileText 
} from 'lucide-react';

export const InvoicesView: React.FC = () => {
  const { 
    invoices, 
    matters, 
    payInvoiceFromTrust, 
    recordManualPayment,
    timeEntries,
    createInvoice
  } = usePractice();

  const [statusFilter, setStatusFilter] = useState<'All' | 'Sent' | 'Overdue' | 'Paid'>('All');
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(invoices[0] || null);
  const [isLedesModalOpen, setIsLedesModalOpen] = useState(false);
  const [isNewInvoiceModalOpen, setIsNewInvoiceModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // New Invoice Form state
  const [selectedMatterForNewInv, setSelectedMatterForNewInv] = useState(matters[0]?.id || '');
  const [invDueDate, setInvDueDate] = useState(new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0]);
  const [selectedTimeEntryIds, setSelectedTimeEntryIds] = useState<string[]>([]);

  // Payment Form state
  const [payAmount, setPayAmount] = useState('');
  const [payMethod, setPayMethod] = useState<'Trust' | 'Wire' | 'Check'>('Trust');
  const [payRef, setPayRef] = useState('');

  const filteredInvoices = statusFilter === 'All'
    ? invoices
    : invoices.filter(inv => inv.status === statusFilter);

  // Matter for currently selected invoice
  const currentInvoiceMatter = selectedInvoice 
    ? matters.find(m => m.id === selectedInvoice.matterId) 
    : null;

  // Unbilled time entries for matter when creating new invoice
  const availableUnbilledEntries = timeEntries.filter(
    te => te.matterId === selectedMatterForNewInv && te.status === 'Unbilled'
  );

  const handlePayFromTrust = () => {
    if (!selectedInvoice) return;
    const amountToPay = selectedInvoice.balanceDue;
    const res = payInvoiceFromTrust(selectedInvoice.id, amountToPay);
    if (res.success) {
      setNotification({ type: 'success', message: res.message });
      // Update local view
      const updatedInv = invoices.find(i => i.id === selectedInvoice.id);
      if (updatedInv) setSelectedInvoice(updatedInv);
    } else {
      setNotification({ type: 'error', message: res.message });
    }
  };

  const handleManualPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInvoice) return;
    const amt = parseFloat(payAmount);
    if (isNaN(amt) || amt <= 0) {
      setNotification({ type: 'error', message: 'Enter a valid payment amount.' });
      return;
    }

    if (payMethod === 'Trust') {
      const res = payInvoiceFromTrust(selectedInvoice.id, amt);
      if (res.success) {
        setNotification({ type: 'success', message: res.message });
        setIsPaymentModalOpen(false);
      } else {
        setNotification({ type: 'error', message: res.message });
      }
    } else {
      recordManualPayment(
        selectedInvoice.id,
        amt,
        payMethod === 'Wire' ? 'Wire Transfer' : 'Client Check',
        payRef || `REF-${Date.now()}`
      );
      setNotification({ type: 'success', message: `Recorded ${payMethod} payment of ${formatCurrency(amt)}.` });
      setIsPaymentModalOpen(false);
    }
  };

  const handleCreateNewInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedTimeEntryIds.length === 0) {
      setNotification({ type: 'error', message: 'Select at least one unbilled time entry to generate an invoice.' });
      return;
    }

    const newInv = createInvoice({
      matterId: selectedMatterForNewInv,
      lineItemIds: selectedTimeEntryIds,
      dueDate: invDueDate,
      notes: 'Standard legal billing statement. Net 30 days.'
    });

    setSelectedInvoice(newInv);
    setIsNewInvoiceModalOpen(false);
    setSelectedTimeEntryIds([]);
    setNotification({ type: 'success', message: `Invoice ${newInv.invoiceNumber} created successfully.` });
  };

  const ledesContent = selectedInvoice ? generateLedes1998B(selectedInvoice) : '';

  const handleCopyLedes = () => {
    navigator.clipboard.writeText(ledesContent);
    setNotification({ type: 'success', message: 'LEDES 1998B format copied to clipboard.' });
  };

  const handleDownloadLedes = () => {
    if (!selectedInvoice) return;
    const blob = new Blob([ledesContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedInvoice.invoiceNumber}_LEDES1998B.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Receipt className="w-5 h-5 text-slate-800" />
            <span>Billing, Invoices & LEDES 1998B</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Generate itemized fee statements, draw from client IOLTA trust escrow, and export standard corporate LEDES files.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => {
              setSelectedMatterForNewInv(matters[0]?.id || '');
              setIsNewInvoiceModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Generate Invoice</span>
          </button>
        </div>
      </div>

      {/* Notification Toast */}
      {notification && (
        <div className={`p-3.5 rounded-lg flex items-center justify-between text-xs font-medium ${
          notification.type === 'success' 
            ? 'bg-emerald-50 text-emerald-900 border border-emerald-200' 
            : 'bg-rose-50 text-rose-900 border border-rose-200'
        }`}>
          <div className="flex items-center gap-2">
            {notification.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{notification.message}</span>
          </div>
          <button 
            onClick={() => setNotification(null)}
            className="text-slate-400 hover:text-slate-600 ml-4 font-bold"
          >
            ✕
          </button>
        </div>
      )}

      {/* Filter Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg w-fit text-xs font-medium">
        {(['All', 'Sent', 'Overdue', 'Paid'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setStatusFilter(tab)}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              statusFilter === tab
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tab} Invoices
          </button>
        ))}
      </div>

      {/* Main Split Grid: Invoices List on Left, Interactive Preview on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Side: Invoices Directory (5 cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
            <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-700 flex justify-between items-center">
              <span>Statements ({filteredInvoices.length})</span>
              <span className="text-[11px] text-slate-500 font-normal">Click to review & bill</span>
            </div>

            <div className="divide-y divide-slate-100 max-h-[700px] overflow-y-auto">
              {filteredInvoices.map((inv) => {
                const isSelected = selectedInvoice?.id === inv.id;
                return (
                  <button
                    key={inv.id}
                    onClick={() => setSelectedInvoice(inv)}
                    className={`w-full text-left p-4 transition-colors ${
                      isSelected 
                        ? 'bg-amber-50/60 border-l-4 border-amber-500' 
                        : 'hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="font-mono-nums font-bold text-xs text-slate-900">
                          {inv.invoiceNumber}
                        </span>
                        <div className="text-xs font-semibold text-slate-800 mt-0.5">
                          {inv.clientName}
                        </div>
                        <div className="text-[11px] text-slate-500 truncate max-w-[220px]">
                          {inv.matterTitle}
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="text-xs font-bold font-mono-nums text-slate-900">
                          {formatCurrency(inv.total)}
                        </div>
                        <span className={`inline-block mt-1 text-[10px] font-semibold px-2 py-0.5 rounded ${
                          inv.status === 'Paid'
                            ? 'bg-emerald-100 text-emerald-800'
                            : inv.status === 'Overdue'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-blue-100 text-blue-800'
                        }`}>
                          {inv.status}
                        </span>
                      </div>
                    </div>

                    <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                      <span>Due: {formatDate(inv.dueDate)}</span>
                      {inv.balanceDue > 0 ? (
                        <span className="text-rose-600 font-medium font-mono-nums">
                          Bal Due: {formatCurrency(inv.balanceDue)}
                        </span>
                      ) : (
                        <span className="text-emerald-600 font-medium">Settled in Full</span>
                      )}
                    </div>
                  </button>
                );
              })}

              {filteredInvoices.length === 0 && (
                <div className="p-8 text-center text-xs text-slate-500">
                  No invoices found matching "{statusFilter}".
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Side: Selected Invoice Detailed Letterhead & Actions (7 cols) */}
        <div className="lg:col-span-7">
          {selectedInvoice ? (
            <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
              {/* Action Toolbar */}
              <div className="p-4 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-3 no-print">
                <div className="flex items-center gap-2">
                  <span className="font-mono-nums font-bold text-sm">
                    {selectedInvoice.invoiceNumber}
                  </span>
                  <span className="text-xs text-slate-400">·</span>
                  <span className={`text-[11px] font-semibold px-2 py-0.5 rounded ${
                    selectedInvoice.status === 'Paid'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      : 'bg-amber-950 text-amber-300 border border-amber-800'
                  }`}>
                    {selectedInvoice.status}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  {/* Pay from Trust Action */}
                  {selectedInvoice.balanceDue > 0 && currentInvoiceMatter && currentInvoiceMatter.trustBalance > 0 && (
                    <button
                      onClick={handlePayFromTrust}
                      className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-md transition-colors"
                      title="Draw directly from available client trust escrow to satisfy statement balance"
                    >
                      <Scale className="w-3.5 h-3.5" />
                      <span>Pay from Trust (${formatCurrency(Math.min(selectedInvoice.balanceDue, currentInvoiceMatter.trustBalance))})</span>
                    </button>
                  )}

                  {/* Manual Payment */}
                  {selectedInvoice.balanceDue > 0 && (
                    <button
                      onClick={() => {
                        setPayAmount(String(selectedInvoice.balanceDue));
                        setIsPaymentModalOpen(true);
                      }}
                      className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-md transition-colors"
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                      <span>Record Payment</span>
                    </button>
                  )}

                  {/* LEDES 1998B Export */}
                  <button
                    onClick={() => setIsLedesModalOpen(true)}
                    className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-md transition-colors"
                    title="Export standard LEDES 1998B electronic file"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>LEDES 1998B</span>
                  </button>

                  {/* Print */}
                  <button
                    onClick={() => window.print()}
                    className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-md transition-colors"
                    title="Print Formal Fee Statement"
                  >
                    <Printer className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Printable Legal Fee Statement Letterhead */}
              <div className="p-8 space-y-6">
                {/* Firm Letterhead Header */}
                <div className="flex justify-between items-start border-b border-slate-200 pb-6">
                  <div>
                    <div className="text-xl font-bold tracking-tight text-slate-900 font-legal-serif">
                      CounselFlow Legal Partners LLP
                    </div>
                    <div className="text-xs text-slate-500 mt-1 leading-relaxed">
                      Attorneys & Counselors at Law<br />
                      555 California Street, 38th Floor<br />
                      San Francisco, CA 94104 · (415) 555-0199
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-lg font-bold text-slate-900 font-mono-nums">
                      FEE STATEMENT
                    </div>
                    <div className="text-xs text-slate-500 mt-1 space-y-0.5">
                      <div>Statement #: <strong className="text-slate-800 font-mono-nums">{selectedInvoice.invoiceNumber}</strong></div>
                      <div>Date: <strong className="text-slate-800">{formatDate(selectedInvoice.issueDate)}</strong></div>
                      <div>Due Date: <strong className="text-slate-800">{formatDate(selectedInvoice.dueDate)}</strong></div>
                    </div>
                  </div>
                </div>

                {/* Client & Matter Block */}
                <div className="grid grid-cols-2 gap-6 bg-slate-50 p-4 rounded-lg border border-slate-200/60 text-xs">
                  <div>
                    <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                      Billed To
                    </span>
                    <div className="font-bold text-slate-900">{selectedInvoice.clientName}</div>
                    <div className="text-slate-600 mt-0.5">{selectedInvoice.clientAddress}</div>
                    <div className="text-slate-500 mt-0.5">{selectedInvoice.clientEmail}</div>
                  </div>

                  <div>
                    <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                      Matter Reference
                    </span>
                    <div className="font-bold text-slate-900">{selectedInvoice.matterTitle}</div>
                    <div className="text-slate-600 font-mono-nums mt-0.5">Matter #: {selectedInvoice.matterNumber}</div>
                    {currentInvoiceMatter && (
                      <div className="mt-1 pt-1 border-t border-slate-200/60 text-slate-700">
                        Client IOLTA Trust Balance: <strong className="font-mono-nums text-slate-900">{formatCurrency(currentInvoiceMatter.trustBalance)}</strong>
                      </div>
                    )}
                  </div>
                </div>

                {/* Line Items Table */}
                <div>
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
                    Professional Services Rendered (UTBMS Standard)
                  </h3>
                  <table className="w-full text-left text-xs border border-slate-200 rounded-lg overflow-hidden">
                    <thead>
                      <tr className="bg-slate-100/70 border-b border-slate-200 text-slate-600 font-semibold">
                        <th className="py-2.5 px-3">Date</th>
                        <th className="py-2.5 px-3">UTBMS</th>
                        <th className="py-2.5 px-3">Description</th>
                        <th className="py-2.5 px-3 text-right">Hours</th>
                        <th className="py-2.5 px-3 text-right">Rate</th>
                        <th className="py-2.5 px-3 text-right">Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {selectedInvoice.lineItems.map((li) => (
                        <tr key={li.id}>
                          <td className="py-2.5 px-3 font-mono-nums text-slate-500 whitespace-nowrap">
                            {formatDate(li.date)}
                          </td>
                          <td className="py-2.5 px-3 font-mono-nums font-semibold text-slate-700">
                            {li.utbmsCode || 'L110'}
                          </td>
                          <td className="py-2.5 px-3 text-slate-800">
                            {li.description}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono-nums">
                            {li.hours.toFixed(1)}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono-nums text-slate-600">
                            ${li.rate}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono-nums font-semibold text-slate-900">
                            {formatCurrency(li.amount)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Expenses if any */}
                {selectedInvoice.expenses.length > 0 && (
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
                      Disbursements & Court Costs
                    </h3>
                    <table className="w-full text-left text-xs border border-slate-200 rounded-lg overflow-hidden">
                      <tbody className="divide-y divide-slate-100">
                        {selectedInvoice.expenses.map((exp) => (
                          <tr key={exp.id}>
                            <td className="py-2 px-3 text-slate-500 font-mono-nums">{formatDate(exp.date)}</td>
                            <td className="py-2 px-3 font-medium text-slate-800">{exp.description}</td>
                            <td className="py-2 px-3 text-slate-500">{exp.category}</td>
                            <td className="py-2 px-3 text-right font-mono-nums font-semibold text-slate-900">
                              {formatCurrency(exp.amount)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {/* Calculation Totals */}
                <div className="flex justify-end pt-2">
                  <div className="w-72 space-y-2 text-xs">
                    <div className="flex justify-between text-slate-600">
                      <span>Services Subtotal:</span>
                      <span className="font-mono-nums">{formatCurrency(selectedInvoice.subtotal)}</span>
                    </div>

                    {selectedInvoice.discountAmount > 0 && (
                      <div className="flex justify-between text-emerald-700">
                        <span>Courtesy Adjustment:</span>
                        <span className="font-mono-nums">-{formatCurrency(selectedInvoice.discountAmount)}</span>
                      </div>
                    )}

                    <div className="flex justify-between text-slate-900 font-bold pt-2 border-t border-slate-200">
                      <span>Total Current Charges:</span>
                      <span className="font-mono-nums">{formatCurrency(selectedInvoice.total)}</span>
                    </div>

                    {selectedInvoice.amountPaid > 0 && (
                      <div className="flex justify-between text-slate-600">
                        <span>Payments & Trust Applied:</span>
                        <span className="font-mono-nums text-emerald-700">-{formatCurrency(selectedInvoice.amountPaid)}</span>
                      </div>
                    )}

                    <div className="flex justify-between text-slate-900 font-bold text-sm pt-2 border-t-2 border-slate-900">
                      <span>Total Balance Due:</span>
                      <span className="font-mono-nums">{formatCurrency(selectedInvoice.balanceDue)}</span>
                    </div>
                  </div>
                </div>

                {/* Payment History Audit */}
                {selectedInvoice.payments.length > 0 && (
                  <div className="mt-4 p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs">
                    <span className="font-semibold text-slate-700 block mb-1">Receipts & Trust Transfers Applied:</span>
                    <div className="space-y-1">
                      {selectedInvoice.payments.map((p) => (
                        <div key={p.id} className="flex justify-between text-slate-600">
                          <span>{formatDate(p.date)} · {p.method} (Ref: {p.reference})</span>
                          <span className="font-mono-nums font-semibold text-slate-900">{formatCurrency(p.amount)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white border border-slate-200 rounded-xl p-12 text-center text-slate-500 text-xs">
              Select an invoice from the directory to review statement details.
            </div>
          )}
        </div>
      </div>

      {/* LEDES 1998B Modal */}
      {isLedesModalOpen && selectedInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="w-full max-w-2xl bg-white rounded-xl shadow-2xl p-6 border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  LEDES 1998B Electronic Data Interchange
                </h3>
                <p className="text-xs text-slate-500">
                  Pipe-delimited standard format for corporate legal departments (Tymetrix, Serengeti, CounselLink).
                </p>
              </div>
              <span className="font-mono text-xs bg-slate-100 px-2 py-1 rounded text-slate-700 font-semibold">
                {selectedInvoice.invoiceNumber}
              </span>
            </div>

            <div className="mt-4">
              <pre className="p-3.5 bg-slate-900 text-amber-300 font-mono text-[11px] rounded-lg overflow-x-auto max-h-64 whitespace-pre leading-relaxed">
                {ledesContent}
              </pre>
            </div>

            <div className="mt-5 pt-3 border-t border-slate-200 flex items-center justify-between">
              <span className="text-[11px] text-slate-500">
                Format: LEDES 1998B Standard Pipe-Delimited
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyLedes}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Raw</span>
                </button>
                <button
                  type="button"
                  onClick={handleDownloadLedes}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .txt</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsLedesModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-700"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Record Payment Modal */}
      {isPaymentModalOpen && selectedInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white rounded-xl shadow-2xl p-6 border border-slate-200">
            <h3 className="text-base font-bold text-slate-900 mb-1">
              Record Payment on {selectedInvoice.invoiceNumber}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Balance due: <strong>{formatCurrency(selectedInvoice.balanceDue)}</strong>
            </p>

            <form onSubmit={handleManualPayment} className="space-y-4 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Payment Method
                </label>
                <select
                  value={payMethod}
                  onChange={(e) => setPayMethod(e.target.value as any)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
                >
                  <option value="Trust">IOLTA Trust Transfer (Earned Fee Drawdown)</option>
                  <option value="Wire">Direct Wire Transfer</option>
                  <option value="Check">Client Check</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Payment Amount ($ USD)
                </label>
                <input
                  type="number"
                  step="0.01"
                  max={selectedInvoice.balanceDue}
                  value={payAmount}
                  onChange={(e) => setPayAmount(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono-nums"
                  required
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Reference / Check / Transfer ID
                </label>
                <input
                  type="text"
                  value={payRef}
                  onChange={(e) => setPayRef(e.target.value)}
                  placeholder="e.g. CHK-1092 or WIRE-48201"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsPaymentModalOpen(false)}
                  className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg"
                >
                  Apply Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Generate Invoice from Unbilled WIP Modal */}
      {isNewInvoiceModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="w-full max-w-xl bg-white rounded-xl shadow-2xl p-6 border border-slate-200 max-h-[85vh] overflow-y-auto">
            <h3 className="text-base font-bold text-slate-900 mb-1">
              Generate New Invoice from Unbilled Time
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Select client matter and unbilled time entries to compile a formal fee statement.
            </p>

            <form onSubmit={handleCreateNewInvoice} className="space-y-4 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Select Matter *
                </label>
                <select
                  value={selectedMatterForNewInv}
                  onChange={(e) => {
                    setSelectedMatterForNewInv(e.target.value);
                    setSelectedTimeEntryIds([]);
                  }}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
                >
                  {matters.map(m => (
                    <option key={m.id} value={m.id}>
                      {m.matterNumber} - {m.clientName} ({m.title})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Payment Due Date *
                </label>
                <input
                  type="date"
                  value={invDueDate}
                  onChange={(e) => setInvDueDate(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
                  required
                />
              </div>

              {/* Unbilled Time Entries Checklist */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="font-medium text-slate-700">
                    Unbilled Time Entries ({availableUnbilledEntries.length} available)
                  </label>
                  {availableUnbilledEntries.length > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        if (selectedTimeEntryIds.length === availableUnbilledEntries.length) {
                          setSelectedTimeEntryIds([]);
                        } else {
                          setSelectedTimeEntryIds(availableUnbilledEntries.map(e => e.id));
                        }
                      }}
                      className="text-[11px] text-blue-600 hover:underline font-medium"
                    >
                      {selectedTimeEntryIds.length === availableUnbilledEntries.length ? 'Deselect All' : 'Select All'}
                    </button>
                  )}
                </div>

                <div className="border border-slate-200 rounded-lg max-h-52 overflow-y-auto divide-y divide-slate-100">
                  {availableUnbilledEntries.map((te) => {
                    const isChecked = selectedTimeEntryIds.includes(te.id);
                    return (
                      <label
                        key={te.id}
                        className={`flex items-start gap-2.5 p-3 cursor-pointer hover:bg-slate-50 transition-colors ${
                          isChecked ? 'bg-amber-50/50' : ''
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedTimeEntryIds(prev => [...prev, te.id]);
                            } else {
                              setSelectedTimeEntryIds(prev => prev.filter(id => id !== te.id));
                            }
                          }}
                          className="mt-0.5 rounded border-slate-300 text-slate-900 focus:ring-slate-900"
                        />
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <span className="font-semibold text-slate-800">{te.utbmsCode}</span>
                            <span className="font-mono-nums font-bold text-slate-900">
                              {formatCurrency(te.durationHours * te.rate)} ({te.durationHours}h)
                            </span>
                          </div>
                          <p className="text-slate-600 text-[11px] mt-0.5">{te.description}</p>
                          <div className="text-[10px] text-slate-400 mt-1">
                            {formatDate(te.date)} · {te.attorneyName}
                          </div>
                        </div>
                      </label>
                    );
                  })}

                  {availableUnbilledEntries.length === 0 && (
                    <div className="p-6 text-center text-slate-400 text-xs">
                      No unbilled time entries currently logged for this matter. Log time entries first or select another matter.
                    </div>
                  )}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsNewInvoiceModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={selectedTimeEntryIds.length === 0}
                  className="px-4 py-2 font-semibold text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg"
                >
                  Generate Statement
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
