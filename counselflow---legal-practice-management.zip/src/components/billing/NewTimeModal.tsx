import React, { useState } from 'react';
import { usePractice } from '../../context/PracticeContext';
import { UTBMS_CODES } from '../../data/mockData';
import { Clock, X } from 'lucide-react';

interface NewTimeModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultMatterId?: string;
}

export const NewTimeModal: React.FC<NewTimeModalProps> = ({ isOpen, onClose, defaultMatterId }) => {
  const { matters, addTimeEntry } = usePractice();

  const initialMatterId = defaultMatterId || matters[0]?.id || '';
  const initialMatter = matters.find(m => m.id === initialMatterId) || matters[0];

  const [matterId, setMatterId] = useState(initialMatterId);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [hours, setHours] = useState('1.0');
  const [rate, setRate] = useState(String(initialMatter?.defaultRate || 650));
  const [attorneyName, setAttorneyName] = useState(initialMatter?.leadAttorney || 'Victoria Vance, Esq.');
  const [utbmsCode, setUtbmsCode] = useState('L110 - Fact Investigation / Development');
  const [description, setDescription] = useState('');
  const [billable, setBillable] = useState(true);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const currentMatter = matters.find(m => m.id === matterId) || matters[0];
    const durationNum = parseFloat(hours);
    const rateNum = parseFloat(rate);

    if (isNaN(durationNum) || durationNum <= 0) return;

    addTimeEntry({
      matterId: currentMatter.id,
      matterNumber: currentMatter.matterNumber,
      matterTitle: currentMatter.title,
      clientName: currentMatter.clientName,
      date,
      durationHours: durationNum,
      rate: rateNum || currentMatter.defaultRate,
      billable,
      utbmsCode,
      description: description.trim() || 'Professional legal consultation and analysis.',
      attorneyName
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
      <div className="w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
        <div className="flex items-center justify-between p-4 bg-slate-900 text-white">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400" />
            <h2 className="text-sm font-bold">Log Billable Time Entry (UTBMS)</h2>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-3.5 text-xs">
          <div>
            <label className="block font-medium text-slate-700 mb-1">Client Matter *</label>
            <select
              value={matterId}
              onChange={(e) => {
                const mId = e.target.value;
                setMatterId(mId);
                const m = matters.find(mat => mat.id === mId);
                if (m) {
                  setRate(String(m.defaultRate));
                  setAttorneyName(m.leadAttorney);
                }
              }}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
            >
              {matters.map(m => (
                <option key={m.id} value={m.id}>
                  {m.matterNumber}: {m.clientName} ({m.title})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Service Date *</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
                required
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Timekeeper / Attorney *</label>
              <input
                type="text"
                value={attorneyName}
                onChange={(e) => setAttorneyName(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Hours (0.1h Tenths) *</label>
              <input
                type="number"
                step="0.1"
                min="0.1"
                value={hours}
                onChange={(e) => setHours(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white font-mono-nums"
                required
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Hourly Rate ($) *</label>
              <input
                type="number"
                value={rate}
                onChange={(e) => setRate(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white font-mono-nums"
                required
              />
            </div>
          </div>

          <div>
            <label className="block font-medium text-slate-700 mb-1">UTBMS Task Code *</label>
            <select
              value={utbmsCode}
              onChange={(e) => setUtbmsCode(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
            >
              {UTBMS_CODES.map(c => (
                <option key={c.code} value={`${c.code} - ${c.description}`}>
                  {c.code} - {c.description} ({c.category})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-medium text-slate-700 mb-1">Activity Narrative / Work Performed *</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Detailed description of legal service performed..."
              rows={3}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white resize-none"
              required
            />
          </div>

          <div className="flex items-center justify-between pt-1">
            <label className="flex items-center gap-2 cursor-pointer text-slate-700">
              <input
                type="checkbox"
                checked={billable}
                onChange={(e) => setBillable(e.target.checked)}
                className="rounded border-slate-300 text-slate-900"
              />
              <span>Billable to Client</span>
            </label>

            <span className="font-mono-nums font-bold text-slate-900">
              Total: ${(parseFloat(hours || '0') * parseFloat(rate || '0')).toFixed(2)}
            </span>
          </div>

          <div className="pt-3 border-t border-slate-200 flex justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg"
            >
              Save Time Entry
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
