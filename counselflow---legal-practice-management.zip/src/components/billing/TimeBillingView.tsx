import React, { useState } from 'react';
import { usePractice } from '../../context/PracticeContext';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { UTBMS_CODES } from '../../data/mockData';
import { TimeEntry } from '../../types';
import { 
  Clock, 
  Plus, 
  Trash2, 
  TrendingUp, 
  Briefcase, 
  FileCheck, 
  CheckCircle2, 
  AlertCircle 
} from 'lucide-react';

interface TimeBillingViewProps {
  onOpenNewTimeModal: () => void;
}

export const TimeBillingView: React.FC<TimeBillingViewProps> = ({ onOpenNewTimeModal }) => {
  const { 
    timeEntries, 
    matters, 
    deleteTimeEntry, 
    totalUnbilledWIP, 
    setActiveView 
  } = usePractice();

  const [matterFilter, setMatterFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'Unbilled' | 'Invoiced'>('all');
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const filteredEntries = timeEntries.filter((te) => {
    if (matterFilter !== 'all' && te.matterId !== matterFilter) return false;
    if (statusFilter !== 'all' && te.status !== statusFilter) return false;
    return true;
  });

  const unbilledHours = timeEntries
    .filter(te => te.status === 'Unbilled')
    .reduce((sum, te) => sum + te.durationHours, 0);

  const handleDelete = (id: string) => {
    deleteTimeEntry(id);
    setNotification({ type: 'success', message: 'Time entry deleted.' });
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Clock className="w-5 h-5 text-amber-600" />
            <span>Time Tracking & Work In Progress (WIP)</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            UTBMS standard time ledger with 0.1h (6-minute) precision increments and billable realization metrics.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setActiveView('invoices')}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors shadow-xs"
          >
            <FileCheck className="w-3.5 h-3.5 text-blue-600" />
            <span>Go to Invoices</span>
          </button>
          <button
            onClick={onOpenNewTimeModal}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Log Time Entry</span>
          </button>
        </div>
      </div>

      {/* Notification Toast */}
      {notification && (
        <div className={`p-3.5 rounded-lg flex items-center justify-between text-xs font-medium ${
          notification.type === 'success' 
            ? 'bg-emerald-50 text-emerald-900 border border-emerald-200' 
            : 'bg-rose-50 text-rose-900 border border-rose-200'
        }`}>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{notification.message}</span>
          </div>
          <button onClick={() => setNotification(null)} className="text-slate-400 hover:text-slate-600 font-bold">
            ✕
          </button>
        </div>
      )}

      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Unbilled Work in Progress</div>
          <div className="text-2xl font-bold font-mono-nums text-slate-900 mt-1">
            {formatCurrency(totalUnbilledWIP)}
          </div>
          <div className="text-[11px] text-emerald-600 mt-1 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />
            <span>Ready for statement generation</span>
          </div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Unbilled Billable Hours</div>
          <div className="text-2xl font-bold font-mono-nums text-slate-900 mt-1">
            {unbilledHours.toFixed(1)} hrs
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Standard 6-minute increment basis
          </div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Average Billed Hourly Rate</div>
          <div className="text-2xl font-bold font-mono-nums text-slate-900 mt-1">
            $645/hr
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Blended partner & associate realization
          </div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs">
          <div className="text-xs text-slate-500 font-medium">UTBMS Task Compliance</div>
          <div className="text-2xl font-bold font-mono-nums text-slate-900 mt-1">
            100%
          </div>
          <div className="text-[11px] text-emerald-600 mt-1">
            Litigation & Corporate codes coded
          </div>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-3 border border-slate-200 rounded-xl shadow-xs">
        <div className="flex items-center gap-3 text-xs w-full sm:w-auto">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-medium">Matter:</span>
            <select
              value={matterFilter}
              onChange={(e) => setMatterFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded text-slate-800 text-xs focus:outline-none"
            >
              <option value="all">All Matters ({timeEntries.length})</option>
              {matters.map(m => (
                <option key={m.id} value={m.id}>
                  {m.matterNumber} - {m.clientName}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-medium">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded text-slate-800 text-xs focus:outline-none"
            >
              <option value="all">All Statuses</option>
              <option value="Unbilled">Unbilled Only</option>
              <option value="Invoiced">Invoiced Only</option>
            </select>
          </div>
        </div>

        <div className="text-xs text-slate-500 font-mono-nums">
          Showing {filteredEntries.length} time entries
        </div>
      </div>

      {/* Time Entries Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Matter / Client</th>
                <th className="py-3 px-4">Attorney</th>
                <th className="py-3 px-4">UTBMS Code</th>
                <th className="py-3 px-4">Activity Description</th>
                <th className="py-3 px-4 text-right">Hours</th>
                <th className="py-3 px-4 text-right">Rate</th>
                <th className="py-3 px-4 text-right">Total ($)</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredEntries.map((te) => {
                const total = te.durationHours * te.rate;
                return (
                  <tr key={te.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 whitespace-nowrap text-slate-600 font-mono-nums">
                      {formatDate(te.date)}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">{te.matterNumber}</div>
                      <div className="text-slate-500 text-[11px] truncate max-w-[180px]">{te.clientName}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-700 whitespace-nowrap">
                      {te.attorneyName}
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-mono-nums font-semibold text-slate-800">
                        {te.utbmsCode.split(' - ')[0]}
                      </span>
                      <div className="text-[11px] text-slate-500 truncate max-w-[140px]">
                        {te.utbmsCode.split(' - ')[1] || ''}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-800 max-w-sm truncate" title={te.description}>
                      {te.description}
                    </td>
                    <td className="py-3 px-4 text-right font-mono-nums font-semibold text-slate-900">
                      {te.durationHours.toFixed(1)}h
                    </td>
                    <td className="py-3 px-4 text-right font-mono-nums text-slate-600">
                      ${te.rate}
                    </td>
                    <td className="py-3 px-4 text-right font-mono-nums font-bold text-slate-900">
                      {formatCurrency(total)}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className={`inline-block text-[10px] font-semibold px-2 py-0.5 rounded ${
                        te.status === 'Unbilled'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {te.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => handleDelete(te.id)}
                        className="text-slate-400 hover:text-rose-600 p-1 rounded transition-colors"
                        title="Delete time entry"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}

              {filteredEntries.length === 0 && (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-slate-400 text-xs">
                    No time entries recorded matching the selected filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
