import React, { useState } from 'react';
import { usePractice } from '../../context/PracticeContext';
import { ShieldAlert, ShieldCheck, AlertTriangle, Search, Briefcase, User, Scale } from 'lucide-react';

interface ConflictCheckModalProps {
  onClose?: () => void;
  isModal?: boolean;
}

export const ConflictCheckModal: React.FC<ConflictCheckModalProps> = ({ onClose, isModal = false }) => {
  const { runConflictCheck, setSelectedMatterId, setActiveView } = usePractice();
  const [searchQuery, setSearchQuery] = useState('');
  const [searched, setSearched] = useState(false);

  const conflictResult = runConflictCheck(searchQuery);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setSearched(true);
    }
  };

  const handleViewMatter = (matterId: string) => {
    setSelectedMatterId(matterId);
    setActiveView('matters');
    if (onClose) onClose();
  };

  const content = (
    <div className="space-y-6">
      {/* Header Info */}
      <div className="border-b border-slate-200 pb-4">
        <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-slate-800" />
          <span>Conflict of Interest Check System</span>
        </h2>
        <p className="text-xs text-slate-500 mt-1 max-w-2xl">
          Automated ethics screening across active clients, opposing parties, adverse witnesses, former representations, and co-counsel records pursuant to ABA Model Rule 1.7 & 1.9.
        </p>
      </div>

      {/* Search Input Bar */}
      <form onSubmit={handleSearch} className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setSearched(true);
            }}
            placeholder="Enter party name, corporate entity, adverse witness, or attorney..."
            className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent placeholder-slate-400"
            autoFocus
          />
        </div>
        <button
          type="submit"
          className="px-5 py-2.5 bg-slate-900 text-white text-xs font-semibold rounded-lg hover:bg-slate-800 transition-colors shrink-0"
        >
          Screen Party
        </button>
      </form>

      {/* Suggested Quick Test Queries */}
      <div className="flex items-center gap-2 text-xs text-slate-500 flex-wrap">
        <span className="font-medium text-slate-600">Sample checks:</span>
        {['Apex Dynamics', 'Acme Technologies', 'Vanguard Capital', 'Sterling Therapeutics', 'Dr. Raymond Garcia'].map((sample) => (
          <button
            key={sample}
            type="button"
            onClick={() => {
              setSearchQuery(sample);
              setSearched(true);
            }}
            className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs transition-colors"
          >
            {sample}
          </button>
        ))}
      </div>

      {/* Results View */}
      {searched && (
        <div className="pt-2">
          {conflictResult.matchFound ? (
            <div className="space-y-4">
              {/* Alert Banner */}
              <div className="p-4 bg-rose-50 border border-rose-200 rounded-lg flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-semibold text-rose-900">
                    Conflict Identified: {conflictResult.hits.length} Potential Ethical Collision(s) Detected
                  </h3>
                  <p className="text-xs text-rose-700 mt-1">
                    Screening matched one or more records in firm repositories. Prior to executing retention agreements or accepting retainer funds, lead counsel must review ethical wall requirements.
                  </p>
                </div>
              </div>

              {/* Hit Cards */}
              <div className="space-y-3">
                {conflictResult.hits.map((hit, idx) => (
                  <div
                    key={idx}
                    className="p-4 bg-white border border-slate-200 rounded-lg shadow-xs hover:border-slate-300 transition-colors"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        <span className={`text-xs font-semibold px-2 py-0.5 rounded ${
                          hit.severity === 'High Conflict'
                            ? 'bg-rose-100 text-rose-800 border border-rose-200'
                            : hit.severity === 'Potential Adversary'
                            ? 'bg-amber-100 text-amber-800 border border-amber-200'
                            : 'bg-blue-100 text-blue-800 border border-blue-200'
                        }`}>
                          {hit.severity}
                        </span>
                        <span className="text-xs text-slate-500 font-medium">
                          Match Type: {hit.type}
                        </span>
                      </div>
                      <span className="text-xs font-mono-nums text-slate-500">
                        {hit.matterNumber}
                      </span>
                    </div>

                    <div className="mt-2.5">
                      <div className="text-sm font-bold text-slate-900">
                        {hit.name}
                      </div>
                      <div className="text-xs text-slate-600 mt-0.5">
                        Related Matter: <span className="font-semibold text-slate-800">{hit.matterTitle}</span>
                      </div>
                      <p className="text-xs text-slate-600 mt-2 bg-slate-50 p-2.5 rounded border border-slate-100">
                        {hit.notes}
                      </p>
                    </div>

                    <div className="mt-3 flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
                      <span>Lead Attorney: <strong className="text-slate-700 font-semibold">{hit.leadAttorney}</strong></span>
                      <button
                        onClick={() => handleViewMatter(hit.matterNumber)}
                        className="text-xs font-semibold text-slate-900 hover:text-blue-700 hover:underline flex items-center gap-1"
                      >
                        <Briefcase className="w-3.5 h-3.5" />
                        <span>Inspect Case File</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="p-8 text-center bg-emerald-50/60 border border-emerald-200 rounded-lg">
              <ShieldCheck className="w-10 h-10 text-emerald-600 mx-auto mb-2" />
              <h3 className="text-base font-semibold text-emerald-900">
                No Conflicts Detected — Cleared for Representation
              </h3>
              <p className="text-xs text-emerald-700 max-w-md mx-auto mt-1">
                Zero matching adverse parties, clients, or former litigation adversaries were found for <strong>"{searchQuery}"</strong>. Safe to proceed with matter onboarding and engagement agreement generation.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );

  if (isModal) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
        <div className="w-full max-w-2xl bg-white rounded-xl shadow-2xl p-6 border border-slate-200 max-h-[85vh] overflow-y-auto">
          {content}
          <div className="mt-6 flex justify-end">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-6 px-4">
      {content}
    </div>
  );
};
