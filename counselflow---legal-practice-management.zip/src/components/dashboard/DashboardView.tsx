import React from 'react';
import { usePractice } from '../../context/PracticeContext';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { 
  Scale, 
  Clock, 
  Receipt, 
  Briefcase, 
  AlertTriangle, 
  ShieldCheck, 
  Plus, 
  ArrowUpRight, 
  FileText, 
  ShieldAlert, 
  CheckCircle2, 
  Calendar 
} from 'lucide-react';

interface DashboardViewProps {
  onOpenNewTimeModal: () => void;
  onOpenNewMatterModal: () => void;
  onOpenTimerDrawer: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ 
  onOpenNewTimeModal, 
  onOpenNewMatterModal,
  onOpenTimerDrawer 
}) => {
  const { 
    matters, 
    timeEntries, 
    invoices, 
    reconciliation, 
    totalTrustBalance, 
    totalUnbilledWIP, 
    totalUnpaidInvoices,
    activeMattersCount,
    setActiveView,
    setSelectedMatterId
  } = usePractice();

  // Upcoming court deadlines & SOL dates
  const criticalDeadlines: {
    matterId: string;
    matterNumber: string;
    matterTitle: string;
    title: string;
    date: string;
    isCourtDeadline: boolean;
  }[] = [];

  matters.forEach(m => {
    // Check tasks
    m.tasks.filter(t => !t.completed).forEach(t => {
      criticalDeadlines.push({
        matterId: m.id,
        matterNumber: m.matterNumber,
        matterTitle: m.title,
        title: t.title,
        date: t.dueDate,
        isCourtDeadline: !!t.isCourtDeadline
      });
    });

    // Check SOL
    if (m.statuteOfLimitationsDate) {
      criticalDeadlines.push({
        matterId: m.id,
        matterNumber: m.matterNumber,
        matterTitle: m.title,
        title: `Statute of Limitations (SOL) Deadline`,
        date: m.statuteOfLimitationsDate,
        isCourtDeadline: true
      });
    }
  });

  // Sort by date ascending
  criticalDeadlines.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  // Recent 4 time entries
  const recentEntries = timeEntries.slice(0, 4);

  return (
    <div className="space-y-6">
      {/* Executive Welcome & Firm Pulse */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            Practice Overview & Operations Console
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            CounselFlow Legal Partners LLP · Managing Partner Console
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenTimerDrawer}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors shadow-xs"
          >
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            <span>Open Timer</span>
          </button>
          <button
            onClick={onOpenNewMatterModal}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Matter Intake</span>
          </button>
        </div>
      </div>

      {/* Top 4 KPI Metrics with High-Density Polish */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: IOLTA Trust Balance */}
        <div 
          onClick={() => setActiveView('trust')}
          className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs hover:border-slate-300 cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span className="font-semibold text-slate-700">IOLTA Trust Escrow</span>
            <Scale className="w-4 h-4 text-amber-600 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-bold font-mono-nums text-slate-900 mt-2">
            {formatCurrency(totalTrustBalance)}
          </div>
          <div className="mt-2 flex items-center gap-1.5 text-[11px] text-emerald-700 font-medium">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>3-Way Reconciled ($0.00 Variance)</span>
          </div>
        </div>

        {/* KPI 2: Unbilled WIP */}
        <div 
          onClick={() => setActiveView('billing')}
          className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs hover:border-slate-300 cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span className="font-semibold text-slate-700">Unbilled Work in Progress</span>
            <Clock className="w-4 h-4 text-blue-600 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-bold font-mono-nums text-slate-900 mt-2">
            {formatCurrency(totalUnbilledWIP)}
          </div>
          <div className="mt-2 text-[11px] text-slate-500">
            {timeEntries.filter(t => t.status === 'Unbilled').length} unbilled UTBMS time entries
          </div>
        </div>

        {/* KPI 3: Accounts Receivable */}
        <div 
          onClick={() => setActiveView('invoices')}
          className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs hover:border-slate-300 cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span className="font-semibold text-slate-700">Accounts Receivable (A/R)</span>
            <Receipt className="w-4 h-4 text-slate-700 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-bold font-mono-nums text-slate-900 mt-2">
            {formatCurrency(totalUnpaidInvoices)}
          </div>
          <div className="mt-2 text-[11px] text-slate-500">
            {invoices.filter(i => i.status !== 'Paid').length} outstanding client statements
          </div>
        </div>

        {/* KPI 4: Active Matters */}
        <div 
          onClick={() => setActiveView('matters')}
          className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs hover:border-slate-300 cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span className="font-semibold text-slate-700">Active Legal Matters</span>
            <Briefcase className="w-4 h-4 text-slate-700 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-bold font-mono-nums text-slate-900 mt-2">
            {activeMattersCount}
          </div>
          <div className="mt-2 text-[11px] text-slate-500">
            Across 6 specialized practice areas
          </div>
        </div>
      </div>

      {/* Main Grid: Urgent Statutory Deadlines (Left 7 cols) & Quick Actions / Ledger Snapshot (Right 5 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Court & Statutory Deadlines */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
            <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-slate-700" />
                <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Upcoming Court Deadlines & Statutory Sol Dates
                </h2>
              </div>
              <span className="text-[11px] text-slate-500 font-mono-nums">
                {criticalDeadlines.length} critical items
              </span>
            </div>

            <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto">
              {criticalDeadlines.slice(0, 6).map((item, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    setSelectedMatterId(item.matterId);
                    setActiveView('matters');
                  }}
                  className="p-4 hover:bg-slate-50 transition-colors cursor-pointer flex items-start justify-between gap-3"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono-nums font-bold text-xs text-slate-900">
                        {item.matterNumber}
                      </span>
                      {item.isCourtDeadline && (
                        <span className="px-2 py-0.5 text-[10px] font-bold bg-rose-100 text-rose-800 rounded">
                          Court Deadline
                        </span>
                      )}
                    </div>
                    <div className="text-xs font-semibold text-slate-800 mt-1">
                      {item.title}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5 truncate max-w-md">
                      {item.matterTitle}
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-xs font-bold text-slate-900 whitespace-nowrap block">
                      {formatDate(item.date)}
                    </span>
                    <span className="text-[10px] text-slate-400">Due</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Time Tracking Ledger */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
            <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-600" />
                <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Recent Billable Activity (UTBMS Standard)
                </h2>
              </div>
              <button
                onClick={onOpenNewTimeModal}
                className="text-xs font-semibold text-slate-900 hover:text-blue-700 flex items-center gap-1"
              >
                <span>+ Log Entry</span>
              </button>
            </div>

            <div className="divide-y divide-slate-100">
              {recentEntries.map((te) => (
                <div key={te.id} className="p-3.5 hover:bg-slate-50 transition-colors flex items-center justify-between text-xs">
                  <div>
                    <div className="font-semibold text-slate-900">
                      {te.matterNumber}: {te.utbmsCode}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5 truncate max-w-md">
                      {te.description}
                    </div>
                  </div>

                  <div className="text-right shrink-0 ml-3">
                    <div className="font-mono-nums font-bold text-slate-900">
                      {formatCurrency(te.durationHours * te.rate)}
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono-nums">
                      {te.durationHours.toFixed(1)}h @ ${te.rate}/hr
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Quick Workflows & IOLTA Snapshot (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Quick Actions Card */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Quick Practice Workflows
            </h2>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={onOpenNewTimeModal}
                className="p-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-left transition-colors group"
              >
                <Clock className="w-4 h-4 text-amber-600 mb-1 group-hover:scale-110 transition-transform" />
                <div className="font-bold text-slate-900">Log UTBMS Time</div>
                <div className="text-[11px] text-slate-500 mt-0.5">Tenth-hour billing</div>
              </button>

              <button
                onClick={() => setActiveView('conflicts')}
                className="p-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-left transition-colors group"
              >
                <ShieldAlert className="w-4 h-4 text-rose-600 mb-1 group-hover:scale-110 transition-transform" />
                <div className="font-bold text-slate-900">Conflict Check</div>
                <div className="text-[11px] text-slate-500 mt-0.5">Ethics screening</div>
              </button>

              <button
                onClick={() => setActiveView('documents')}
                className="p-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-left transition-colors group"
              >
                <FileText className="w-4 h-4 text-blue-600 mb-1 group-hover:scale-110 transition-transform" />
                <div className="font-bold text-slate-900">Assemble Contract</div>
                <div className="text-[11px] text-slate-500 mt-0.5">NDA / Engagement</div>
              </button>

              <button
                onClick={() => setActiveView('trust')}
                className="p-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-left transition-colors group"
              >
                <Scale className="w-4 h-4 text-emerald-600 mb-1 group-hover:scale-110 transition-transform" />
                <div className="font-bold text-slate-900">IOLTA Audit</div>
                <div className="text-[11px] text-slate-500 mt-0.5">3-way reconcile</div>
              </button>
            </div>
          </div>

          {/* Client Trust Retainer Balances Snapshot */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
            <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
              <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Client Trust Escrow Balances
              </h2>
              <span className="text-[11px] font-mono-nums font-bold text-slate-900">
                {formatCurrency(totalTrustBalance)} Total
              </span>
            </div>

            <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
              {matters.map((matter) => (
                <div 
                  key={matter.id}
                  onClick={() => {
                    setSelectedMatterId(matter.id);
                    setActiveView('matters');
                  }}
                  className="p-3 hover:bg-slate-50 transition-colors cursor-pointer flex items-center justify-between text-xs"
                >
                  <div>
                    <div className="font-semibold text-slate-900">
                      {matter.clientName}
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono-nums">
                      {matter.matterNumber} · {matter.practiceArea}
                    </div>
                  </div>

                  <div className="text-right font-mono-nums font-bold text-slate-900">
                    {formatCurrency(matter.trustBalance)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
