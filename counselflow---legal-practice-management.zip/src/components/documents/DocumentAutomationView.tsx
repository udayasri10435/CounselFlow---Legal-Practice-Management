import React, { useState } from 'react';
import { usePractice } from '../../context/PracticeContext';
import { formatDate } from '../../utils/formatters';
import { DocumentTemplate, GeneratedDocument } from '../../types';
import { 
  FileText, 
  Copy, 
  Printer, 
  Check, 
  Save, 
  Trash2, 
  Plus, 
  FolderPlus, 
  CheckCircle2,
  FileCheck2,
  Edit3
} from 'lucide-react';

export const DocumentAutomationView: React.FC = () => {
  const { 
    templates, 
    generatedDocs, 
    matters, 
    generateDocument, 
    updateGeneratedDoc, 
    deleteGeneratedDoc 
  } = usePractice();

  const [activeTab, setActiveTab] = useState<'templates' | 'assembled'>('templates');
  const [selectedTemplate, setSelectedTemplate] = useState<DocumentTemplate>(templates[0]);
  const [selectedMatterId, setSelectedMatterId] = useState<string>(matters[0]?.id || '');
  const [docTitle, setDocTitle] = useState('');
  const [variableValues, setVariableValues] = useState<Record<string, string>>({});
  const [selectedClauseIds, setSelectedClauseIds] = useState<string[]>([]);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Active Document Viewer state (for generated/saved docs)
  const [viewingDoc, setViewingDoc] = useState<GeneratedDocument | null>(generatedDocs[0] || null);

  // Initialize form when template or matter changes
  const initForm = (tmpl: DocumentTemplate, mId: string) => {
    const matter = matters.find(m => m.id === mId) || matters[0];
    const initialVars: Record<string, string> = {};

    tmpl.variables.forEach(v => {
      // Intelligent autofill from matter data
      if (v.key === 'client_name' && matter) {
        initialVars[v.key] = matter.clientName;
      } else if (v.key === 'matter_title' && matter) {
        initialVars[v.key] = matter.title;
      } else if (v.key === 'lead_attorney' && matter) {
        initialVars[v.key] = matter.leadAttorney;
      } else if (v.key === 'hourly_rate' && matter) {
        initialVars[v.key] = String(matter.defaultRate);
      } else if (v.key === 'opposing_party' && matter?.opposingParty) {
        initialVars[v.key] = matter.opposingParty;
      } else if (v.key === 'party_a' && matter) {
        initialVars[v.key] = matter.clientName;
      } else if (v.key === 'effective_date') {
        initialVars[v.key] = new Date().toISOString().split('T')[0];
      } else {
        initialVars[v.key] = v.defaultValue;
      }
    });

    setVariableValues(initialVars);
    setSelectedClauseIds(tmpl.clauses.filter(c => c.defaultIncluded).map(c => c.id));
    setDocTitle(`${tmpl.title} - ${matter?.clientName || 'Draft'}`);
  };

  // Compile live preview text
  const compilePreview = () => {
    if (!selectedTemplate) return '';
    const activeClauses = selectedTemplate.clauses.filter(cl => selectedClauseIds.includes(cl.id));
    const clausesText = activeClauses.length > 0
      ? activeClauses.map(c => `### ${c.title}\n${c.content}`).join('\n\n')
      : '_No optional clauses selected._';

    let compiled = selectedTemplate.bodyContent;
    compiled = compiled.replace(/\{\{selected_clauses\}\}/g, clausesText);

    Object.entries(variableValues).forEach(([k, v]) => {
      const reg = new RegExp(`\\{\\{${k}\\}\\}`, 'g');
      compiled = compiled.replace(reg, v || `[${k.toUpperCase()}]`);
    });

    return compiled;
  };

  const previewContent = compilePreview();

  const handleAssembleAndSave = () => {
    const doc = generateDocument({
      templateId: selectedTemplate.id,
      matterId: selectedMatterId,
      title: docTitle || `${selectedTemplate.title} - ${matters.find(m => m.id === selectedMatterId)?.clientName}`,
      variableValues,
      selectedClauseIds
    });

    setViewingDoc(doc);
    setActiveTab('assembled');
    setNotification({ type: 'success', message: `Document "${doc.title}" assembled and saved to matter file.` });
  };

  const handleCopyMarkdown = (text: string) => {
    navigator.clipboard.writeText(text);
    setNotification({ type: 'success', message: 'Document text copied to clipboard.' });
  };

  const handleUpdateStatus = (docId: string, status: GeneratedDocument['status']) => {
    updateGeneratedDoc(docId, { status });
    if (viewingDoc && viewingDoc.id === docId) {
      setViewingDoc({ ...viewingDoc, status });
    }
    setNotification({ type: 'success', message: `Status updated to ${status}.` });
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <FileText className="w-5 h-5 text-slate-800" />
            <span>Document Automation & Dynamic Assembly</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Assemble jurisdiction-specific contracts, NDAs, pre-suit demands, and retainer agreements with dynamic merge fields.
          </p>
        </div>

        {/* View Switcher Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-medium">
          <button
            onClick={() => setActiveTab('templates')}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              activeTab === 'templates'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Template Builder
          </button>
          <button
            onClick={() => setActiveTab('assembled')}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              activeTab === 'assembled'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Executed / Saved ({generatedDocs.length})
          </button>
        </div>
      </div>

      {/* Notification Toast */}
      {notification && (
        <div className={`p-3.5 rounded-lg flex items-center justify-between text-xs font-medium ${
          notification.type === 'success' 
            ? 'bg-emerald-50 text-emerald-900 border border-emerald-200' 
            : 'bg-rose-50 text-rose-900 border border-rose-200'
        }`}>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{notification.message}</span>
          </div>
          <button onClick={() => setNotification(null)} className="text-slate-400 hover:text-slate-600 font-bold">
            ✕
          </button>
        </div>
      )}

      {/* Mode 1: Document Template Builder with Live Preview */}
      {activeTab === 'templates' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Form Controls (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
              <h2 className="text-sm font-bold text-slate-900">
                1. Select Legal Template & Target Matter
              </h2>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Template Library
                </label>
                <select
                  value={selectedTemplate.id}
                  onChange={(e) => {
                    const tmpl = templates.find(t => t.id === e.target.value) || templates[0];
                    setSelectedTemplate(tmpl);
                    initForm(tmpl, selectedMatterId);
                  }}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-900 bg-white"
                >
                  {templates.map(t => (
                    <option key={t.id} value={t.id}>
                      {t.title} ({t.category})
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-slate-500 mt-1 italic">
                  {selectedTemplate.description}
                </p>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Autofill from Matter
                </label>
                <select
                  value={selectedMatterId}
                  onChange={(e) => {
                    setSelectedMatterId(e.target.value);
                    initForm(selectedTemplate, e.target.value);
                  }}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-900 bg-white"
                >
                  {matters.map(m => (
                    <option key={m.id} value={m.id}>
                      {m.matterNumber}: {m.clientName} ({m.title})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Document Working Title
                </label>
                <input
                  type="text"
                  value={docTitle}
                  onChange={(e) => setDocTitle(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-900"
                />
              </div>
            </div>

            {/* Dynamic Variables Form */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
              <h2 className="text-sm font-bold text-slate-900">
                2. Dynamic Variable Merge Fields
              </h2>
              <p className="text-xs text-slate-500">
                Values update in real-time in the legal preview pane.
              </p>

              <div className="space-y-3 pt-2">
                {selectedTemplate.variables.map((v) => (
                  <div key={v.key}>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      {v.label} <code className="font-mono text-[10px] text-amber-800 bg-amber-50 px-1 py-0.5 rounded">{`{{${v.key}}}`}</code>
                    </label>
                    <input
                      type={v.type === 'date' ? 'date' : 'text'}
                      value={variableValues[v.key] ?? v.defaultValue}
                      onChange={(e) => {
                        setVariableValues(prev => ({ ...prev, [v.key]: e.target.value }));
                      }}
                      className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md text-slate-900"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Modular Clauses Library */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
              <h2 className="text-sm font-bold text-slate-900">
                3. Modular Clause Library ({selectedTemplate.clauses.length})
              </h2>
              <p className="text-xs text-slate-500">
                Select specific legal riders, warranties, and arbitration clauses to insert.
              </p>

              <div className="space-y-2 pt-2">
                {selectedTemplate.clauses.map((clause) => {
                  const isChecked = selectedClauseIds.includes(clause.id);
                  return (
                    <label
                      key={clause.id}
                      className={`block p-3 rounded-lg border cursor-pointer transition-colors ${
                        isChecked
                          ? 'border-slate-400 bg-slate-50/80'
                          : 'border-slate-200 hover:bg-slate-50/40 opacity-75'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedClauseIds(prev => [...prev, clause.id]);
                            } else {
                              setSelectedClauseIds(prev => prev.filter(id => id !== clause.id));
                            }
                          }}
                          className="rounded border-slate-300 text-slate-900 focus:ring-slate-900"
                        />
                        <span className="text-xs font-semibold text-slate-900">
                          {clause.title}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 mt-1 pl-5 leading-relaxed line-clamp-2">
                        {clause.content}
                      </p>
                    </label>
                  );
                })}
              </div>

              {/* Action Button */}
              <div className="pt-3">
                <button
                  type="button"
                  onClick={handleAssembleAndSave}
                  className="w-full flex items-center justify-center gap-2 py-2.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors shadow-sm"
                >
                  <Save className="w-4 h-4" />
                  <span>Assemble & Save to Matter Docket</span>
                </button>
              </div>
            </div>
          </div>

          {/* Right Column: Live Legal Document Preview (7 cols) */}
          <div className="lg:col-span-7">
            <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden sticky top-20">
              {/* Preview Bar */}
              <div className="p-3 bg-slate-900 text-white flex items-center justify-between no-print">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-semibold tracking-wide">Live Contract Preview</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCopyMarkdown(previewContent)}
                    className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 rounded transition-colors"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Text</span>
                  </button>
                  <button
                    onClick={() => window.print()}
                    className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 rounded transition-colors"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Print</span>
                  </button>
                </div>
              </div>

              {/* Legal Document Render Surface */}
              <div className="p-8 max-h-[800px] overflow-y-auto font-legal-serif text-slate-900 leading-relaxed text-sm bg-white whitespace-pre-wrap select-text selection:bg-amber-100">
                {previewContent}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Mode 2: Saved / Executed Documents Directory */}
      {activeTab === 'assembled' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Document Directory (4 cols) */}
          <div className="lg:col-span-4 space-y-3">
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
              <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-700">
                Matter Documents Archive
              </div>
              <div className="divide-y divide-slate-100 max-h-[600px] overflow-y-auto">
                {generatedDocs.map((doc) => {
                  const isSelected = viewingDoc?.id === doc.id;
                  return (
                    <button
                      key={doc.id}
                      onClick={() => setViewingDoc(doc)}
                      className={`w-full text-left p-4 transition-colors ${
                        isSelected ? 'bg-amber-50/70 border-l-4 border-amber-500' : 'hover:bg-slate-50'
                      }`}
                    >
                      <div className="text-xs font-bold text-slate-900 truncate">
                        {doc.title}
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        {doc.clientName} · {doc.matterNumber}
                      </div>
                      <div className="mt-2 flex items-center justify-between text-[11px]">
                        <span className="text-slate-400">{formatDate(doc.lastModified)}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          doc.status === 'Executed'
                            ? 'bg-emerald-100 text-emerald-800'
                            : doc.status === 'Finalized'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}>
                          {doc.status}
                        </span>
                      </div>
                    </button>
                  );
                })}

                {generatedDocs.length === 0 && (
                  <div className="p-8 text-center text-xs text-slate-400">
                    No documents assembled yet. Use the Template Builder to generate legal contracts.
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Document Viewer (8 cols) */}
          <div className="lg:col-span-8">
            {viewingDoc ? (
              <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
                <div className="p-4 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-3 no-print">
                  <div>
                    <h3 className="text-xs font-bold">{viewingDoc.title}</h3>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      Client: {viewingDoc.clientName} · {viewingDoc.matterTitle}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Status Dropdown */}
                    <select
                      value={viewingDoc.status}
                      onChange={(e) => handleUpdateStatus(viewingDoc.id, e.target.value as any)}
                      className="text-xs bg-slate-800 text-slate-200 border border-slate-700 rounded px-2 py-1 focus:outline-none"
                    >
                      <option value="Draft">Draft</option>
                      <option value="Under Review">Under Review</option>
                      <option value="Finalized">Finalized</option>
                      <option value="Executed">Executed</option>
                    </select>

                    <button
                      onClick={() => handleCopyMarkdown(viewingDoc.content)}
                      className="p-1.5 text-slate-300 hover:text-white bg-slate-800 rounded transition-colors"
                      title="Copy Document Text"
                    >
                      <Copy className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => window.print()}
                      className="p-1.5 text-slate-300 hover:text-white bg-slate-800 rounded transition-colors"
                      title="Print Document"
                    >
                      <Printer className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => {
                        deleteGeneratedDoc(viewingDoc.id);
                        setViewingDoc(generatedDocs.filter(d => d.id !== viewingDoc.id)[0] || null);
                        setNotification({ type: 'success', message: 'Document deleted from docket.' });
                      }}
                      className="p-1.5 text-slate-400 hover:text-rose-400 bg-slate-800 rounded transition-colors"
                      title="Delete Document"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="p-8 font-legal-serif text-slate-900 leading-relaxed text-sm bg-white whitespace-pre-wrap select-text max-h-[700px] overflow-y-auto">
                  {viewingDoc.content}
                </div>
              </div>
            ) : (
              <div className="p-12 text-center text-slate-400 text-xs bg-white border border-slate-200 rounded-xl">
                Select a document from the archive to inspect.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
