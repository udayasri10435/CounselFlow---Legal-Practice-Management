import React from 'react';
import { usePractice } from '../../context/PracticeContext';
import { formatDuration } from '../../utils/formatters';
import { Search, Play, Pause, Clock, Plus } from 'lucide-react';

interface HeaderProps {
  onOpenNewTimeModal: () => void;
  onOpenTimerDrawer: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenNewTimeModal, onOpenTimerDrawer }) => {
  const { 
    activeView, 
    setActiveView, 
    setIsCommandPaletteOpen, 
    activeTimer, 
    startTimer, 
    pauseTimer 
  } = usePractice();

  const navItems: { id: typeof activeView; label: string }[] = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'matters', label: 'Matters' },
    { id: 'billing', label: 'Time & WIP' },
    { id: 'invoices', label: 'Invoices' },
    { id: 'trust', label: 'Trust / IOLTA' },
    { id: 'documents', label: 'Documents' },
  ];

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between h-16 px-6 bg-slate-900 border-b border-slate-800 text-white select-none">
      {/* Zone 1: Single text element wordmark */}
      <button 
        onClick={() => setActiveView('dashboard')}
        className="text-lg font-bold tracking-tight text-white hover:text-amber-300 transition-colors whitespace-nowrap shrink-0"
      >
        CounselFlow
      </button>

      {/* Zone 2: 4-6 clean text navigation links */}
      <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-300">
        {navItems.map((item) => {
          const isActive = activeView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id)}
              className={`transition-colors whitespace-nowrap relative py-1 ${
                isActive 
                  ? 'text-white font-semibold' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {item.label}
              {isActive && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-400 rounded-full" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Zone 3: 1-2 primary actions (Timer indicator & Search / Quick Log) */}
      <div className="flex items-center gap-3">
        {/* Quick Search Shortcut */}
        <button
          onClick={() => setIsCommandPaletteOpen(true)}
          className="flex items-center gap-2 px-3 py-1.5 text-xs text-slate-400 bg-slate-800/80 hover:bg-slate-800 hover:text-slate-200 border border-slate-700/60 rounded-md transition-colors whitespace-nowrap"
          title="Search matters, clients, invoices (⌘K)"
        >
          <Search className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Search</span>
          <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono bg-slate-700 text-slate-300 rounded">⌘K</kbd>
        </button>

        {/* Live Active Timer Widget Toggle */}
        <div className="flex items-center bg-slate-800 border border-slate-700 rounded-md overflow-hidden p-0.5">
          <button
            onClick={() => {
              if (activeTimer.isRunning) {
                pauseTimer();
              } else {
                startTimer();
              }
            }}
            className={`p-1.5 rounded transition-colors ${
              activeTimer.isRunning 
                ? 'bg-amber-500/20 text-amber-400 hover:bg-amber-500/30' 
                : 'text-slate-400 hover:text-white hover:bg-slate-700'
            }`}
            title={activeTimer.isRunning ? 'Pause Timer' : 'Start Timer'}
          >
            {activeTimer.isRunning ? (
              <Pause className="w-3.5 h-3.5" />
            ) : (
              <Play className="w-3.5 h-3.5" />
            )}
          </button>

          <button
            onClick={onOpenTimerDrawer}
            className={`px-2.5 py-1 text-xs font-mono-nums flex items-center gap-1.5 transition-colors ${
              activeTimer.isRunning 
                ? 'text-amber-400 font-semibold' 
                : 'text-slate-300 hover:text-white'
            }`}
            title="Open Live Timer Controls"
          >
            <Clock className="w-3.5 h-3.5 opacity-70" />
            <span>{formatDuration(activeTimer.seconds)}</span>
          </button>
        </div>

        {/* Primary Action Button */}
        <button
          onClick={onOpenNewTimeModal}
          className="hidden sm:flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-md transition-colors shadow-sm whitespace-nowrap shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Log Time</span>
        </button>
      </div>
    </header>
  );
};
