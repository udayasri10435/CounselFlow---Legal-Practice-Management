import React from 'react';
import { usePractice } from '../../context/PracticeContext';
import { formatCurrency } from '../../utils/formatters';
import { 
  LayoutDashboard, 
  Briefcase, 
  Clock, 
  Receipt, 
  Scale, 
  FileText, 
  ShieldAlert, 
  ShieldCheck, 
  Plus,
  Building2
} from 'lucide-react';

interface SidebarProps {
  onOpenNewTimeModal: () => void;
  onOpenNewMatterModal: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onOpenNewTimeModal, onOpenNewMatterModal }) => {
  const { 
    activeView, 
    setActiveView, 
    totalTrustBalance, 
    totalUnbilledWIP, 
    reconciliation,
    setSelectedMatterId 
  } = usePractice();

  const navLinks = [
    { id: 'dashboard' as const, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'matters' as const, label: 'Matters & Cases', icon: Briefcase },
    { id: 'billing' as const, label: 'Time & WIP', icon: Clock },
    { id: 'invoices' as const, label: 'Invoices & LEDES', icon: Receipt },
    { id: 'trust' as const, label: 'IOLTA Trust Accounting', icon: Scale },
    { id: 'documents' as const, label: 'Document Automation', icon: FileText },
    { id: 'conflicts' as const, label: 'Conflict Check', icon: ShieldAlert },
  ];

  return (
    <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col shrink-0 select-none text-slate-300">
      {/* Practice Identity Sub-lockup */}
      <div className="p-4 border-b border-slate-800 flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
          <Building2 className="w-5 h-5" />
        </div>
        <div className="overflow-hidden">
          <div className="text-xs font-bold text-white tracking-tight truncate">
            CounselFlow Partners
          </div>
          <div className="text-[11px] text-slate-400 truncate">
            San Francisco · New York
          </div>
        </div>
      </div>

      {/* Primary Navigation */}
      <div className="p-3 flex-1 overflow-y-auto space-y-1">
        <div className="px-3 py-1.5 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
          Practice Management
        </div>

        {navLinks.map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                if (item.id === 'matters') setSelectedMatterId(null);
                setActiveView(item.id);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                isActive
                  ? 'bg-amber-400 text-slate-950 font-bold shadow-xs'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-slate-950' : 'text-slate-400'}`} />
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Practice Health Snapshot */}
      <div className="p-3.5 m-3 bg-slate-850/80 rounded-xl border border-slate-800 text-xs space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
            IOLTA Trust Status
          </span>
          {reconciliation.status === 'Balanced' ? (
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          ) : (
            <ShieldAlert className="w-4 h-4 text-rose-400" />
          )}
        </div>

        <div>
          <div className="text-sm font-bold font-mono-nums text-white">
            {formatCurrency(totalTrustBalance)}
          </div>
          <div className="text-[10px] text-emerald-400 font-medium mt-0.5">
            Zero Variance Reconciled
          </div>
        </div>

        <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
          <span>Unbilled WIP</span>
          <span className="font-mono-nums font-semibold text-slate-200">
            {formatCurrency(totalUnbilledWIP)}
          </span>
        </div>
      </div>

      {/* Bottom User Profile */}
      <div className="p-3 border-t border-slate-800 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2.5 overflow-hidden">
          <div className="w-7 h-7 rounded-full bg-slate-700 text-amber-300 flex items-center justify-center font-bold text-xs shrink-0">
            VV
          </div>
          <div className="truncate">
            <div className="text-white font-medium truncate">Victoria Vance, Esq.</div>
            <div className="text-[10px] text-slate-400 truncate">Senior Litigation Partner</div>
          </div>
        </div>
      </div>
    </aside>
  );
};
