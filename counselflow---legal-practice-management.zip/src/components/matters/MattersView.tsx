import React, { useState } from 'react';
import { usePractice } from '../../context/PracticeContext';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { Matter, PracticeArea, MatterStatus } from '../../types';
import { 
  Briefcase, 
  Plus, 
  Search, 
  AlertTriangle, 
  Clock, 
  Scale, 
  FileText, 
  CheckCircle2, 
  Calendar, 
  User, 
  Phone, 
  Mail, 
  ShieldAlert,
  ChevronRight,
  X
} from 'lucide-react';

interface MattersViewProps {
  onOpenNewMatterModal: () => void;
  onOpenNewTimeModal: () => void;
}

export const MattersView: React.FC<MattersViewProps> = ({ onOpenNewMatterModal, onOpenNewTimeModal }) => {
  const { 
    matters, 
    timeEntries, 
    invoices, 
    trustTransactions, 
    selectedMatterId, 
    setSelectedMatterId,
    addMatterNote,
    addMatterTask,
    toggleMatterTask
  } = usePractice();

  const [searchQ, setSearchQ] = useState('');
  const [practiceFilter, setPracticeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Detail Modal Tab state
  const [detailTab, setDetailTab] = useState<'overview' | 'time' | 'trust' | 'notes' | 'tasks'>('overview');
  const [newNoteText, setNewNoteText] = useState('');
  const [newNoteCategory, setNewNoteCategory] = useState<'General' | 'Court Filing' | 'Client Call' | 'Settlement Negotiation'>('General');
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskDueDate, setNewTaskDueDate] = useState('');
  const [newTaskPriority, setNewTaskPriority] = useState<'High' | 'Medium' | 'Low'>('Medium');
  const [isCourtDeadline, setIsCourtDeadline] = useState(false);

  const selectedMatter = selectedMatterId ? matters.find(m => m.id === selectedMatterId) : null;

  // Filter matters
  const filteredMatters = matters.filter(m => {
    const q = searchQ.trim().toLowerCase();
    if (q) {
      const matchNumber = m.matterNumber.toLowerCase().includes(q);
      const matchTitle = m.title.toLowerCase().includes(q);
      const matchClient = m.clientName.toLowerCase().includes(q);
      const matchOpp = m.opposingParty?.toLowerCase().includes(q);
      if (!matchNumber && !matchTitle && !matchClient && !matchOpp) return false;
    }
    if (practiceFilter !== 'all' && m.practiceArea !== practiceFilter) return false;
    if (statusFilter !== 'all' && m.status !== statusFilter) return false;
    return true;
  });

  // Calculate SOL warnings (if within 90 days)
  const getSolStatus = (solDate?: string) => {
    if (!solDate) return null;
    const today = new Date().getTime();
    const sol = new Date(solDate).getTime();
    const daysLeft = Math.ceil((sol - today) / (1000 * 60 * 60 * 24));

    if (daysLeft < 0) {
      return { label: `SOL Expired (${Math.abs(daysLeft)}d ago)`, color: 'text-rose-700 bg-rose-50 border-rose-200' };
    } else if (daysLeft <= 60) {
      return { label: `SOL Approaching: ${daysLeft} days!`, color: 'text-rose-700 bg-rose-50 border-rose-300 font-bold' };
    } else if (daysLeft <= 180) {
      return { label: `SOL: ${daysLeft} days`, color: 'text-amber-700 bg-amber-50 border-amber-200' };
    }
    return { label: `SOL: ${formatDate(solDate)}`, color: 'text-slate-600 bg-slate-50 border-slate-200' };
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMatter || !newNoteText.trim()) return;
    addMatterNote(selectedMatter.id, newNoteText.trim(), newNoteCategory);
    setNewNoteText('');
  };

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMatter || !newTaskTitle.trim() || !newTaskDueDate) return;
    addMatterTask(selectedMatter.id, newTaskTitle.trim(), newTaskDueDate, newTaskPriority, isCourtDeadline);
    setNewTaskTitle('');
    setNewTaskDueDate('');
    setIsCourtDeadline(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Briefcase className="w-5 h-5 text-slate-800" />
            <span>Matters & Case Management</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Client matter directory, court dockets, statute of limitations deadlines, and fee budgets.
          </p>
        </div>

        <button
          onClick={onOpenNewMatterModal}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors shadow-sm self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Matter Intake</span>
        </button>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 bg-white p-3 border border-slate-200 rounded-xl shadow-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQ}
            onChange={(e) => setSearchQ(e.target.value)}
            placeholder="Search by case name, client, matter #, opposing party..."
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-md text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-slate-900"
          />
        </div>

        <div className="flex items-center gap-3 text-xs overflow-x-auto pb-1 md:pb-0">
          <div className="flex items-center gap-1.5 whitespace-nowrap">
            <span className="text-slate-500 font-medium">Practice Area:</span>
            <select
              value={practiceFilter}
              onChange={(e) => setPracticeFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded text-slate-800 text-xs focus:outline-none"
            >
              <option value="all">All Practice Areas</option>
              <option value="Commercial Litigation">Litigation</option>
              <option value="Corporate & M&A">Corporate & M&A</option>
              <option value="Intellectual Property">Intellectual Property</option>
              <option value="Employment & Labor">Employment & Labor</option>
              <option value="Estate & Trusts">Estate & Trusts</option>
              <option value="Real Estate">Real Estate</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 whitespace-nowrap">
            <span className="text-slate-500 font-medium">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded text-slate-800 text-xs focus:outline-none"
            >
              <option value="all">All Statuses</option>
              <option value="Intake">Intake</option>
              <option value="Active">Active</option>
              <option value="Discovery">Discovery</option>
              <option value="Pre-Trial">Pre-Trial</option>
              <option value="Settlement / Closing">Settlement / Closing</option>
              <option value="Closed">Closed</option>
            </select>
          </div>
        </div>
      </div>

      {/* High-Density Matters Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
                <th className="py-3 px-4">Matter #</th>
                <th className="py-3 px-4">Case Title & Client</th>
                <th className="py-3 px-4">Practice Area</th>
                <th className="py-3 px-4">Lead Attorney</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Statute of Limitations</th>
                <th className="py-3 px-4 text-right">IOLTA Trust</th>
                <th className="py-3 px-4 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredMatters.map((matter) => {
                const sol = getSolStatus(matter.statuteOfLimitationsDate);
                return (
                  <tr 
                    key={matter.id}
                    onClick={() => setSelectedMatterId(matter.id)}
                    className="hover:bg-amber-50/40 cursor-pointer transition-colors group"
                  >
                    <td className="py-3.5 px-4 font-mono-nums font-bold text-slate-900 whitespace-nowrap">
                      {matter.matterNumber}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-900 group-hover:text-blue-900">
                        {matter.title}
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        Client: <strong className="text-slate-700">{matter.clientName}</strong>
                        {matter.opposingParty && (
                          <span className="ml-2 text-rose-700">v. {matter.opposingParty}</span>
                        )}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-700 whitespace-nowrap">
                      {matter.practiceArea}
                    </td>
                    <td className="py-3.5 px-4 text-slate-700 whitespace-nowrap">
                      {matter.leadAttorney}
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold ${
                        matter.status === 'Active' || matter.status === 'Discovery'
                          ? 'bg-blue-100 text-blue-800'
                          : matter.status === 'Pre-Trial'
                          ? 'bg-amber-100 text-amber-800'
                          : matter.status === 'Intake'
                          ? 'bg-purple-100 text-purple-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}>
                        {matter.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      {sol ? (
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] border ${sol.color}`}>
                          {sol.label}
                        </span>
                      ) : (
                        <span className="text-slate-400 text-[11px]">—</span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono-nums font-bold text-slate-900 whitespace-nowrap">
                      {formatCurrency(matter.trustBalance)}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedMatterId(matter.id);
                        }}
                        className="p-1 text-slate-400 hover:text-slate-800 rounded transition-colors"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}

              {filteredMatters.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400 text-xs">
                    No matters found matching your search criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Selected Matter Detail Modal / Side Drawer */}
      {selectedMatter && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="w-full max-w-4xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="p-5 bg-slate-900 text-white flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs bg-slate-800 text-amber-300 px-2 py-0.5 rounded font-semibold">
                    {selectedMatter.matterNumber}
                  </span>
                  <span className="text-xs text-slate-400 font-medium">
                    {selectedMatter.practiceArea} · {selectedMatter.billingModel} (${selectedMatter.defaultRate}/hr)
                  </span>
                </div>
                <h2 className="text-base font-bold text-white mt-1">
                  {selectedMatter.title}
                </h2>
                <div className="text-xs text-slate-400 mt-0.5">
                  Client: <span className="text-slate-200 font-medium">{selectedMatter.clientName}</span> · Lead Counsel: <span className="text-slate-200 font-medium">{selectedMatter.leadAttorney}</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    onOpenNewTimeModal();
                  }}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-md transition-colors"
                >
                  + Log Time
                </button>
                <button
                  onClick={() => setSelectedMatterId(null)}
                  className="text-slate-400 hover:text-white p-1 rounded"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Tabs */}
            <div className="flex items-center gap-2 px-5 py-2.5 bg-slate-100 border-b border-slate-200 text-xs font-semibold">
              {(['overview', 'time', 'trust', 'tasks', 'notes'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setDetailTab(tab)}
                  className={`px-3 py-1.5 rounded-md capitalize transition-colors ${
                    detailTab === tab
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {tab === 'time' ? 'Time & WIP' : tab === 'trust' ? 'Trust & Invoices' : tab}
                </button>
              ))}
            </div>

            {/* Modal Tab Content */}
            <div className="p-6 overflow-y-auto flex-1 space-y-5 text-xs">
              {/* Tab 1: Overview */}
              {detailTab === 'overview' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-slate-50 border border-slate-200 rounded-lg">
                    <div>
                      <span className="text-slate-400 block text-[11px]">IOLTA Retainer Escrow</span>
                      <span className="text-base font-bold font-mono-nums text-slate-900">{formatCurrency(selectedMatter.trustBalance)}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[11px]">Default Rate</span>
                      <span className="text-base font-bold font-mono-nums text-slate-900">${selectedMatter.defaultRate}/hr</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[11px]">Open Date</span>
                      <span className="text-base font-semibold text-slate-900">{formatDate(selectedMatter.openDate)}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[11px]">Statute of Limitations</span>
                      <span className="text-base font-semibold text-rose-700">
                        {selectedMatter.statuteOfLimitationsDate ? formatDate(selectedMatter.statuteOfLimitationsDate) : 'N/A'}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Client Details */}
                    <div className="p-4 border border-slate-200 rounded-lg space-y-2">
                      <h3 className="font-bold text-slate-900 uppercase tracking-wider text-[11px]">Client Details</h3>
                      <div className="flex items-center gap-2 text-slate-700">
                        <User className="w-3.5 h-3.5 text-slate-400" />
                        <span>{selectedMatter.clientName}</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-700">
                        <Mail className="w-3.5 h-3.5 text-slate-400" />
                        <span>{selectedMatter.clientEmail}</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-700">
                        <Phone className="w-3.5 h-3.5 text-slate-400" />
                        <span>{selectedMatter.clientPhone}</span>
                      </div>
                    </div>

                    {/* Adverse Party & Court */}
                    <div className="p-4 border border-slate-200 rounded-lg space-y-2">
                      <h3 className="font-bold text-slate-900 uppercase tracking-wider text-[11px]">Litigation & Forum</h3>
                      <div>
                        <span className="text-slate-400">Opposing Party:</span>{' '}
                        <strong className="text-slate-800">{selectedMatter.opposingParty || 'None specified'}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400">Opposing Counsel:</span>{' '}
                        <span className="text-slate-700">{selectedMatter.opposingCounsel || 'N/A'}</span>
                      </div>
                      <div>
                        <span className="text-slate-400">Court / Venue:</span>{' '}
                        <span className="text-slate-700">{selectedMatter.courtOrJurisdiction || 'Arbitration / Private'}</span>
                      </div>
                      <div>
                        <span className="text-slate-400">Docket / Docket #:</span>{' '}
                        <span className="text-slate-700 font-mono-nums">{selectedMatter.docketNumber || 'N/A'}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 2: Time & WIP */}
              {detailTab === 'time' && (
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <h3 className="font-bold text-slate-900">Recorded Time Entries ({timeEntries.filter(t => t.matterId === selectedMatter.id).length})</h3>
                  </div>

                  <table className="w-full text-left border border-slate-200 rounded-lg overflow-hidden">
                    <thead className="bg-slate-50 text-slate-600">
                      <tr>
                        <th className="py-2 px-3">Date</th>
                        <th className="py-2 px-3">Attorney</th>
                        <th className="py-2 px-3">UTBMS Code</th>
                        <th className="py-2 px-3">Description</th>
                        <th className="py-2 px-3 text-right">Hours</th>
                        <th className="py-2 px-3 text-right">Amount</th>
                        <th className="py-2 px-3 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {timeEntries.filter(t => t.matterId === selectedMatter.id).map(te => (
                        <tr key={te.id}>
                          <td className="py-2 px-3 font-mono-nums text-slate-500">{formatDate(te.date)}</td>
                          <td className="py-2 px-3 text-slate-700">{te.attorneyName}</td>
                          <td className="py-2 px-3 font-mono-nums font-semibold">{te.utbmsCode.split(' - ')[0]}</td>
                          <td className="py-2 px-3 text-slate-700 truncate max-w-xs">{te.description}</td>
                          <td className="py-2 px-3 text-right font-mono-nums">{te.durationHours.toFixed(1)}h</td>
                          <td className="py-2 px-3 text-right font-mono-nums font-semibold">{formatCurrency(te.durationHours * te.rate)}</td>
                          <td className="py-2 px-3 text-center">
                            <span className={`px-2 py-0.5 rounded text-[10px] ${te.status === 'Unbilled' ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'}`}>
                              {te.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Tab 3: Trust & Invoices */}
              {detailTab === 'trust' && (
                <div className="space-y-4">
                  <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-lg flex justify-between items-center">
                    <div>
                      <span className="font-bold text-amber-900 block">Available IOLTA Trust Balance</span>
                      <span className="text-xs text-amber-700">Dedicated escrow reserve for this matter</span>
                    </div>
                    <span className="text-xl font-bold font-mono-nums text-amber-950">{formatCurrency(selectedMatter.trustBalance)}</span>
                  </div>

                  <div>
                    <h4 className="font-bold text-slate-900 mb-2">Invoices for this Matter</h4>
                    <table className="w-full text-left border border-slate-200 rounded-lg overflow-hidden">
                      <thead className="bg-slate-50 text-slate-600">
                        <tr>
                          <th className="py-2 px-3">Invoice #</th>
                          <th className="py-2 px-3">Issue Date</th>
                          <th className="py-2 px-3">Total</th>
                          <th className="py-2 px-3">Paid from Trust</th>
                          <th className="py-2 px-3">Balance Due</th>
                          <th className="py-2 px-3">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {invoices.filter(i => i.matterId === selectedMatter.id).map(inv => (
                          <tr key={inv.id}>
                            <td className="py-2 px-3 font-mono-nums font-bold">{inv.invoiceNumber}</td>
                            <td className="py-2 px-3">{formatDate(inv.issueDate)}</td>
                            <td className="py-2 px-3 font-mono-nums">{formatCurrency(inv.total)}</td>
                            <td className="py-2 px-3 font-mono-nums text-emerald-700">{formatCurrency(inv.trustApplied)}</td>
                            <td className="py-2 px-3 font-mono-nums font-bold">{formatCurrency(inv.balanceDue)}</td>
                            <td className="py-2 px-3">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${inv.status === 'Paid' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'}`}>
                                {inv.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Tab 4: Tasks & Court Deadlines */}
              {detailTab === 'tasks' && (
                <div className="space-y-4">
                  <form onSubmit={handleAddTask} className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex flex-wrap gap-2 items-end">
                    <div className="flex-1 min-w-[200px]">
                      <label className="block text-[11px] font-medium text-slate-700 mb-1">New Task / Deadline Title</label>
                      <input
                        type="text"
                        value={newTaskTitle}
                        onChange={(e) => setNewTaskTitle(e.target.value)}
                        placeholder="E.g., File response to motion for summary judgment..."
                        className="w-full px-2.5 py-1.5 border border-slate-300 rounded text-xs text-slate-900 bg-white"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-slate-700 mb-1">Due Date</label>
                      <input
                        type="date"
                        value={newTaskDueDate}
                        onChange={(e) => setNewTaskDueDate(e.target.value)}
                        className="px-2.5 py-1.5 border border-slate-300 rounded text-xs text-slate-900 bg-white"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-slate-700 mb-1">Priority</label>
                      <select
                        value={newTaskPriority}
                        onChange={(e) => setNewTaskPriority(e.target.value as any)}
                        className="px-2.5 py-1.5 border border-slate-300 rounded text-xs text-slate-900 bg-white"
                      >
                        <option value="High">High</option>
                        <option value="Medium">Medium</option>
                        <option value="Low">Low</option>
                      </select>
                    </div>
                    <label className="flex items-center gap-1.5 pb-2 text-[11px] text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={isCourtDeadline}
                        onChange={(e) => setIsCourtDeadline(e.target.checked)}
                        className="rounded border-slate-300"
                      />
                      <span>Court Statutory Deadline</span>
                    </label>
                    <button
                      type="submit"
                      className="px-3.5 py-1.5 font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded text-xs"
                    >
                      Add Task
                    </button>
                  </form>

                  <div className="space-y-2">
                    {selectedMatter.tasks.map((task) => (
                      <div
                        key={task.id}
                        onClick={() => toggleMatterTask(selectedMatter.id, task.id)}
                        className={`flex items-center justify-between p-3 border rounded-lg cursor-pointer transition-colors ${
                          task.completed ? 'bg-slate-50 opacity-60 border-slate-200' : 'bg-white hover:bg-slate-50 border-slate-200'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <input
                            type="checkbox"
                            checked={task.completed}
                            onChange={() => {}}
                            className="rounded border-slate-300 text-slate-900"
                          />
                          <div>
                            <span className={`text-xs font-semibold ${task.completed ? 'line-through text-slate-400' : 'text-slate-900'}`}>
                              {task.title}
                            </span>
                            <div className="text-[11px] text-slate-500">
                              Assigned: {task.assignedTo} · Due: {formatDate(task.dueDate)}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          {task.isCourtDeadline && (
                            <span className="px-2 py-0.5 text-[10px] font-bold bg-rose-100 text-rose-800 rounded">
                              Court Deadline
                            </span>
                          )}
                          <span className={`px-2 py-0.5 text-[10px] font-medium rounded ${
                            task.priority === 'High' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700'
                          }`}>
                            {task.priority}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tab 5: Notes */}
              {detailTab === 'notes' && (
                <div className="space-y-4">
                  <form onSubmit={handleAddNote} className="space-y-2 p-3 bg-slate-50 border border-slate-200 rounded-lg">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-800">Add Case Note / Call Record</span>
                      <select
                        value={newNoteCategory}
                        onChange={(e) => setNewNoteCategory(e.target.value as any)}
                        className="text-xs px-2 py-1 border border-slate-300 rounded bg-white"
                      >
                        <option value="General">General</option>
                        <option value="Court Filing">Court Filing</option>
                        <option value="Client Call">Client Call</option>
                        <option value="Settlement Negotiation">Settlement Negotiation</option>
                      </select>
                    </div>
                    <textarea
                      value={newNoteText}
                      onChange={(e) => setNewNoteText(e.target.value)}
                      placeholder="Record memorandum, court filing update, or client discussion..."
                      rows={2}
                      className="w-full p-2 text-xs border border-slate-300 rounded text-slate-900 resize-none bg-white"
                      required
                    />
                    <div className="flex justify-end">
                      <button
                        type="submit"
                        className="px-3.5 py-1.5 font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded text-xs"
                      >
                        Post Note
                      </button>
                    </div>
                  </form>

                  <div className="space-y-2">
                    {selectedMatter.notes.map((note) => (
                      <div key={note.id} className="p-3 bg-white border border-slate-200 rounded-lg space-y-1">
                        <div className="flex items-center justify-between text-[11px] text-slate-500">
                          <span>{formatDate(note.date)} · <strong className="text-slate-700">{note.author}</strong></span>
                          <span className="font-semibold text-amber-800 bg-amber-50 px-2 py-0.5 rounded">{note.category}</span>
                        </div>
                        <p className="text-slate-800 text-xs leading-relaxed">{note.text}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
