import React, { useState } from 'react';
import { usePractice } from '../../context/PracticeContext';
import { PracticeArea, BillingModel } from '../../types';
import { Briefcase, AlertTriangle, ShieldCheck, X } from 'lucide-react';

interface NewMatterModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewMatterModal: React.FC<NewMatterModalProps> = ({ isOpen, onClose }) => {
  const { addMatter, runConflictCheck, setSelectedMatterId, setActiveView } = usePractice();

  const [title, setTitle] = useState('');
  const [clientName, setClientName] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [practiceArea, setPracticeArea] = useState<PracticeArea>('Commercial Litigation');
  const [billingModel, setBillingModel] = useState<BillingModel>('Hourly');
  const [defaultRate, setDefaultRate] = useState('650');
  const [leadAttorney, setLeadAttorney] = useState('Victoria Vance, Esq.');
  const [opposingParty, setOpposingParty] = useState('');
  const [opposingCounsel, setOpposingCounsel] = useState('');
  const [courtOrJurisdiction, setCourtOrJurisdiction] = useState('U.S. District Court');
  const [docketNumber, setDocketNumber] = useState('');
  const [solDate, setSolDate] = useState('');

  if (!isOpen) return null;

  // Run live conflict check against proposed adverse entity
  const adverseConflict = opposingParty.trim() ? runConflictCheck(opposingParty) : null;
  const clientConflict = clientName.trim() ? runConflictCheck(clientName) : null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !clientName.trim()) return;

    const newM = addMatter({
      title: title.trim(),
      clientId: `cli-${Date.now()}`,
      clientName: clientName.trim(),
      clientEmail: clientEmail.trim() || `${clientName.toLowerCase().replace(/\s+/g, '')}@client.com`,
      clientPhone: clientPhone.trim() || '(555) 012-3456',
      practiceArea,
      status: 'Intake',
      billingModel,
      defaultRate: parseFloat(defaultRate) || 600,
      leadAttorney,
      responsibleStaff: ['Marcus Wright (Associate)'],
      opposingParty: opposingParty.trim() || undefined,
      opposingCounsel: opposingCounsel.trim() || undefined,
      courtOrJurisdiction: courtOrJurisdiction.trim() || undefined,
      docketNumber: docketNumber.trim() || undefined,
      openDate: new Date().toISOString().split('T')[0],
      statuteOfLimitationsDate: solDate || undefined
    });

    setSelectedMatterId(newM.id);
    setActiveView('matters');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
      <div className="w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 bg-slate-900 text-white">
          <div className="flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-bold">New Client Matter Intake & Conflict Screening</h2>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto flex-1 space-y-4 text-xs">
          {/* Conflict Scanner Warning if adverse match detected */}
          {adverseConflict && adverseConflict.matchFound && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-lg flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-rose-900 block">
                  Ethical Conflict Alert: "{opposingParty}" already exists in firm records!
                </span>
                <span className="text-rose-700 text-[11px] block mt-0.5">
                  Matched in {adverseConflict.hits[0]?.matterNumber} ({adverseConflict.hits[0]?.matterTitle}). Verify ethics wall before proceeding with intake.
                </span>
              </div>
            </div>
          )}

          {/* Section 1: Matter Identification */}
          <div className="space-y-3">
            <h3 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] border-b pb-1">
              1. Matter Identification & Scope
            </h3>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Matter Title / Case Caption *</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="E.g., Quantum Robotics v. Terabyte Capital Corp."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Practice Area *</label>
                <select
                  value={practiceArea}
                  onChange={(e) => setPracticeArea(e.target.value as PracticeArea)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
                >
                  <option value="Commercial Litigation">Commercial Litigation</option>
                  <option value="Corporate & M&A">Corporate & M&A</option>
                  <option value="Intellectual Property">Intellectual Property</option>
                  <option value="Employment & Labor">Employment & Labor</option>
                  <option value="Estate & Trusts">Estate & Trusts</option>
                  <option value="Real Estate">Real Estate</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Lead Responsible Counsel *</label>
                <select
                  value={leadAttorney}
                  onChange={(e) => setLeadAttorney(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
                >
                  <option value="Victoria Vance, Esq.">Victoria Vance, Esq. (Partner)</option>
                  <option value="Julian Davenport, Esq.">Julian Davenport, Esq. (Managing Partner)</option>
                  <option value="Sarah Chen (Senior Associate)">Sarah Chen (Senior Associate)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 2: Client Profile */}
          <div className="space-y-3 pt-2">
            <h3 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] border-b pb-1">
              2. Client Profile
            </h3>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Client Entity / Individual *</label>
                <input
                  type="text"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="e.g. Apex Biotech Inc."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
                  required
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Email Address</label>
                <input
                  type="email"
                  value={clientEmail}
                  onChange={(e) => setClientEmail(e.target.value)}
                  placeholder="legal@client.com"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Phone Number</label>
                <input
                  type="tel"
                  value={clientPhone}
                  onChange={(e) => setClientPhone(e.target.value)}
                  placeholder="(415) 555-0120"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Billing & Rates */}
          <div className="space-y-3 pt-2">
            <h3 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] border-b pb-1">
              3. Fee Structure & Hourly Rates
            </h3>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Billing Arrangement</label>
                <select
                  value={billingModel}
                  onChange={(e) => setBillingModel(e.target.value as BillingModel)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
                >
                  <option value="Hourly">Hourly (UTBMS Tenth-Hour Increments)</option>
                  <option value="Fixed Fee">Fixed Fee / Milestone</option>
                  <option value="Contingency">Contingency Fee</option>
                  <option value="Retainer">Monthly Retainer</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Default Rate ($/hr)</label>
                <input
                  type="number"
                  value={defaultRate}
                  onChange={(e) => setDefaultRate(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white font-mono-nums"
                  required
                />
              </div>
            </div>
          </div>

          {/* Section 4: Opposing Party & Court */}
          <div className="space-y-3 pt-2">
            <h3 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] border-b pb-1">
              4. Adverse Parties & Statutory Deadlines
            </h3>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Opposing / Adverse Entity</label>
                <input
                  type="text"
                  value={opposingParty}
                  onChange={(e) => setOpposingParty(e.target.value)}
                  placeholder="e.g. Defendant or counter-party name"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Opposing Counsel / Law Firm</label>
                <input
                  type="text"
                  value={opposingCounsel}
                  onChange={(e) => setOpposingCounsel(e.target.value)}
                  placeholder="e.g. Latham & Watkins LLP"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Court / Forum</label>
                <input
                  type="text"
                  value={courtOrJurisdiction}
                  onChange={(e) => setCourtOrJurisdiction(e.target.value)}
                  placeholder="e.g. Delaware Chancery Court"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Docket Number</label>
                <input
                  type="text"
                  value={docketNumber}
                  onChange={(e) => setDocketNumber(e.target.value)}
                  placeholder="e.g. 24-CV-10928"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white font-mono"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Statute of Limitations (SOL)</label>
                <input
                  type="date"
                  value={solDate}
                  onChange={(e) => setSolDate(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-sm"
            >
              Open Matter File
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
