import React, { useState, useEffect } from 'react';
import { usePractice } from '../../context/PracticeContext';
import { Search, Briefcase, FileText, Receipt, ShieldAlert, Clock, X, Scale } from 'lucide-react';

interface CommandPaletteProps {
  onOpenNewMatter: () => void;
  onOpenNewTime: () => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({ onOpenNewMatter, onOpenNewTime }) => {
  const {
    isCommandPaletteOpen,
    setIsCommandPaletteOpen,
    matters,
    invoices,
    generatedDocs,
    setActiveView,
    setSelectedMatterId
  } = usePractice();

  const [query, setQuery] = useState('');

  // Keyboard shortcut listener for Cmd+K / Ctrl+K and Esc
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen(!isCommandPaletteOpen);
      }
      if (e.key === 'Escape' && isCommandPaletteOpen) {
        setIsCommandPaletteOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isCommandPaletteOpen, setIsCommandPaletteOpen]);

  if (!isCommandPaletteOpen) return null;

  const cleanQ = query.trim().toLowerCase();

  // Search Results
  const matchedMatters = matters.filter(m => 
    !cleanQ || 
    m.matterNumber.toLowerCase().includes(cleanQ) || 
    m.title.toLowerCase().includes(cleanQ) || 
    m.clientName.toLowerCase().includes(cleanQ) ||
    (m.opposingParty && m.opposingParty.toLowerCase().includes(cleanQ))
  ).slice(0, 5);

  const matchedInvoices = invoices.filter(inv =>
    !cleanQ ||
    inv.invoiceNumber.toLowerCase().includes(cleanQ) ||
    inv.clientName.toLowerCase().includes(cleanQ) ||
    inv.matterNumber.toLowerCase().includes(cleanQ)
  ).slice(0, 3);

  const matchedDocs = generatedDocs.filter(d =>
    !cleanQ ||
    d.title.toLowerCase().includes(cleanQ) ||
    d.templateTitle.toLowerCase().includes(cleanQ)
  ).slice(0, 3);

  const handleSelectMatter = (matterId: string) => {
    setSelectedMatterId(matterId);
    setActiveView('matters');
    setIsCommandPaletteOpen(false);
  };

  const handleSelectInvoice = () => {
    setActiveView('invoices');
    setIsCommandPaletteOpen(false);
  };

  const handleSelectDocs = () => {
    setActiveView('documents');
    setIsCommandPaletteOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 bg-slate-950/60 backdrop-blur-xs p-4">
      <div 
        className="w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3.5 border-b border-slate-200 bg-slate-50/50">
          <Search className="w-5 h-5 text-slate-400 mr-3" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search matters, clients, opposing parties, invoices, documents..."
            className="w-full text-sm bg-transparent placeholder-slate-400 text-slate-900 focus:outline-none"
            autoFocus
          />
          <button
            onClick={() => setIsCommandPaletteOpen(false)}
            className="p-1 text-slate-400 hover:text-slate-600 rounded transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Actions Shortcuts */}
        <div className="px-4 py-2 bg-slate-50 border-b border-slate-200/80 flex items-center gap-2 overflow-x-auto text-xs">
          <span className="text-slate-400 font-medium">Quick:</span>
          <button
            onClick={() => {
              setIsCommandPaletteOpen(false);
              onOpenNewTime();
            }}
            className="flex items-center gap-1 px-2.5 py-1 bg-white hover:bg-slate-100 border border-slate-200 rounded text-slate-700 font-medium transition-colors"
          >
            <Clock className="w-3 h-3 text-amber-600" />
            <span>Log Time</span>
          </button>
          <button
            onClick={() => {
              setIsCommandPaletteOpen(false);
              onOpenNewMatter();
            }}
            className="flex items-center gap-1 px-2.5 py-1 bg-white hover:bg-slate-100 border border-slate-200 rounded text-slate-700 font-medium transition-colors"
          >
            <Briefcase className="w-3 h-3 text-blue-600" />
            <span>New Matter</span>
          </button>
          <button
            onClick={() => {
              setIsCommandPaletteOpen(false);
              setActiveView('conflicts');
            }}
            className="flex items-center gap-1 px-2.5 py-1 bg-white hover:bg-slate-100 border border-slate-200 rounded text-slate-700 font-medium transition-colors"
          >
            <ShieldAlert className="w-3 h-3 text-rose-600" />
            <span>Conflict Check</span>
          </button>
          <button
            onClick={() => {
              setIsCommandPaletteOpen(false);
              setActiveView('trust');
            }}
            className="flex items-center gap-1 px-2.5 py-1 bg-white hover:bg-slate-100 border border-slate-200 rounded text-slate-700 font-medium transition-colors"
          >
            <Scale className="w-3 h-3 text-emerald-600" />
            <span>IOLTA Reconciliation</span>
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto p-2 space-y-3">
          {/* Matters */}
          {matchedMatters.length > 0 && (
            <div>
              <div className="px-3 py-1 text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
                Active Matters
              </div>
              <div className="space-y-0.5">
                {matchedMatters.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => handleSelectMatter(m.id)}
                    className="w-full flex items-center justify-between px-3 py-2 text-left rounded-lg hover:bg-slate-100 transition-colors group"
                  >
                    <div className="flex items-center gap-3">
                      <Briefcase className="w-4 h-4 text-slate-400 group-hover:text-slate-900" />
                      <div>
                        <div className="text-xs font-semibold text-slate-900 group-hover:text-blue-900">
                          {m.matterNumber}: {m.title}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {m.clientName} · {m.practiceArea}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-[11px] font-mono-nums text-slate-600">
                        ${m.trustBalance.toLocaleString()} Trust
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Invoices */}
          {matchedInvoices.length > 0 && (
            <div>
              <div className="px-3 py-1 text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
                Invoices & Statements
              </div>
              <div className="space-y-0.5">
                {matchedInvoices.map((inv) => (
                  <button
                    key={inv.id}
                    onClick={handleSelectInvoice}
                    className="w-full flex items-center justify-between px-3 py-2 text-left rounded-lg hover:bg-slate-100 transition-colors group"
                  >
                    <div className="flex items-center gap-3">
                      <Receipt className="w-4 h-4 text-slate-400 group-hover:text-slate-900" />
                      <div>
                        <div className="text-xs font-semibold text-slate-900">
                          {inv.invoiceNumber} — {inv.clientName}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          Due: {inv.dueDate} · Status: {inv.status}
                        </div>
                      </div>
                    </div>
                    <div className="text-right font-mono-nums text-xs font-semibold text-slate-900">
                      ${inv.total.toLocaleString()}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Documents */}
          {matchedDocs.length > 0 && (
            <div>
              <div className="px-3 py-1 text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
                Legal Documents & Contracts
              </div>
              <div className="space-y-0.5">
                {matchedDocs.map((doc) => (
                  <button
                    key={doc.id}
                    onClick={handleSelectDocs}
                    className="w-full flex items-center justify-between px-3 py-2 text-left rounded-lg hover:bg-slate-100 transition-colors group"
                  >
                    <div className="flex items-center gap-3">
                      <FileText className="w-4 h-4 text-slate-400 group-hover:text-slate-900" />
                      <div>
                        <div className="text-xs font-semibold text-slate-900">
                          {doc.title}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {doc.templateTitle} · {doc.status}
                        </div>
                      </div>
                    </div>
                    <span className="text-[11px] text-slate-400">{doc.lastModified}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {matchedMatters.length === 0 && matchedInvoices.length === 0 && matchedDocs.length === 0 && (
            <div className="p-8 text-center text-slate-500 text-xs">
              No matching matters, invoices, or documents found for "{query}".
            </div>
          )}
        </div>

        <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-200 text-[11px] text-slate-500 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span>Navigation: <kbd className="px-1.5 py-0.5 bg-white border border-slate-200 rounded font-mono">↑</kbd> <kbd className="px-1.5 py-0.5 bg-white border border-slate-200 rounded font-mono">↓</kbd></span>
            <span>Select: <kbd className="px-1.5 py-0.5 bg-white border border-slate-200 rounded font-mono">↵</kbd></span>
            <span>Close: <kbd className="px-1.5 py-0.5 bg-white border border-slate-200 rounded font-mono">Esc</kbd></span>
          </div>
          <span>Jurisdiction: Federal & State practice</span>
        </div>
      </div>
    </div>
  );
};
