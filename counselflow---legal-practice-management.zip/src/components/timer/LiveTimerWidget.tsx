import React from 'react';
import { usePractice } from '../../context/PracticeContext';
import { formatDuration } from '../../utils/formatters';
import { UTBMS_CODES } from '../../data/mockData';
import { Play, Pause, RotateCcw, Check, X, Clock } from 'lucide-react';

interface LiveTimerWidgetProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LiveTimerWidget: React.FC<LiveTimerWidgetProps> = ({ isOpen, onClose }) => {
  const { 
    activeTimer, 
    startTimer, 
    pauseTimer, 
    resetTimer, 
    updateTimerState, 
    commitTimerToEntry,
    matters 
  } = usePractice();

  if (!isOpen) return null;

  const currentMatter = matters.find(m => m.id === activeTimer.matterId) || matters[0];

  // Calculate billable estimate
  const rawHours = activeTimer.seconds / 3600;
  const billedHours = activeTimer.roundToTenth 
    ? Math.max(0.1, Math.ceil(rawHours * 10) / 10) 
    : Math.round(rawHours * 100) / 100;
  const currentRate = activeTimer.rate || currentMatter?.defaultRate || 650;
  const billableAmount = billedHours * currentRate;

  const handleSave = () => {
    if (activeTimer.seconds <= 0) return;
    const entry = commitTimerToEntry();
    if (entry) {
      onClose();
    }
  };

  return (
    <div className="fixed bottom-4 right-6 z-40 w-96 bg-white border border-slate-200 rounded-xl shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-200">
      {/* Timer Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-900 text-white">
        <div className="flex items-center gap-2">
          <Clock className={`w-4 h-4 ${activeTimer.isRunning ? 'text-amber-400 animate-pulse' : 'text-slate-400'}`} />
          <span className="text-sm font-semibold tracking-wide">Live Billable Timer</span>
        </div>
        <button 
          onClick={onClose} 
          className="text-slate-400 hover:text-white p-1 rounded transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-4">
        {/* Stopwatch Display */}
        <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200/70 rounded-lg">
          <div>
            <div className="text-3xl font-mono-nums font-semibold tracking-tight text-slate-900">
              {formatDuration(activeTimer.seconds)}
            </div>
            <div className="text-xs text-slate-500 mt-0.5">
              <span>{billedHours.toFixed(1)} hrs</span>
              <span className="mx-1.5" aria-hidden="true">·</span>
              <span className="font-mono-nums font-medium text-slate-700">${billableAmount.toFixed(2)}</span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-1.5">
            {activeTimer.isRunning ? (
              <button
                onClick={pauseTimer}
                className="p-2.5 bg-amber-500 text-slate-950 hover:bg-amber-400 rounded-lg transition-colors shadow-sm"
                title="Pause"
              >
                <Pause className="w-4 h-4 fill-current" />
              </button>
            ) : (
              <button
                onClick={() => startTimer()}
                className="p-2.5 bg-slate-900 text-white hover:bg-slate-800 rounded-lg transition-colors shadow-sm"
                title="Start"
              >
                <Play className="w-4 h-4 fill-current" />
              </button>
            )}
            <button
              onClick={resetTimer}
              className="p-2.5 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
              title="Reset"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Matter Selection */}
        <div>
          <label className="block text-xs font-medium text-slate-700 mb-1">
            Target Matter
          </label>
          <select
            value={activeTimer.matterId}
            onChange={(e) => {
              const mId = e.target.value;
              const selectedM = matters.find(m => m.id === mId);
              updateTimerState({
                matterId: mId,
                rate: selectedM ? selectedM.defaultRate : activeTimer.rate,
                attorneyName: selectedM ? selectedM.leadAttorney : activeTimer.attorneyName
              });
            }}
            className="w-full text-xs bg-white border border-slate-300 rounded-md px-2.5 py-2 text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900"
          >
            {matters.map(m => (
              <option key={m.id} value={m.id}>
                {m.matterNumber} - {m.title}
              </option>
            ))}
          </select>
        </div>

        {/* UTBMS Task Code */}
        <div>
          <label className="block text-xs font-medium text-slate-700 mb-1">
            UTBMS Task Code
          </label>
          <select
            value={activeTimer.utbmsCode}
            onChange={(e) => updateTimerState({ utbmsCode: e.target.value })}
            className="w-full text-xs bg-white border border-slate-300 rounded-md px-2.5 py-2 text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900"
          >
            {UTBMS_CODES.map(c => (
              <option key={c.code} value={`${c.code} - ${c.description}`}>
                {c.code} - {c.description} ({c.category})
              </option>
            ))}
          </select>
        </div>

        {/* Description */}
        <div>
          <label className="block text-xs font-medium text-slate-700 mb-1">
            Activity Notes / Description
          </label>
          <textarea
            value={activeTimer.description}
            onChange={(e) => updateTimerState({ description: e.target.value })}
            placeholder="E.g., Review opposing counsel motion to compel; telephone conference with client..."
            rows={2}
            className="w-full text-xs bg-white border border-slate-300 rounded-md p-2.5 text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-slate-900 resize-none"
          />
        </div>

        {/* 0.1h increment toggle */}
        <div className="flex items-center justify-between pt-1 border-t border-slate-100">
          <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-600">
            <input
              type="checkbox"
              checked={activeTimer.roundToTenth}
              onChange={(e) => updateTimerState({ roundToTenth: e.target.checked })}
              className="rounded border-slate-300 text-slate-900 focus:ring-slate-900"
            />
            <span>Round to 0.1h (6 min) increment</span>
          </label>
          <span className="text-[11px] font-mono-nums text-slate-500">${currentRate}/hr</span>
        </div>

        {/* Save Button */}
        <button
          onClick={handleSave}
          disabled={activeTimer.seconds <= 0}
          className="w-full flex items-center justify-center gap-2 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition-colors"
        >
          <Check className="w-4 h-4" />
          <span>Save to Unbilled WIP</span>
        </button>
      </div>
    </div>
  );
};
