import React, { useState } from 'react';
import { usePractice } from '../../context/PracticeContext';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { 
  Scale, 
  ShieldCheck, 
  AlertOctagon, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Plus, 
  FileCheck2, 
  CheckCircle2, 
  AlertCircle,
  Building,
  UserCheck
} from 'lucide-react';
import { TrustTransaction } from '../../types';

export const TrustAccountingView: React.FC = () => {
  const { 
    matters, 
    trustTransactions, 
    reconciliation, 
    addTrustTransaction, 
    runThreeWayReconciliation,
    totalTrustBalance 
  } = usePractice();

  // Modals state
  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
  const [isReconModalOpen, setIsReconModalOpen] = useState(false);
  const [selectedMatterFilter, setSelectedMatterFilter] = useState<string>('all');
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // New Transaction Form State
  const [newTxMatterId, setNewTxMatterId] = useState(matters[0]?.id || '');
  const [newTxType, setNewTxType] = useState<'Deposit' | 'Disbursement'>('Deposit');
  const [newTxAmount, setNewTxAmount] = useState('');
  const [newTxMethod, setNewTxMethod] = useState<TrustTransaction['paymentMethod']>('Wire');
  const [newTxRef, setNewTxRef] = useState('');
  const [newTxPurpose, setNewTxPurpose] = useState('');
  const [newTxAuth, setNewTxAuth] = useState('Victoria Vance, Esq.');

  // Reconciliation Modal Form State
  const [reconBankBalance, setReconBankBalance] = useState(String(reconciliation.bankStatementEndingBalance));
  const [reconNotes, setReconNotes] = useState(reconciliation.notes);

  const filteredTransactions = selectedMatterFilter === 'all'
    ? trustTransactions
    : trustTransactions.filter(t => t.matterId === selectedMatterFilter);

  const handleCreateTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(newTxAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      setNotification({ type: 'error', message: 'Please enter a valid amount greater than $0.' });
      return;
    }
    if (!newTxRef.trim()) {
      setNotification({ type: 'error', message: 'Reference number / Check number is required for IOLTA compliance.' });
      return;
    }
    if (!newTxPurpose.trim()) {
      setNotification({ type: 'error', message: 'An explanation/purpose is mandatory under State Bar trust rules.' });
      return;
    }

    const res = addTrustTransaction({
      matterId: newTxMatterId,
      type: newTxType,
      amount: amountNum,
      paymentMethod: newTxMethod,
      referenceNumber: newTxRef.trim(),
      explanationPurpose: newTxPurpose.trim(),
      authorizedBy: newTxAuth
    });

    if (res.success) {
      setNotification({ type: 'success', message: res.message });
      setIsDepositModalOpen(false);
      setNewTxAmount('');
      setNewTxRef('');
      setNewTxPurpose('');
    } else {
      setNotification({ type: 'error', message: res.message });
    }
  };

  const handlePerformReconciliation = (e: React.FormEvent) => {
    e.preventDefault();
    const bankVal = parseFloat(reconBankBalance);
    if (isNaN(bankVal)) {
      setNotification({ type: 'error', message: 'Please enter a valid bank balance.' });
      return;
    }
    const updatedRecord = runThreeWayReconciliation(bankVal, reconNotes);
    setIsReconModalOpen(false);
    if (updatedRecord.status === 'Balanced') {
      setNotification({ type: 'success', message: 'IOLTA 3-Way Reconciliation verified: $0.00 variance across all client sub-accounts.' });
    } else {
      setNotification({ type: 'error', message: `Audit Discrepancy detected: Variance of $${updatedRecord.variance.toFixed(2)} between bank and client books.` });
    }
  };

  const isBalanced = reconciliation.status === 'Balanced' && Math.abs(reconciliation.variance) < 0.01;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Scale className="w-5 h-5 text-amber-600" />
            <span>IOLTA Trust Accounting & 3-Way Reconciliation</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Interest on Lawyers' Trust Accounts (IOLTA) escrow ledger with strict individual client segregation and zero commingling.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setIsReconModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors shadow-xs"
          >
            <FileCheck2 className="w-3.5 h-3.5 text-blue-600" />
            <span>Run 3-Way Audit</span>
          </button>

          <button
            onClick={() => setIsDepositModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Trust Transaction</span>
          </button>
        </div>
      </div>

      {/* Notification Toast */}
      {notification && (
        <div className={`p-3.5 rounded-lg flex items-center justify-between text-xs font-medium ${
          notification.type === 'success' 
            ? 'bg-emerald-50 text-emerald-900 border border-emerald-200' 
            : 'bg-rose-50 text-rose-900 border border-rose-200'
        }`}>
          <div className="flex items-center gap-2">
            {notification.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{notification.message}</span>
          </div>
          <button 
            onClick={() => setNotification(null)}
            className="text-slate-400 hover:text-slate-600 ml-4 font-bold"
          >
            ✕
          </button>
        </div>
      )}

      {/* IOLTA Three-Way Reconciliation Status Card */}
      <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-xs">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold tracking-wide text-slate-500 uppercase">
              Three-Way Reconciliation Status
            </span>
            <span className="text-xs text-slate-400 font-mono-nums">
              ({reconciliation.reconciliationDate})
            </span>
          </div>

          {/* Compliance Status Badge */}
          <div className="flex items-center gap-1.5">
            {isBalanced ? (
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-md text-xs font-semibold">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>IOLTA Compliant — $0.00 Variance</span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-rose-50 border border-rose-200 text-rose-800 rounded-md text-xs font-semibold">
                <AlertOctagon className="w-4 h-4 text-rose-600" />
                <span>Discrepancy: ${reconciliation.variance.toFixed(2)}</span>
              </div>
            )}
          </div>
        </div>

        {/* 3 Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
          {/* Pillar 1: Bank Statement */}
          <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-lg">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
              <span>1. Bank Escrow Statement</span>
              <Building className="w-3.5 h-3.5 text-slate-400" />
            </div>
            <div className="text-xl font-bold font-mono-nums text-slate-900">
              {formatCurrency(reconciliation.bankStatementEndingBalance)}
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              JPMorgan / First Republic Escrow Account #8812
            </div>
          </div>

          {/* Pillar 2: General Trust Book Balance */}
          <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-lg">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
              <span>2. Trust Book General Ledger</span>
              <Scale className="w-3.5 h-3.5 text-slate-400" />
            </div>
            <div className="text-xl font-bold font-mono-nums text-slate-900">
              {formatCurrency(reconciliation.generalTrustBookBalance)}
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              Net balance of all deposits & disbursements
            </div>
          </div>

          {/* Pillar 3: Sum of Individual Client Ledgers */}
          <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-lg">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
              <span>3. Sum of Client Sub-Ledgers</span>
              <UserCheck className="w-3.5 h-3.5 text-slate-400" />
            </div>
            <div className="text-xl font-bold font-mono-nums text-slate-900">
              {formatCurrency(reconciliation.clientLedgersSum)}
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              {matters.length} distinct client matter trust accounts
            </div>
          </div>
        </div>

        {/* Audit Notes */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between text-xs text-slate-500 gap-2">
          <div>
            <span className="font-semibold text-slate-700">Audit Examiner:</span> {reconciliation.reviewedBy}
          </div>
          <div className="text-slate-600 italic">
            "{reconciliation.notes}"
          </div>
        </div>
      </div>

      {/* Individual Client Sub-Accounts Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900">
              Individual Client Trust Sub-Ledgers
            </h2>
            <p className="text-xs text-slate-500">
              State Bar ethics rules strictly prohibit commingling or applying Client A's funds toward Client B's expenses.
            </p>
          </div>
          <span className="text-xs font-mono-nums text-slate-700 font-semibold">
            Total in Escrow: {formatCurrency(totalTrustBalance)}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-200 text-slate-500 font-medium">
                <th className="py-2.5 px-4">Matter #</th>
                <th className="py-2.5 px-4">Client / Matter Scope</th>
                <th className="py-2.5 px-4">Lead Attorney</th>
                <th className="py-2.5 px-4">Billing Model</th>
                <th className="py-2.5 px-4 text-right">Available Trust Balance</th>
                <th className="py-2.5 px-4 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {matters.map((matter) => (
                <tr key={matter.id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3 px-4 font-mono-nums font-semibold text-slate-900">
                    {matter.matterNumber}
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-medium text-slate-900">{matter.clientName}</div>
                    <div className="text-slate-500 text-[11px] truncate max-w-xs">{matter.title}</div>
                  </td>
                  <td className="py-3 px-4 text-slate-600">
                    {matter.leadAttorney}
                  </td>
                  <td className="py-3 px-4 text-slate-600">
                    {matter.billingModel}
                  </td>
                  <td className="py-3 px-4 text-right font-mono-nums font-bold text-slate-900">
                    {formatCurrency(matter.trustBalance)}
                  </td>
                  <td className="py-3 px-4 text-center">
                    {matter.trustBalance > 0 ? (
                      <span className="text-[11px] text-emerald-700 font-medium">Funded</span>
                    ) : (
                      <span className="text-[11px] text-slate-400">Zero Balance</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Full Trust Transactions Journal / Audit Trail */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-bold text-slate-900">
              General Trust Journal & Audit Trail
            </h2>
            <p className="text-xs text-slate-500">
              All cleared deposits, retainer drawdowns, and disbursements.
            </p>
          </div>

          {/* Filter by Matter */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500">Filter Ledger:</span>
            <select
              value={selectedMatterFilter}
              onChange={(e) => setSelectedMatterFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-white border border-slate-300 rounded text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900"
            >
              <option value="all">All Matters ({trustTransactions.length})</option>
              {matters.map(m => (
                <option key={m.id} value={m.id}>
                  {m.matterNumber} - {m.clientName}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-200 text-slate-500 font-medium">
                <th className="py-2.5 px-4">Tx #</th>
                <th className="py-2.5 px-4">Date</th>
                <th className="py-2.5 px-4">Matter / Client</th>
                <th className="py-2.5 px-4">Type</th>
                <th className="py-2.5 px-4">Reference / Check #</th>
                <th className="py-2.5 px-4">Explanation & Purpose</th>
                <th className="py-2.5 px-4">Authorized By</th>
                <th className="py-2.5 px-4 text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTransactions.map((tx) => (
                <tr key={tx.id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3 px-4 font-mono-nums text-slate-500">
                    {tx.transactionNumber}
                  </td>
                  <td className="py-3 px-4 text-slate-600 whitespace-nowrap">
                    {formatDate(tx.date)}
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-slate-900">{tx.matterNumber}</div>
                    <div className="text-slate-500 text-[11px]">{tx.clientName}</div>
                  </td>
                  <td className="py-3 px-4">
                    {tx.type === 'Deposit' ? (
                      <span className="inline-flex items-center gap-1 text-emerald-700 font-medium">
                        <ArrowDownLeft className="w-3.5 h-3.5" />
                        Deposit
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-slate-700 font-medium">
                        <ArrowUpRight className="w-3.5 h-3.5 text-amber-600" />
                        Disbursement
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 font-mono-nums text-slate-700">
                    {tx.paymentMethod} · {tx.referenceNumber}
                  </td>
                  <td className="py-3 px-4 text-slate-700 max-w-sm truncate" title={tx.explanationPurpose}>
                    {tx.explanationPurpose}
                  </td>
                  <td className="py-3 px-4 text-slate-600 whitespace-nowrap">
                    {tx.authorizedBy}
                  </td>
                  <td className={`py-3 px-4 text-right font-mono-nums font-bold whitespace-nowrap ${
                    tx.type === 'Deposit' ? 'text-emerald-700' : 'text-slate-900'
                  }`}>
                    {tx.type === 'Deposit' ? '+' : '-'}{formatCurrency(tx.amount)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Trust Transaction Modal */}
      {isDepositModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white rounded-xl shadow-2xl p-6 border border-slate-200">
            <h3 className="text-base font-bold text-slate-900 mb-1 flex items-center gap-2">
              <Scale className="w-4 h-4 text-amber-600" />
              <span>Record IOLTA Trust Transaction</span>
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              All retainer deposits and fee disbursements are audited under State Bar IOLTA accounting rules.
            </p>

            <form onSubmit={handleCreateTransaction} className="space-y-4 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Target Client Matter *
                </label>
                <select
                  value={newTxMatterId}
                  onChange={(e) => setNewTxMatterId(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
                >
                  {matters.map(m => (
                    <option key={m.id} value={m.id}>
                      {m.matterNumber} - {m.clientName} (Current Trust: {formatCurrency(m.trustBalance)})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Transaction Type *
                  </label>
                  <select
                    value={newTxType}
                    onChange={(e) => setNewTxType(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
                  >
                    <option value="Deposit">Deposit (Retainer Influx)</option>
                    <option value="Disbursement">Disbursement (Fee / Expense Drawdown)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Amount ($ USD) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    value={newTxAmount}
                    onChange={(e) => setNewTxAmount(e.target.value)}
                    placeholder="e.g. 10000.00"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Payment Instrument *
                  </label>
                  <select
                    value={newTxMethod}
                    onChange={(e) => setNewTxMethod(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white"
                  >
                    <option value="Wire">Wire Transfer</option>
                    <option value="Check">Client / Trust Check</option>
                    <option value="ACH">Direct ACH / Electronic</option>
                    <option value="Trust Transfer">Internal Trust Transfer</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Check / Wire Reference Number *
                  </label>
                  <input
                    type="text"
                    value={newTxRef}
                    onChange={(e) => setNewTxRef(e.target.value)}
                    placeholder="e.g. WIRE-88129 or CHK-5102"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Purpose / Explanation (Mandatory IOLTA Record) *
                </label>
                <textarea
                  value={newTxPurpose}
                  onChange={(e) => setNewTxPurpose(e.target.value)}
                  placeholder="E.g., Advance litigation retainer deposit pursuant to Engagement Agreement..."
                  rows={2}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 resize-none"
                  required
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Authorizing Attorney
                </label>
                <input
                  type="text"
                  value={newTxAuth}
                  onChange={(e) => setNewTxAuth(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
                  required
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsDepositModalOpen(false)}
                  className="px-4 py-2 font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
                >
                  Post Transaction to Ledger
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 3-Way Reconciliation Audit Modal */}
      {isReconModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white rounded-xl shadow-2xl p-6 border border-slate-200">
            <h3 className="text-base font-bold text-slate-900 mb-1 flex items-center gap-2">
              <FileCheck2 className="w-4 h-4 text-blue-600" />
              <span>Execute 3-Way Reconciliation Audit</span>
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Compares your bank escrow statement against the firm general trust ledger and individual client sub-accounts.
            </p>

            <form onSubmit={handlePerformReconciliation} className="space-y-4 text-xs">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-1.5">
                <div className="flex justify-between text-slate-600">
                  <span>Current Client Sub-Accounts Total:</span>
                  <span className="font-mono-nums font-bold text-slate-900">{formatCurrency(totalTrustBalance)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>General Trust Book Balance:</span>
                  <span className="font-mono-nums font-bold text-slate-900">{formatCurrency(totalTrustBalance)}</span>
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Bank Statement Ending Balance ($ USD) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={reconBankBalance}
                  onChange={(e) => setReconBankBalance(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono-nums text-sm font-semibold"
                  required
                />
                <span className="text-[11px] text-slate-400 mt-1 block">
                  Match with the ending figure on your monthly escrow account statement.
                </span>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Audit Notes & Reconciliation Memorandum
                </label>
                <textarea
                  value={reconNotes}
                  onChange={(e) => setReconNotes(e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 resize-none"
                  placeholder="Enter audit verification details..."
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsReconModalOpen(false)}
                  className="px-4 py-2 font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Close
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors"
                >
                  Verify & Sign Audit Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
