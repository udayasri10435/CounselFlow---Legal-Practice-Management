import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { 
  Matter, 
  TimeEntry, 
  Invoice, 
  TrustTransaction, 
  ReconciliationRecord, 
  DocumentTemplate, 
  GeneratedDocument,
  ConflictResult,
  MatterNote,
  MatterTask
} from '../types';
import { 
  INITIAL_MATTERS, 
  INITIAL_TIME_ENTRIES, 
  INITIAL_INVOICES, 
  INITIAL_TRUST_TRANSACTIONS, 
  INITIAL_RECONCILIATION, 
  DOCUMENT_TEMPLATES, 
  INITIAL_GENERATED_DOCS,
  UTBMS_CODES
} from '../data/mockData';

export interface ActiveTimerState {
  isRunning: boolean;
  seconds: number;
  matterId: string;
  description: string;
  utbmsCode: string;
  rate: number;
  attorneyName: string;
  roundToTenth: boolean;
}

interface PracticeContextType {
  // Navigation
  activeView: 'dashboard' | 'matters' | 'billing' | 'invoices' | 'trust' | 'documents' | 'conflicts';
  setActiveView: (view: 'dashboard' | 'matters' | 'billing' | 'invoices' | 'trust' | 'documents' | 'conflicts') => void;
  selectedMatterId: string | null;
  setSelectedMatterId: (id: string | null) => void;
  isCommandPaletteOpen: boolean;
  setIsCommandPaletteOpen: (open: boolean) => void;

  // Matters
  matters: Matter[];
  addMatter: (matter: Omit<Matter, 'id' | 'matterNumber' | 'trustBalance' | 'notes' | 'tasks'>) => Matter;
  updateMatter: (id: string, updates: Partial<Matter>) => void;
  deleteMatter: (id: string) => void;
  addMatterNote: (matterId: string, text: string, category: MatterNote['category']) => void;
  toggleMatterTask: (matterId: string, taskId: string) => void;
  addMatterTask: (matterId: string, title: string, dueDate: string, priority: MatterTask['priority'], isCourtDeadline?: boolean) => void;

  // Time & Timer
  timeEntries: TimeEntry[];
  activeTimer: ActiveTimerState;
  startTimer: (matterId?: string) => void;
  pauseTimer: () => void;
  resetTimer: () => void;
  updateTimerState: (updates: Partial<ActiveTimerState>) => void;
  commitTimerToEntry: () => TimeEntry | null;
  addTimeEntry: (entry: Omit<TimeEntry, 'id' | 'status'>) => TimeEntry;
  updateTimeEntry: (id: string, updates: Partial<TimeEntry>) => void;
  deleteTimeEntry: (id: string) => void;

  // Invoices & Billing
  invoices: Invoice[];
  createInvoice: (params: { matterId: string; lineItemIds: string[]; dueDate: string; notes?: string; discount?: number }) => Invoice;
  payInvoiceFromTrust: (invoiceId: string, amount: number) => { success: boolean; message: string };
  recordManualPayment: (invoiceId: string, amount: number, method: Invoice['payments'][0]['method'], reference: string) => void;
  updateInvoiceStatus: (invoiceId: string, status: Invoice['status']) => void;

  // Trust Accounting & Reconciliation
  trustTransactions: TrustTransaction[];
  reconciliation: ReconciliationRecord;
  addTrustTransaction: (params: {
    matterId: string;
    type: 'Deposit' | 'Disbursement';
    amount: number;
    paymentMethod: TrustTransaction['paymentMethod'];
    referenceNumber: string;
    explanationPurpose: string;
    authorizedBy: string;
    invoiceId?: string;
  }) => { success: boolean; message: string; transaction?: TrustTransaction };
  runThreeWayReconciliation: (bankStatementEndingBalance: number, notes?: string) => ReconciliationRecord;

  // Documents
  templates: DocumentTemplate[];
  generatedDocs: GeneratedDocument[];
  generateDocument: (params: {
    templateId: string;
    matterId: string;
    title: string;
    variableValues: Record<string, string>;
    selectedClauseIds: string[];
  }) => GeneratedDocument;
  updateGeneratedDoc: (id: string, updates: Partial<GeneratedDocument>) => void;
  deleteGeneratedDoc: (id: string) => void;

  // Conflict Checking
  runConflictCheck: (query: string) => ConflictResult;

  // Quick stats
  totalTrustBalance: number;
  totalUnbilledWIP: number;
  totalUnpaidInvoices: number;
  activeMattersCount: number;
}

const PracticeContext = createContext<PracticeContextType | undefined>(undefined);

const STORAGE_KEYS = {
  MATTERS: 'counsel_matters_v1',
  TIME: 'counsel_time_entries_v1',
  INVOICES: 'counsel_invoices_v1',
  TRUST: 'counsel_trust_tx_v1',
  RECON: 'counsel_reconciliation_v1',
  DOCS: 'counsel_generated_docs_v1',
  TEMPLATES: 'counsel_templates_v1',
  TIMER: 'counsel_active_timer_v1'
};

export const PracticeProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Navigation State
  const [activeView, setActiveView] = useState<'dashboard' | 'matters' | 'billing' | 'invoices' | 'trust' | 'documents' | 'conflicts'>('dashboard');
  const [selectedMatterId, setSelectedMatterId] = useState<string | null>(null);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);

  // Matters State
  const [matters, setMatters] = useState<Matter[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MATTERS);
    return saved ? JSON.parse(saved) : INITIAL_MATTERS;
  });

  // Time Entries State
  const [timeEntries, setTimeEntries] = useState<TimeEntry[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.TIME);
    return saved ? JSON.parse(saved) : INITIAL_TIME_ENTRIES;
  });

  // Invoices State
  const [invoices, setInvoices] = useState<Invoice[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.INVOICES);
    return saved ? JSON.parse(saved) : INITIAL_INVOICES;
  });

  // Trust Transactions State
  const [trustTransactions, setTrustTransactions] = useState<TrustTransaction[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.TRUST);
    return saved ? JSON.parse(saved) : INITIAL_TRUST_TRANSACTIONS;
  });

  // 3-Way Reconciliation Record
  const [reconciliation, setReconciliation] = useState<ReconciliationRecord>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.RECON);
    return saved ? JSON.parse(saved) : INITIAL_RECONCILIATION;
  });

  // Document Templates State
  const [templates] = useState<DocumentTemplate[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.TEMPLATES);
    return saved ? JSON.parse(saved) : DOCUMENT_TEMPLATES;
  });

  // Generated Documents State
  const [generatedDocs, setGeneratedDocs] = useState<GeneratedDocument[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.DOCS);
    return saved ? JSON.parse(saved) : INITIAL_GENERATED_DOCS;
  });

  // Active Live Timer State
  const [activeTimer, setActiveTimer] = useState<ActiveTimerState>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.TIMER);
    return saved ? JSON.parse(saved) : {
      isRunning: false,
      seconds: 0,
      matterId: 'mat-1',
      description: '',
      utbmsCode: 'L120 - Analysis / Strategy Formulation',
      rate: 675,
      attorneyName: 'Victoria Vance, Esq.',
      roundToTenth: true
    };
  });

  // Persist State to LocalStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MATTERS, JSON.stringify(matters));
  }, [matters]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TIME, JSON.stringify(timeEntries));
  }, [timeEntries]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(invoices));
  }, [invoices]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TRUST, JSON.stringify(trustTransactions));
  }, [trustTransactions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.RECON, JSON.stringify(reconciliation));
  }, [reconciliation]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.DOCS, JSON.stringify(generatedDocs));
  }, [generatedDocs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TIMER, JSON.stringify(activeTimer));
  }, [activeTimer]);

  // Live Timer Interval
  useEffect(() => {
    let interval: any = null;
    if (activeTimer.isRunning) {
      interval = setInterval(() => {
        setActiveTimer(prev => ({
          ...prev,
          seconds: prev.seconds + 1
        }));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [activeTimer.isRunning]);

  // Recalculate 3-way reconciliation when trust data changes
  const refreshReconciliation = (updatedMatters: Matter[], currentStatementBalance?: number) => {
    const clientSum = updatedMatters.reduce((acc, m) => acc + (m.trustBalance || 0), 0);
    const bankBal = currentStatementBalance !== undefined ? currentStatementBalance : reconciliation.bankStatementEndingBalance;
    const diff = Math.abs(bankBal - clientSum);
    const isBalanced = diff < 0.01;

    const newRecon: ReconciliationRecord = {
      ...reconciliation,
      bankStatementEndingBalance: bankBal,
      generalTrustBookBalance: clientSum,
      clientLedgersSum: clientSum,
      variance: Number((bankBal - clientSum).toFixed(2)),
      adjustedBankBalance: bankBal,
      status: isBalanced ? 'Balanced' : 'Discrepancy'
    };
    setReconciliation(newRecon);
  };

  // 1. Matters Handlers
  const addMatter = (matterData: Omit<Matter, 'id' | 'matterNumber' | 'trustBalance' | 'notes' | 'tasks'>): Matter => {
    const count = matters.length + 1;
    const seq = String(count).padStart(4, '0');
    const newMatter: Matter = {
      ...matterData,
      id: `mat-${Date.now()}`,
      matterNumber: `MAT-2026-${seq}`,
      trustBalance: 0,
      notes: [
        {
          id: `note-${Date.now()}`,
          date: new Date().toISOString().split('T')[0],
          author: matterData.leadAttorney,
          category: 'General',
          text: `Matter opened and conflict check verified cleared. Scope: ${matterData.title}`
        }
      ],
      tasks: [
        {
          id: `task-${Date.now()}`,
          title: 'Execute Client Engagement Agreement & IOLTA Retainer Deposit',
          dueDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
          assignedTo: matterData.leadAttorney,
          completed: false,
          priority: 'High',
          isCourtDeadline: false
        }
      ]
    };

    setMatters(prev => [newMatter, ...prev]);
    return newMatter;
  };

  const updateMatter = (id: string, updates: Partial<Matter>) => {
    setMatters(prev => {
      const updated = prev.map(m => m.id === id ? { ...m, ...updates } : m);
      if (updates.trustBalance !== undefined) {
        refreshReconciliation(updated);
      }
      return updated;
    });
  };

  const deleteMatter = (id: string) => {
    setMatters(prev => {
      const updated = prev.filter(m => m.id !== id);
      refreshReconciliation(updated);
      return updated;
    });
  };

  const addMatterNote = (matterId: string, text: string, category: MatterNote['category']) => {
    setMatters(prev => prev.map(m => {
      if (m.id !== matterId) return m;
      const newNote: MatterNote = {
        id: `note-${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
        author: m.leadAttorney,
        category,
        text
      };
      return { ...m, notes: [newNote, ...m.notes] };
    }));
  };

  const toggleMatterTask = (matterId: string, taskId: string) => {
    setMatters(prev => prev.map(m => {
      if (m.id !== matterId) return m;
      return {
        ...m,
        tasks: m.tasks.map(t => t.id === taskId ? { ...t, completed: !t.completed } : t)
      };
    }));
  };

  const addMatterTask = (matterId: string, title: string, dueDate: string, priority: MatterTask['priority'], isCourtDeadline = false) => {
    setMatters(prev => prev.map(m => {
      if (m.id !== matterId) return m;
      const newTask: MatterTask = {
        id: `task-${Date.now()}`,
        title,
        dueDate,
        assignedTo: m.leadAttorney,
        completed: false,
        priority,
        isCourtDeadline
      };
      return { ...m, tasks: [...m.tasks, newTask] };
    }));
  };

  // 2. Timer Handlers
  const startTimer = (matterId?: string) => {
    const targetMatterId = matterId || activeTimer.matterId || matters[0]?.id;
    const targetMatter = matters.find(m => m.id === targetMatterId);
    setActiveTimer(prev => ({
      ...prev,
      isRunning: true,
      matterId: targetMatterId,
      rate: targetMatter ? targetMatter.defaultRate : prev.rate,
      attorneyName: targetMatter ? targetMatter.leadAttorney : prev.attorneyName
    }));
  };

  const pauseTimer = () => {
    setActiveTimer(prev => ({ ...prev, isRunning: false }));
  };

  const resetTimer = () => {
    setActiveTimer(prev => ({
      ...prev,
      isRunning: false,
      seconds: 0,
      description: ''
    }));
  };

  const updateTimerState = (updates: Partial<ActiveTimerState>) => {
    setActiveTimer(prev => ({ ...prev, ...updates }));
  };

  const commitTimerToEntry = (): TimeEntry | null => {
    if (activeTimer.seconds <= 0) return null;

    const currentMatter = matters.find(m => m.id === activeTimer.matterId) || matters[0];
    if (!currentMatter) return null;

    // Standard 6-minute increment (0.1h) calculation
    let calculatedHours = activeTimer.seconds / 3600;
    if (activeTimer.roundToTenth) {
      calculatedHours = Math.max(0.1, Math.ceil(calculatedHours * 10) / 10);
    } else {
      calculatedHours = Math.round(calculatedHours * 100) / 100;
    }

    const newEntry: TimeEntry = {
      id: `te-${Date.now()}`,
      matterId: currentMatter.id,
      matterNumber: currentMatter.matterNumber,
      matterTitle: currentMatter.title,
      clientName: currentMatter.clientName,
      date: new Date().toISOString().split('T')[0],
      durationHours: calculatedHours,
      rate: activeTimer.rate || currentMatter.defaultRate,
      billable: true,
      utbmsCode: activeTimer.utbmsCode || 'L120 - Analysis / Strategy Formulation',
      description: activeTimer.description.trim() || 'Professional legal consultation and case analysis.',
      attorneyName: activeTimer.attorneyName || currentMatter.leadAttorney,
      status: 'Unbilled'
    };

    setTimeEntries(prev => [newEntry, ...prev]);
    resetTimer();
    return newEntry;
  };

  const addTimeEntry = (entryData: Omit<TimeEntry, 'id' | 'status'>): TimeEntry => {
    const newEntry: TimeEntry = {
      ...entryData,
      id: `te-${Date.now()}`,
      status: 'Unbilled'
    };
    setTimeEntries(prev => [newEntry, ...prev]);
    return newEntry;
  };

  const updateTimeEntry = (id: string, updates: Partial<TimeEntry>) => {
    setTimeEntries(prev => prev.map(te => te.id === id ? { ...te, ...updates } : te));
  };

  const deleteTimeEntry = (id: string) => {
    setTimeEntries(prev => prev.filter(te => te.id !== id));
  };

  // 3. Invoices & Billing Handlers
  const createInvoice = (params: { 
    matterId: string; 
    lineItemIds: string[]; 
    dueDate: string; 
    notes?: string; 
    discount?: number 
  }): Invoice => {
    const matter = matters.find(m => m.id === params.matterId) || matters[0];
    const selectedEntries = timeEntries.filter(te => params.lineItemIds.includes(te.id));

    const lineItems = selectedEntries.map(te => ({
      id: `li-${te.id}`,
      description: te.description,
      hours: te.durationHours,
      rate: te.rate,
      amount: te.durationHours * te.rate,
      utbmsCode: te.utbmsCode.split(' ')[0],
      date: te.date
    }));

    const subtotal = lineItems.reduce((acc, item) => acc + item.amount, 0);
    const discountAmount = params.discount || 0;
    const total = Math.max(0, subtotal - discountAmount);

    const invoiceCount = invoices.length + 1;
    const invSeq = String(invoiceCount).padStart(4, '0');

    const newInvoice: Invoice = {
      id: `inv-${Date.now()}`,
      invoiceNumber: `INV-2026-${invSeq}`,
      matterId: matter.id,
      matterNumber: matter.matterNumber,
      matterTitle: matter.title,
      clientId: matter.clientId,
      clientName: matter.clientName,
      clientEmail: matter.clientEmail,
      clientAddress: 'Corporate Legal Dept, Suite 1000',
      issueDate: new Date().toISOString().split('T')[0],
      dueDate: params.dueDate,
      lineItems,
      expenses: [],
      subtotal,
      taxAmount: 0,
      discountAmount,
      total,
      amountPaid: 0,
      trustApplied: 0,
      balanceDue: total,
      status: 'Sent',
      notes: params.notes || 'Payment due within 30 days. Remit to CounselFlow Operating Escrow or authorize Trust Drawdown.',
      payments: []
    };

    // Mark entries as invoiced
    setTimeEntries(prev => prev.map(te => {
      if (params.lineItemIds.includes(te.id)) {
        return { ...te, status: 'Invoiced', invoiceId: newInvoice.id };
      }
      return te;
    }));

    setInvoices(prev => [newInvoice, ...prev]);
    return newInvoice;
  };

  const payInvoiceFromTrust = (invoiceId: string, amount: number): { success: boolean; message: string } => {
    const invoice = invoices.find(inv => inv.id === invoiceId);
    if (!invoice) return { success: false, message: 'Invoice not found.' };

    const matter = matters.find(m => m.id === invoice.matterId);
    if (!matter) return { success: false, message: 'Matter not found.' };

    if (amount <= 0) return { success: false, message: 'Payment amount must be greater than $0.' };

    if (amount > invoice.balanceDue) {
      return { success: false, message: `Payment exceeds remaining balance of $${invoice.balanceDue.toLocaleString()}.` };
    }

    // STRICT IOLTA COMPLIANCE GUARD:
    // Firm CANNOT disburse more trust money than belongs to this specific matter!
    if (amount > matter.trustBalance) {
      return { 
        success: false, 
        message: `IOLTA Safeguard Violation: Available client trust balance is only $${matter.trustBalance.toLocaleString()}. You cannot disburse more than the client's individual trust balance.` 
      };
    }

    // Process Trust Disbursement
    const txId = `tr-${Date.now()}`;
    const txNumber = `TR-2026-${String(trustTransactions.length + 1).padStart(4, '0')}`;
    const newRunningBalance = matter.trustBalance - amount;

    const newTx: TrustTransaction = {
      id: txId,
      transactionNumber: txNumber,
      date: new Date().toISOString().split('T')[0],
      matterId: matter.id,
      matterNumber: matter.matterNumber,
      clientName: matter.clientName,
      type: 'Disbursement',
      amount,
      paymentMethod: 'Trust Transfer',
      referenceNumber: `IOLTA-DRAW-${invoice.invoiceNumber}`,
      explanationPurpose: `Earned attorney fees transfer to operating account for Invoice ${invoice.invoiceNumber}`,
      authorizedBy: matter.leadAttorney,
      runningBalance: newRunningBalance,
      invoiceId: invoice.id,
      status: 'Cleared'
    };

    // Update Matter trust balance
    const updatedMatters = matters.map(m => m.id === matter.id ? { ...m, trustBalance: newRunningBalance } : m);
    setMatters(updatedMatters);

    // Update Trust Transactions
    setTrustTransactions(prev => [newTx, ...prev]);

    // Update Invoice
    const updatedAmountPaid = invoice.amountPaid + amount;
    const updatedTrustApplied = invoice.trustApplied + amount;
    const updatedBalanceDue = invoice.total - updatedAmountPaid;
    const newStatus = updatedBalanceDue <= 0.01 ? 'Paid' : invoice.status;

    setInvoices(prev => prev.map(inv => inv.id === invoice.id ? {
      ...inv,
      amountPaid: updatedAmountPaid,
      trustApplied: updatedTrustApplied,
      balanceDue: Math.max(0, updatedBalanceDue),
      status: newStatus,
      payments: [
        ...inv.payments,
        {
          id: `pay-${Date.now()}`,
          date: new Date().toISOString().split('T')[0],
          amount,
          method: 'Trust Transfer (IOLTA)',
          reference: newTx.referenceNumber
        }
      ]
    } : inv));

    // Refresh 3-way reconciliation
    refreshReconciliation(updatedMatters);

    return { 
      success: true, 
      message: `Successfully transferred $${amount.toLocaleString()} from IOLTA Trust to Operating Account for ${invoice.invoiceNumber}.` 
    };
  };

  const recordManualPayment = (invoiceId: string, amount: number, method: Invoice['payments'][0]['method'], reference: string) => {
    setInvoices(prev => prev.map(inv => {
      if (inv.id !== invoiceId) return inv;
      const newPaid = inv.amountPaid + amount;
      const newBalance = Math.max(0, inv.total - newPaid);
      return {
        ...inv,
        amountPaid: newPaid,
        balanceDue: newBalance,
        status: newBalance <= 0.01 ? 'Paid' : inv.status,
        payments: [
          ...inv.payments,
          {
            id: `pay-${Date.now()}`,
            date: new Date().toISOString().split('T')[0],
            amount,
            method,
            reference
          }
        ]
      };
    }));
  };

  const updateInvoiceStatus = (invoiceId: string, status: Invoice['status']) => {
    setInvoices(prev => prev.map(inv => inv.id === invoiceId ? { ...inv, status } : inv));
  };

  // 4. Trust Accounting & IOLTA Handlers
  const addTrustTransaction = (params: {
    matterId: string;
    type: 'Deposit' | 'Disbursement';
    amount: number;
    paymentMethod: TrustTransaction['paymentMethod'];
    referenceNumber: string;
    explanationPurpose: string;
    authorizedBy: string;
    invoiceId?: string;
  }): { success: boolean; message: string; transaction?: TrustTransaction } => {
    const matter = matters.find(m => m.id === params.matterId);
    if (!matter) return { success: false, message: 'Matter not found' };

    if (params.amount <= 0) return { success: false, message: 'Amount must be greater than $0.' };

    if (params.type === 'Disbursement' && params.amount > matter.trustBalance) {
      return {
        success: false,
        message: `IOLTA Violation: Insufficient client trust funds. Current matter trust balance is $${matter.trustBalance.toLocaleString()}, cannot disburse $${params.amount.toLocaleString()}.`
      };
    }

    const delta = params.type === 'Deposit' ? params.amount : -params.amount;
    const newRunningBalance = matter.trustBalance + delta;

    const newTx: TrustTransaction = {
      id: `tr-${Date.now()}`,
      transactionNumber: `TR-2026-${String(trustTransactions.length + 1).padStart(4, '0')}`,
      date: new Date().toISOString().split('T')[0],
      matterId: matter.id,
      matterNumber: matter.matterNumber,
      clientName: matter.clientName,
      type: params.type,
      amount: params.amount,
      paymentMethod: params.paymentMethod,
      referenceNumber: params.referenceNumber,
      explanationPurpose: params.explanationPurpose,
      authorizedBy: params.authorizedBy,
      runningBalance: newRunningBalance,
      invoiceId: params.invoiceId,
      status: 'Cleared'
    };

    const updatedMatters = matters.map(m => m.id === matter.id ? { ...m, trustBalance: newRunningBalance } : m);
    setMatters(updatedMatters);
    setTrustTransactions(prev => [newTx, ...prev]);

    refreshReconciliation(updatedMatters);

    return {
      success: true,
      message: `IOLTA Trust ${params.type} of $${params.amount.toLocaleString()} recorded successfully for ${matter.matterNumber}.`,
      transaction: newTx
    };
  };

  const runThreeWayReconciliation = (bankStatementEndingBalance: number, notes?: string): ReconciliationRecord => {
    const clientSum = matters.reduce((acc, m) => acc + (m.trustBalance || 0), 0);
    const variance = Number((bankStatementEndingBalance - clientSum).toFixed(2));
    const isBalanced = Math.abs(variance) < 0.01;

    const newRecord: ReconciliationRecord = {
      id: `recon-${Date.now()}`,
      reconciliationDate: new Date().toISOString().split('T')[0],
      bankStatementEndingBalance,
      generalTrustBookBalance: clientSum,
      clientLedgersSum: clientSum,
      variance,
      unclearedDeposits: 0,
      outstandingDisbursements: 0,
      adjustedBankBalance: bankStatementEndingBalance,
      status: isBalanced ? 'Balanced' : 'Discrepancy',
      reviewedBy: 'Julian Davenport, Esq. (Managing Partner)',
      notes: notes || (isBalanced ? 'All individual client sub-ledgers reconcile 100% with bank statement balance. IOLTA audit passed.' : `Variance of $${variance} detected between bank statement and client ledgers. Review pending deposits or uncashed client disbursements.`)
    };

    setReconciliation(newRecord);
    return newRecord;
  };

  // 5. Document Automation Handlers
  const generateDocument = (params: {
    templateId: string;
    matterId: string;
    title: string;
    variableValues: Record<string, string>;
    selectedClauseIds: string[];
  }): GeneratedDocument => {
    const template = templates.find(t => t.id === params.templateId) || templates[0];
    const matter = matters.find(m => m.id === params.matterId) || matters[0];

    // Build clauses text
    const activeClauses = template.clauses.filter(cl => params.selectedClauseIds.includes(cl.id));
    const clausesText = activeClauses.length > 0 
      ? activeClauses.map((c, i) => `#### ${c.title}\n${c.content}`).join('\n\n')
      : '_No special clauses selected._';

    // Substitute variables
    let compiled = template.bodyContent;
    compiled = compiled.replace(/\{\{selected_clauses\}\}/g, clausesText);

    Object.entries(params.variableValues).forEach(([key, val]) => {
      const reg = new RegExp(`\\{\\{${key}\\}\\}`, 'g');
      compiled = compiled.replace(reg, val || `[${key}]`);
    });

    const newDoc: GeneratedDocument = {
      id: `gdoc-${Date.now()}`,
      templateId: template.id,
      templateTitle: template.title,
      matterId: matter.id,
      matterNumber: matter.matterNumber,
      matterTitle: matter.title,
      clientName: matter.clientName,
      title: params.title || `${template.title} - ${matter.clientName}`,
      createdDate: new Date().toISOString().split('T')[0],
      lastModified: new Date().toISOString().split('T')[0],
      content: compiled,
      status: 'Draft'
    };

    setGeneratedDocs(prev => [newDoc, ...prev]);
    return newDoc;
  };

  const updateGeneratedDoc = (id: string, updates: Partial<GeneratedDocument>) => {
    setGeneratedDocs(prev => prev.map(doc => doc.id === id ? { 
      ...doc, 
      ...updates, 
      lastModified: new Date().toISOString().split('T')[0] 
    } : doc));
  };

  const deleteGeneratedDoc = (id: string) => {
    setGeneratedDocs(prev => prev.filter(doc => doc.id !== id));
  };

  // 6. Conflict Checking Engine
  const runConflictCheck = (query: string): ConflictResult => {
    const cleanQ = query.trim().toLowerCase();
    if (!cleanQ) {
      return { matchFound: false, query: '', hits: [] };
    }

    const hits: ConflictResult['hits'] = [];

    matters.forEach(m => {
      // 1. Check Client Name
      if (m.clientName.toLowerCase().includes(cleanQ)) {
        hits.push({
          type: 'Client',
          name: m.clientName,
          matterNumber: m.matterNumber,
          matterTitle: m.title,
          status: m.status,
          leadAttorney: m.leadAttorney,
          severity: 'Existing Representation',
          notes: `Client is currently represented by ${m.leadAttorney} under ${m.matterNumber}. Direct conflict if adverse.`
        });
      }

      // 2. Check Opposing Party
      if (m.opposingParty && m.opposingParty.toLowerCase().includes(cleanQ)) {
        hits.push({
          type: 'Matter Opposing Party',
          name: m.opposingParty,
          matterNumber: m.matterNumber,
          matterTitle: m.title,
          status: m.status,
          leadAttorney: m.leadAttorney,
          severity: 'High Conflict',
          notes: `Entity is currently an adverse party in active litigation matter ${m.matterNumber}. Representation strictly prohibited without ethical wall & written consent.`
        });
      }

      // 3. Check Opposing Counsel
      if (m.opposingCounsel && m.opposingCounsel.toLowerCase().includes(cleanQ)) {
        hits.push({
          type: 'Opposing Counsel',
          name: m.opposingCounsel,
          matterNumber: m.matterNumber,
          matterTitle: m.title,
          status: m.status,
          leadAttorney: m.leadAttorney,
          severity: 'Potential Adversary',
          notes: `Counsel is opposing counsel in ${m.matterNumber}. Check for potential co-representation conflicts.`
        });
      }

      // 4. Check Matter Title or Court docket
      if (m.title.toLowerCase().includes(cleanQ) || (m.docketNumber && m.docketNumber.toLowerCase().includes(cleanQ))) {
        if (!hits.some(h => h.matterNumber === m.matterNumber)) {
          hits.push({
            type: 'Active Matter',
            name: m.title,
            matterNumber: m.matterNumber,
            matterTitle: m.title,
            status: m.status,
            leadAttorney: m.leadAttorney,
            severity: 'Existing Representation',
            notes: `Matches active case record in ${m.courtOrJurisdiction || 'practice ledger'}.`
          });
        }
      }
    });

    return {
      matchFound: hits.length > 0,
      query,
      hits
    };
  };

  // Quick stats
  const totalTrustBalance = matters.reduce((sum, m) => sum + (m.trustBalance || 0), 0);
  const totalUnbilledWIP = timeEntries
    .filter(te => te.status === 'Unbilled')
    .reduce((sum, te) => sum + (te.durationHours * te.rate), 0);
  const totalUnpaidInvoices = invoices
    .filter(inv => inv.status !== 'Paid' && inv.status !== 'Void')
    .reduce((sum, inv) => sum + inv.balanceDue, 0);
  const activeMattersCount = matters.filter(m => m.status !== 'Closed').length;

  return (
    <PracticeContext.Provider
      value={{
        activeView,
        setActiveView,
        selectedMatterId,
        setSelectedMatterId,
        isCommandPaletteOpen,
        setIsCommandPaletteOpen,

        matters,
        addMatter,
        updateMatter,
        deleteMatter,
        addMatterNote,
        toggleMatterTask,
        addMatterTask,

        timeEntries,
        activeTimer,
        startTimer,
        pauseTimer,
        resetTimer,
        updateTimerState,
        commitTimerToEntry,
        addTimeEntry,
        updateTimeEntry,
        deleteTimeEntry,

        invoices,
        createInvoice,
        payInvoiceFromTrust,
        recordManualPayment,
        updateInvoiceStatus,

        trustTransactions,
        reconciliation,
        addTrustTransaction,
        runThreeWayReconciliation,

        templates,
        generatedDocs,
        generateDocument,
        updateGeneratedDoc,
        deleteGeneratedDoc,

        runConflictCheck,

        totalTrustBalance,
        totalUnbilledWIP,
        totalUnpaidInvoices,
        activeMattersCount
      }}
    >
      {children}
    </PracticeContext.Provider>
  );
};

export const usePractice = () => {
  const context = useContext(PracticeContext);
  if (!context) {
    throw new Error('usePractice must be used within a PracticeProvider');
  }
  return context;
};
