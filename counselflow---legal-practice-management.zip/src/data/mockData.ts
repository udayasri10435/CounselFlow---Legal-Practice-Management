import { 
  Matter, 
  TimeEntry, 
  Invoice, 
  TrustTransaction, 
  ReconciliationRecord, 
  DocumentTemplate, 
  GeneratedDocument,
  UTBMSCode 
} from '../types';

export const UTBMS_CODES: UTBMSCode[] = [
  { code: 'L110', category: 'Litigation', description: 'Fact Investigation / Development' },
  { code: 'L120', category: 'Litigation', description: 'Analysis / Strategy Formulation' },
  { code: 'L210', category: 'Litigation', description: 'Pleadings & Initial Filings' },
  { code: 'L240', category: 'Litigation', description: 'Dispositive Motions & Briefs' },
  { code: 'L310', category: 'Litigation', description: 'Written Discovery & Interrogatories' },
  { code: 'L330', category: 'Litigation', description: 'Depositions Taking & Defending' },
  { code: 'L410', category: 'Litigation', description: 'Trial Preparation & Exhibits' },
  { code: 'L510', category: 'Litigation', description: 'Settlement Conferences & ADR' },
  { code: 'A103', category: 'Advisory', description: 'Telephone Conference with Client/Counsel' },
  { code: 'A104', category: 'Advisory', description: 'Written Communication & Email Correspondence' },
  { code: 'A105', category: 'Advisory', description: 'Review & Analyze Relevant Case Documents' },
  { code: 'B110', category: 'General', description: 'Draft Contracts / Commercial Agreements' },
  { code: 'B130', category: 'General', description: 'Due Diligence & Regulatory Compliance Review' },
  { code: 'E101', category: 'General', description: 'Estate Planning & Trust Document Drafting' },
  { code: 'P102', category: 'General', description: 'Patent & Trademark Filing Documentation' }
];

export const INITIAL_MATTERS: Matter[] = [
  {
    id: 'mat-1',
    matterNumber: 'MAT-2026-0082',
    title: 'Acme Corp v. Apex Dynamics Inc.',
    clientId: 'cli-101',
    clientName: 'Acme Technologies Inc.',
    clientEmail: 'generalcounsel@acmetech.io',
    clientPhone: '(415) 883-9120',
    practiceArea: 'Commercial Litigation',
    status: 'Discovery',
    billingModel: 'Hourly',
    defaultRate: 675,
    leadAttorney: 'Victoria Vance, Esq.',
    responsibleStaff: ['Marcus Wright (Associate)', 'Elena Rostova (Paralegal)'],
    opposingParty: 'Apex Dynamics Inc.',
    opposingCounsel: 'Sterling, Cross & Higgins LLP (Mark Gallagher, Esq.)',
    courtOrJurisdiction: 'U.S. District Court, N.D. California',
    docketNumber: '3:25-cv-09142-WHA',
    openDate: '2025-11-14',
    statuteOfLimitationsDate: '2027-04-15',
    trustBalance: 42500,
    operatingRetainerBalance: 5000,
    notes: [
      {
        id: 'note-1',
        date: '2026-09-18',
        author: 'Victoria Vance, Esq.',
        category: 'Court Filing',
        text: 'Deposition subpoena served upon Apex Chief Technology Officer. Motion to compel responses to second set of interrogatories drafted.'
      },
      {
        id: 'note-2',
        date: '2026-09-24',
        author: 'Marcus Wright (Associate)',
        category: 'Client Call',
        text: 'Executive review call with CFO regarding expert witness budgets. Client approved $25k expert retainer disbursement.'
      }
    ],
    tasks: [
      {
        id: 'task-1',
        title: 'Serve Second Set of Requests for Production',
        dueDate: '2026-10-05',
        assignedTo: 'Marcus Wright',
        completed: false,
        priority: 'High',
        isCourtDeadline: true
      },
      {
        id: 'task-2',
        title: 'Prepare Witness Deposition Binder (CTO)',
        dueDate: '2026-10-12',
        assignedTo: 'Elena Rostova',
        completed: false,
        priority: 'Medium',
        isCourtDeadline: false
      }
    ]
  },
  {
    id: 'mat-2',
    matterNumber: 'MAT-2026-0104',
    title: 'Horizon FinTech Series B Preferred Financing',
    clientId: 'cli-102',
    clientName: 'Horizon Financial Group',
    clientEmail: 'legal@horizonfin.com',
    clientPhone: '(212) 554-7200',
    practiceArea: 'Corporate & M&A',
    status: 'Active',
    billingModel: 'Fixed Fee',
    defaultRate: 720,
    leadAttorney: 'Julian Davenport, Esq.',
    responsibleStaff: ['Sarah Chen (Senior Associate)'],
    opposingParty: 'Vanguard Capital Partners (Lead Investor)',
    opposingCounsel: 'Fenwick & West LLP (David Ross, Esq.)',
    courtOrJurisdiction: 'Delaware Chancery / Corporate Counsel',
    openDate: '2026-01-10',
    trustBalance: 18000,
    notes: [
      {
        id: 'note-3',
        date: '2026-09-22',
        author: 'Julian Davenport, Esq.',
        category: 'General',
        text: 'Term sheet finalized at $48M pre-money valuation. NVCA model voting agreements drafted with custom protective provisions.'
      }
    ],
    tasks: [
      {
        id: 'task-3',
        title: 'Circulate Amended Investor Rights Agreement for signature',
        dueDate: '2026-10-02',
        assignedTo: 'Sarah Chen',
        completed: false,
        priority: 'High',
        isCourtDeadline: false
      }
    ]
  },
  {
    id: 'mat-3',
    matterNumber: 'MAT-2026-0045',
    title: 'Kensington Dynasty Revocable Family Trust & Asset Protection',
    clientId: 'cli-103',
    clientName: 'Arthur & Eleanor Kensington',
    clientEmail: 'arthur@kensingtonholdings.org',
    clientPhone: '(312) 420-1922',
    practiceArea: 'Estate & Trusts',
    status: 'Settlement / Closing',
    billingModel: 'Hourly',
    defaultRate: 590,
    leadAttorney: 'Julian Davenport, Esq.',
    responsibleStaff: ['Elena Rostova (Paralegal)'],
    courtOrJurisdiction: 'Cook County Probate Court',
    openDate: '2025-08-20',
    trustBalance: 8500,
    notes: [
      {
        id: 'note-4',
        date: '2026-09-15',
        author: 'Julian Davenport, Esq.',
        category: 'Client Call',
        text: 'Signing ceremony conducted for restated dynasty trust and generation-skipping transfer tax allocations.'
      }
    ],
    tasks: [
      {
        id: 'task-4',
        title: 'File real property deed transfer with county recorder',
        dueDate: '2026-09-30',
        assignedTo: 'Elena Rostova',
        completed: true,
        priority: 'Medium',
        isCourtDeadline: false
      }
    ]
  },
  {
    id: 'mat-4',
    matterNumber: 'MAT-2026-0118',
    title: 'Sterling Biotech CRISPR Vector Patent Prosecution & Cross-License',
    clientId: 'cli-104',
    clientName: 'Sterling Therapeutics SA',
    clientEmail: 'patents@sterlingbio.ch',
    clientPhone: '+41 22 819 4400',
    practiceArea: 'Intellectual Property',
    status: 'Active',
    billingModel: 'Hourly',
    defaultRate: 750,
    leadAttorney: 'Victoria Vance, Esq.',
    responsibleStaff: ['Dr. Aris Thorne (Patent Agent)'],
    opposingParty: 'GenHelix Therapeutics GmbH',
    courtOrJurisdiction: 'USPTO / European Patent Office (EPO)',
    docketNumber: 'US-App-18/902,311',
    openDate: '2026-03-01',
    statuteOfLimitationsDate: '2026-11-20', // Approaching deadline!
    trustBalance: 31200,
    notes: [
      {
        id: 'note-5',
        date: '2026-09-20',
        author: 'Dr. Aris Thorne',
        category: 'Court Filing',
        text: 'USPTO non-final office action response drafted with amended Claims 1-14 to establish non-obviousness over prior art Müller 2021.'
      }
    ],
    tasks: [
      {
        id: 'task-5',
        title: 'USPTO 3-Month Office Action Deadline',
        dueDate: '2026-10-18',
        assignedTo: 'Victoria Vance, Esq.',
        completed: false,
        priority: 'High',
        isCourtDeadline: true
      }
    ]
  },
  {
    id: 'mat-5',
    matterNumber: 'MAT-2026-0130',
    title: 'Pacific Horizon Waterfront Commercial Tower Lease Negotiations',
    clientId: 'cli-105',
    clientName: 'Pacific Horizon Real Estate Partners',
    clientEmail: 'development@pacifichorizon.com',
    clientPhone: '(206) 714-3388',
    practiceArea: 'Real Estate',
    status: 'Pre-Trial',
    billingModel: 'Hourly',
    defaultRate: 610,
    leadAttorney: 'Julian Davenport, Esq.',
    responsibleStaff: ['Sarah Chen (Senior Associate)'],
    opposingParty: 'Northwest Marina Holdings LLC',
    opposingCounsel: 'Perkins Coie LLP (Karen Lindqvist, Esq.)',
    courtOrJurisdiction: 'King County Superior Court',
    openDate: '2026-05-12',
    statuteOfLimitationsDate: '2028-05-12',
    trustBalance: 12000,
    notes: [
      {
        id: 'note-6',
        date: '2026-09-10',
        author: 'Sarah Chen',
        category: 'Settlement Negotiation',
        text: 'Landlord concession package negotiated: 6 months tenant improvement abatement in exchange for 12-year lease extension.'
      }
    ],
    tasks: [
      {
        id: 'task-6',
        title: 'Review subordination and non-disturbance agreement (SNDA)',
        dueDate: '2026-10-08',
        assignedTo: 'Sarah Chen',
        completed: false,
        priority: 'Medium',
        isCourtDeadline: false
      }
    ]
  },
  {
    id: 'mat-6',
    matterNumber: 'MAT-2026-0142',
    title: 'Garcia v. NexaGlobal - Executive Non-Compete & Trade Secrets',
    clientId: 'cli-106',
    clientName: 'Dr. Raymond Garcia',
    clientEmail: 'rgarcia.ai@gmail.com',
    clientPhone: '(650) 992-4112',
    practiceArea: 'Employment & Labor',
    status: 'Intake',
    billingModel: 'Hourly',
    defaultRate: 650,
    leadAttorney: 'Victoria Vance, Esq.',
    responsibleStaff: ['Marcus Wright (Associate)'],
    opposingParty: 'NexaGlobal Autonomous Systems Inc.',
    opposingCounsel: 'Gibson Dunn & Crutcher LLP',
    courtOrJurisdiction: 'Santa Clara County Superior Court',
    openDate: '2026-09-22',
    statuteOfLimitationsDate: '2027-01-30',
    trustBalance: 15000,
    notes: [
      {
        id: 'note-7',
        date: '2026-09-23',
        author: 'Victoria Vance, Esq.',
        category: 'Client Call',
        text: 'Initial intake completed. California Bus. & Prof. Code § 16600 voidness arguments analyzed regarding restrictive covenants.'
      }
    ],
    tasks: [
      {
        id: 'task-7',
        title: 'Draft Pre-Litigation Cease & Desist / Declaratory Relief Letter',
        dueDate: '2026-10-01',
        assignedTo: 'Marcus Wright',
        completed: false,
        priority: 'High',
        isCourtDeadline: false
      }
    ]
  }
];

export const INITIAL_TIME_ENTRIES: TimeEntry[] = [
  {
    id: 'te-1',
    matterId: 'mat-1',
    matterNumber: 'MAT-2026-0082',
    matterTitle: 'Acme Corp v. Apex Dynamics Inc.',
    clientName: 'Acme Technologies Inc.',
    date: '2026-09-26',
    durationHours: 2.4,
    rate: 675,
    billable: true,
    utbmsCode: 'L240 - Dispositive Motions & Briefs',
    description: 'Drafted opposition to defendant Apex motion for protective order; analyzed 9th Circuit precedence on source code discovery.',
    attorneyName: 'Victoria Vance, Esq.',
    status: 'Unbilled'
  },
  {
    id: 'te-2',
    matterId: 'mat-1',
    matterNumber: 'MAT-2026-0082',
    matterTitle: 'Acme Corp v. Apex Dynamics Inc.',
    clientName: 'Acme Technologies Inc.',
    date: '2026-09-25',
    durationHours: 1.8,
    rate: 450,
    billable: true,
    utbmsCode: 'L310 - Written Discovery & Interrogatories',
    description: 'Synthesized electronic discovery custodians list; prepared responses to defendants second request for admission.',
    attorneyName: 'Marcus Wright (Associate)',
    status: 'Unbilled'
  },
  {
    id: 'te-3',
    matterId: 'mat-2',
    matterNumber: 'MAT-2026-0104',
    matterTitle: 'Horizon FinTech Series B Preferred Financing',
    clientName: 'Horizon Financial Group',
    date: '2026-09-27',
    durationHours: 3.2,
    rate: 720,
    billable: true,
    utbmsCode: 'B110 - Draft Contracts / Commercial Agreements',
    description: 'Substantive revision to Series B Certificate of Incorporation, liquidation preference overhang, and co-sale covenants.',
    attorneyName: 'Julian Davenport, Esq.',
    status: 'Unbilled'
  },
  {
    id: 'te-4',
    matterId: 'mat-4',
    matterNumber: 'MAT-2026-0118',
    matterTitle: 'Sterling Biotech CRISPR Vector Patent Prosecution & Cross-License',
    clientName: 'Sterling Therapeutics SA',
    date: '2026-09-24',
    durationHours: 2.1,
    rate: 750,
    billable: true,
    utbmsCode: 'P102 - Patent & Trademark Filing Documentation',
    description: 'Conducted prior art differential analysis for CRISPR Cas12j PAM sequence variants; drafted technical declaration.',
    attorneyName: 'Victoria Vance, Esq.',
    status: 'Unbilled'
  },
  {
    id: 'te-5',
    matterId: 'mat-5',
    matterNumber: 'MAT-2026-0130',
    matterTitle: 'Pacific Horizon Waterfront Commercial Tower Lease Negotiations',
    clientName: 'Pacific Horizon Real Estate Partners',
    date: '2026-09-23',
    durationHours: 1.5,
    rate: 480,
    billable: true,
    utbmsCode: 'A103 - Telephone Conference with Client/Counsel',
    description: 'Conference call with lead landlord broker regarding HVAC capital expenditure allocation and casualty insurance clauses.',
    attorneyName: 'Sarah Chen (Senior Associate)',
    status: 'Unbilled'
  },
  {
    id: 'te-6',
    matterId: 'mat-6',
    matterNumber: 'MAT-2026-0142',
    matterTitle: 'Garcia v. NexaGlobal - Executive Non-Compete & Trade Secrets',
    clientName: 'Dr. Raymond Garcia',
    date: '2026-09-27',
    durationHours: 1.2,
    rate: 650,
    billable: true,
    utbmsCode: 'L120 - Analysis / Strategy Formulation',
    description: 'Analyzed employer trade secret claims regarding foundational LLM model weights under California Uniform Trade Secrets Act (CUTSA).',
    attorneyName: 'Victoria Vance, Esq.',
    status: 'Unbilled'
  }
];

export const INITIAL_INVOICES: Invoice[] = [
  {
    id: 'inv-1',
    invoiceNumber: 'INV-2026-0078',
    matterId: 'mat-1',
    matterNumber: 'MAT-2026-0082',
    matterTitle: 'Acme Corp v. Apex Dynamics Inc.',
    clientId: 'cli-101',
    clientName: 'Acme Technologies Inc.',
    clientEmail: 'generalcounsel@acmetech.io',
    clientAddress: '550 Montgomery St, Suite 900, San Francisco, CA 94111',
    issueDate: '2026-09-01',
    dueDate: '2026-10-01',
    subtotal: 14850,
    taxAmount: 0,
    discountAmount: 0,
    total: 14850,
    amountPaid: 14850,
    trustApplied: 14850,
    balanceDue: 0,
    status: 'Paid',
    notes: 'Paid in full via authorized client trust IOLTA transfer on Sept 5, 2026.',
    lineItems: [
      {
        id: 'li-1',
        description: 'Prepare Motion to Compel production of server logs',
        hours: 12.0,
        rate: 675,
        amount: 8100,
        utbmsCode: 'L240',
        date: '2026-08-14'
      },
      {
        id: 'li-2',
        description: 'Deposition preparation and witness interview',
        hours: 15.0,
        rate: 450,
        amount: 6750,
        utbmsCode: 'L330',
        date: '2026-08-20'
      }
    ],
    expenses: [],
    payments: [
      {
        id: 'pay-1',
        date: '2026-09-05',
        amount: 14850,
        method: 'Trust Transfer (IOLTA)',
        reference: 'IOLTA-XFER-9921'
      }
    ]
  },
  {
    id: 'inv-2',
    invoiceNumber: 'INV-2026-0089',
    matterId: 'mat-2',
    matterNumber: 'MAT-2026-0104',
    matterTitle: 'Horizon FinTech Series B Preferred Financing',
    clientId: 'cli-102',
    clientName: 'Horizon Financial Group',
    clientEmail: 'legal@horizonfin.com',
    clientAddress: '383 Madison Avenue, 24th Floor, New York, NY 10179',
    issueDate: '2026-09-15',
    dueDate: '2026-10-15',
    subtotal: 22000,
    taxAmount: 0,
    discountAmount: 1000,
    total: 21000,
    amountPaid: 10000,
    trustApplied: 10000,
    balanceDue: 11000,
    status: 'Sent',
    notes: 'Milestone 1 invoice for corporate restatement and SEC filing prep. Remaining balance payable net 30.',
    lineItems: [
      {
        id: 'li-3',
        description: 'Series B Corporate Restructuring & Charter Amendment',
        hours: 20.0,
        rate: 720,
        amount: 14400,
        utbmsCode: 'B110',
        date: '2026-08-28'
      },
      {
        id: 'li-4',
        description: 'Cap table modeling and regulatory disclosure schedules',
        hours: 15.2,
        rate: 500,
        amount: 7600,
        utbmsCode: 'B130',
        date: '2026-09-02'
      }
    ],
    expenses: [
      {
        id: 'exp-1',
        description: 'Delaware Secretary of State expedite filing fee',
        amount: 550,
        category: 'Filing Fees',
        date: '2026-09-03'
      }
    ],
    payments: [
      {
        id: 'pay-2',
        date: '2026-09-18',
        amount: 10000,
        method: 'Trust Transfer (IOLTA)',
        reference: 'IOLTA-XFER-9944'
      }
    ]
  },
  {
    id: 'inv-3',
    invoiceNumber: 'INV-2026-0091',
    matterId: 'mat-3',
    matterNumber: 'MAT-2026-0045',
    matterTitle: 'Kensington Dynasty Revocable Family Trust & Asset Protection',
    clientId: 'cli-103',
    clientName: 'Arthur & Eleanor Kensington',
    clientEmail: 'arthur@kensingtonholdings.org',
    clientAddress: '1200 Lake Shore Drive, Penthouse C, Chicago, IL 60611',
    issueDate: '2026-08-20',
    dueDate: '2026-09-20',
    subtotal: 9400,
    taxAmount: 0,
    discountAmount: 0,
    total: 9400,
    amountPaid: 0,
    trustApplied: 0,
    balanceDue: 9400,
    status: 'Overdue',
    notes: 'Final trust distribution fee statement. Client requested payment plan review.',
    lineItems: [
      {
        id: 'li-5',
        description: 'Draft generation-skipping trust provisions & deed transfers',
        hours: 16.0,
        rate: 587.5,
        amount: 9400,
        utbmsCode: 'E101',
        date: '2026-08-10'
      }
    ],
    expenses: [],
    payments: []
  }
];

export const INITIAL_TRUST_TRANSACTIONS: TrustTransaction[] = [
  {
    id: 'tr-1',
    transactionNumber: 'TR-2026-0041',
    date: '2026-08-01',
    matterId: 'mat-1',
    matterNumber: 'MAT-2026-0082',
    clientName: 'Acme Technologies Inc.',
    type: 'Deposit',
    amount: 57350,
    paymentMethod: 'Wire',
    referenceNumber: 'WIRE-US-991204',
    explanationPurpose: 'Initial litigation retainer deposit into IOLTA trust escrow',
    authorizedBy: 'Victoria Vance, Esq.',
    runningBalance: 57350,
    status: 'Cleared'
  },
  {
    id: 'tr-2',
    transactionNumber: 'TR-2026-0052',
    date: '2026-09-05',
    matterId: 'mat-1',
    matterNumber: 'MAT-2026-0082',
    clientName: 'Acme Technologies Inc.',
    type: 'Disbursement',
    amount: 14850,
    paymentMethod: 'Trust Transfer',
    referenceNumber: 'IOLTA-XFER-9921',
    explanationPurpose: 'Earned attorney fee transfer to operating account for Invoice INV-2026-0078',
    authorizedBy: 'Victoria Vance, Esq.',
    runningBalance: 42500,
    invoiceId: 'inv-1',
    status: 'Cleared'
  },
  {
    id: 'tr-3',
    transactionNumber: 'TR-2026-0060',
    date: '2026-08-15',
    matterId: 'mat-2',
    matterNumber: 'MAT-2026-0104',
    clientName: 'Horizon Financial Group',
    type: 'Deposit',
    amount: 28000,
    paymentMethod: 'Wire',
    referenceNumber: 'WIRE-NY-841103',
    explanationPurpose: 'Series B M&A legal advisory retainer deposit',
    authorizedBy: 'Julian Davenport, Esq.',
    runningBalance: 28000,
    status: 'Cleared'
  },
  {
    id: 'tr-4',
    transactionNumber: 'TR-2026-0071',
    date: '2026-09-18',
    matterId: 'mat-2',
    matterNumber: 'MAT-2026-0104',
    clientName: 'Horizon Financial Group',
    type: 'Disbursement',
    amount: 10000,
    paymentMethod: 'Trust Transfer',
    referenceNumber: 'IOLTA-XFER-9944',
    explanationPurpose: 'Earned fee disbursement to operating for partial payment on Invoice INV-2026-0089',
    authorizedBy: 'Julian Davenport, Esq.',
    runningBalance: 18000,
    invoiceId: 'inv-2',
    status: 'Cleared'
  },
  {
    id: 'tr-5',
    transactionNumber: 'TR-2026-0079',
    date: '2026-08-25',
    matterId: 'mat-4',
    matterNumber: 'MAT-2026-0118',
    clientName: 'Sterling Therapeutics SA',
    type: 'Deposit',
    amount: 31200,
    paymentMethod: 'Wire',
    referenceNumber: 'SWIFT-CH-002914',
    explanationPurpose: 'CRISPR patent defense and USPTO prosecution retainer',
    authorizedBy: 'Victoria Vance, Esq.',
    runningBalance: 31200,
    status: 'Cleared'
  },
  {
    id: 'tr-6',
    transactionNumber: 'TR-2026-0084',
    date: '2026-09-02',
    matterId: 'mat-5',
    matterNumber: 'MAT-2026-0130',
    clientName: 'Pacific Horizon Real Estate Partners',
    type: 'Deposit',
    amount: 12000,
    paymentMethod: 'ACH',
    referenceNumber: 'ACH-SEA-7729',
    explanationPurpose: 'Commercial lease negotiation retainer escrow',
    authorizedBy: 'Julian Davenport, Esq.',
    runningBalance: 12000,
    status: 'Cleared'
  },
  {
    id: 'tr-7',
    transactionNumber: 'TR-2026-0088',
    date: '2026-09-12',
    matterId: 'mat-3',
    matterNumber: 'MAT-2026-0045',
    clientName: 'Arthur & Eleanor Kensington',
    type: 'Deposit',
    amount: 8500,
    paymentMethod: 'Check',
    referenceNumber: 'CHK-4819',
    explanationPurpose: 'Probate recording and title transfer retainer deposit',
    authorizedBy: 'Julian Davenport, Esq.',
    runningBalance: 8500,
    status: 'Cleared'
  },
  {
    id: 'tr-8',
    transactionNumber: 'TR-2026-0095',
    date: '2026-09-22',
    matterId: 'mat-6',
    matterNumber: 'MAT-2026-0142',
    clientName: 'Dr. Raymond Garcia',
    type: 'Deposit',
    amount: 15000,
    paymentMethod: 'Wire',
    referenceNumber: 'WIRE-SF-66291',
    explanationPurpose: 'Intake retainer for executive trade secret dispute representation',
    authorizedBy: 'Victoria Vance, Esq.',
    runningBalance: 15000,
    status: 'Cleared'
  }
];

// Sum of current balances: 42500 + 18000 + 8500 + 31200 + 12000 + 15000 = 127,200.00
export const INITIAL_RECONCILIATION: ReconciliationRecord = {
  id: 'recon-2026-09',
  reconciliationDate: '2026-09-28',
  bankStatementEndingBalance: 127200.00,
  generalTrustBookBalance: 127200.00,
  clientLedgersSum: 127200.00,
  variance: 0.00, // Exact 3-way match!
  unclearedDeposits: 0.00,
  outstandingDisbursements: 0.00,
  adjustedBankBalance: 127200.00,
  status: 'Balanced',
  reviewedBy: 'Julian Davenport, Esq. (Managing Partner)',
  notes: 'September 2026 3-way IOLTA reconciliation completed with First Republic / JPMorgan Chase Escrow Statement #8812. Zero variance detected across all 6 client sub-accounts.'
};

export const DOCUMENT_TEMPLATES: DocumentTemplate[] = [
  {
    id: 'tmpl-1',
    title: 'Attorney-Client Fee Agreement & Retainer Terms',
    category: 'Engagement & Fee',
    description: 'State Bar compliant legal engagement agreement with IOLTA trust escrow terms, hourly billing rates, and dispute resolution.',
    variables: [
      { key: 'client_name', label: 'Client Name', defaultValue: 'Acme Technologies Inc.', type: 'text' },
      { key: 'matter_title', label: 'Matter Description', defaultValue: 'Commercial Litigation & IP Representation', type: 'text' },
      { key: 'lead_attorney', label: 'Lead Counsel', defaultValue: 'Victoria Vance, Esq.', type: 'text' },
      { key: 'hourly_rate', label: 'Standard Hourly Rate ($)', defaultValue: '675', type: 'currency' },
      { key: 'retainer_amount', label: 'Initial IOLTA Retainer ($)', defaultValue: '25,000', type: 'currency' },
      { key: 'governing_jurisdiction', label: 'Governing State/Jurisdiction', defaultValue: 'State of California', type: 'text' },
      { key: 'effective_date', label: 'Agreement Date', defaultValue: '2026-09-28', type: 'date' }
    ],
    clauses: [
      {
        id: 'cl-1',
        title: 'IOLTA Trust Accounting Compliance',
        category: 'Trust Terms',
        defaultIncluded: true,
        content: 'Retainer funds received hereunder shall be deposited directly into Firm’s designated Interest on Lawyers’ Trust Accounts (IOLTA) escrow account. Funds shall remain the property of Client until earned through the rendition of legal services documented on itemized billing statements. Withdrawals from the IOLTA account shall occur only following delivery of an itemized invoice, with written audit notice provided to Client.'
      },
      {
        id: 'cl-2',
        title: 'Mandatory Fee Arbitration & Conflict Waiver',
        category: 'Dispute Resolution',
        defaultIncluded: true,
        content: 'In the event of any fee dispute arising under this Agreement, the parties agree to submit the dispute to binding fee arbitration conducted by the State Bar Mandatory Fee Arbitration Program pursuant to applicable business and professions codes.'
      },
      {
        id: 'cl-3',
        title: 'Statute of Limitations & Electronic Communications',
        category: 'Operational',
        defaultIncluded: false,
        content: 'Client acknowledges that all official communications and notices regarding court deadlines, discovery cutoffs, and statutes of limitations may be transmitted via encrypted client portal or secure electronic transmission.'
      }
    ],
    bodyContent: `# LEGAL SERVICES ENGAGEMENT & RETAINER AGREEMENT

**DATE OF EXECUTION:** {{effective_date}}  
**GOVERNING JURISDICTION:** {{governing_jurisdiction}}  

**PARTIES:**  
- **COUNSEL:** CounselFlow Legal Partners LLP, by and through {{lead_attorney}}  
- **CLIENT:** {{client_name}}  

---

### 1. SCOPE OF REPRESENTATION
Firm agrees to provide comprehensive legal representation to Client solely in connection with the following designated matter:
> **{{matter_title}}**

Any ancillary legal proceedings, appeals, or transactional restructuring outside the four corners of this scope shall require a separate written addendum.

### 2. HOURLY RATES & FEE ALLOCATION
Client agrees to compensate Firm for professional services at the following rate structure:
- **Lead Partner / Counsel ({{lead_attorney}}):** $\${{hourly_rate}} per billable hour
- **Associates:** \$450 per billable hour
- **Paralegals & Litigation Support:** \$220 per billable hour

All time entries are recorded in tenths of an hour (6-minute increments) using the Uniform Task-Based Management System (UTBMS).

### 3. INITIAL IOLTA RETAINER DEPOSIT
Simultaneously with the execution of this Agreement, Client shall deliver an initial advance retainer deposit in the amount of:
> **\${{retainer_amount}}**

### 4. SPECIAL CLAUSES & COMPLIANCE
{{selected_clauses}}

---

**IN WITNESS WHEREOF**, the parties have executed this Agreement as of the date first written above.

**COUNSEL:**  
____________________________  
{{lead_attorney}}  
Managing Counsel, CounselFlow LLP  

**CLIENT:**  
____________________________  
{{client_name}}  
Authorized Signatory  
`
  },
  {
    id: 'tmpl-2',
    title: 'Mutual Non-Disclosure & Confidentiality Agreement',
    category: 'Corporate',
    description: 'Bilateral trade secret protection agreement with strict IP ownership reservations and injunctive relief terms.',
    variables: [
      { key: 'party_a', label: 'Disclosing Party A', defaultValue: 'Horizon Financial Group', type: 'text' },
      { key: 'party_b', label: 'Receiving Party B', defaultValue: 'Vanguard Capital Partners', type: 'text' },
      { key: 'purpose_description', label: 'Evaluation Purpose', defaultValue: 'Evaluating potential Series B Preferred Equity Investment', type: 'text' },
      { key: 'term_years', label: 'Confidentiality Duration (Years)', defaultValue: '3', type: 'text' },
      { key: 'governing_law', label: 'Governing Jurisdiction', defaultValue: 'State of Delaware', type: 'text' },
      { key: 'effective_date', label: 'Effective Date', defaultValue: '2026-09-28', type: 'date' }
    ],
    clauses: [
      {
        id: 'cl-4',
        title: 'Non-Solicitation of Key Personnel',
        category: 'Protective Terms',
        defaultIncluded: true,
        content: 'For a period of twenty-four (24) months from the Effective Date, neither party shall, directly or indirectly, solicit, entice, or induce any executive, engineer, or research personnel of the other party to terminate employment.'
      },
      {
        id: 'cl-5',
        title: 'Defend Trade Secrets Act (DTSA) Notice of Immunity',
        category: 'Statutory Notice',
        defaultIncluded: true,
        content: 'Pursuant to 18 U.S.C. § 1833(b), an individual shall not be held criminally or civilly liable under any federal or state trade secret law for the disclosure of a trade secret that is made in confidence to a government official or attorney solely for reporting or investigating a suspected violation of law.'
      },
      {
        id: 'cl-6',
        title: 'Specific Performance & Equitable Relief',
        category: 'Remedies',
        defaultIncluded: true,
        content: 'The parties acknowledge that unauthorized disclosure or use of Confidential Information will cause irreparable injury for which monetary damages alone would be inadequate. Accordingly, the disclosing party shall be entitled to seek temporary and permanent injunctive relief without the necessity of posting bond.'
      }
    ],
    bodyContent: `# MUTUAL NON-DISCLOSURE AGREEMENT

This Mutual Non-Disclosure Agreement ("Agreement") is made effective as of **{{effective_date}}**, by and between:

- **{{party_a}}**, a corporation organized under the laws of {{governing_law}} ("First Party"), and  
- **{{party_b}}**, an entity organized under the laws of {{governing_law}} ("Second Party").

---

### 1. PURPOSE
The parties desire to explore and evaluate a prospective commercial transaction involving:
> **{{purpose_description}}** (the "Purpose").

In connection with this Purpose, each party may disclose to the other proprietary, technical, and commercial information.

### 2. CONFIDENTIAL INFORMATION DEFINED
"Confidential Information" encompasses all non-public information, trade secrets, algorithms, financial statements, and business projections disclosed in tangible, oral, or electronic form.

### 3. OBLIGATION OF CONFIDENTIALITY
Each Receiving Party agrees to protect the Confidential Information using the same degree of care it uses for its own sensitive assets, but no less than a reasonable degree of care. The confidentiality obligations herein shall endure for a period of **{{term_years}} years** from the Effective Date.

### 4. SPECIAL CLAUSES & COVENANTS
{{selected_clauses}}

### 5. GOVERNING LAW & VENUE
This Agreement shall be governed by and construed in accordance with the substantive laws of the **{{governing_law}}**, without giving effect to conflicts of law principles.

---

**{{party_a}}**  
By: _______________________________  
Name: Authorized Officer  

**{{party_b}}**  
By: _______________________________  
Name: Authorized Officer  
`
  },
  {
    id: 'tmpl-3',
    title: 'Formal Litigation Demand & Cease-and-Desist Notice',
    category: 'Litigation',
    description: 'Pre-suit demand letter asserting statutory violations, evidentiary litigation hold notice, and settlement conference demand.',
    variables: [
      { key: 'opposing_party', label: 'Adverse Entity / Defendant', defaultValue: 'Apex Dynamics Inc.', type: 'text' },
      { key: 'client_name', label: 'Represented Claimant', defaultValue: 'Acme Technologies Inc.', type: 'text' },
      { key: 'cause_of_action', label: 'Primary Cause of Action', defaultValue: 'Misappropriation of Trade Secrets and Breach of Covenant', type: 'text' },
      { key: 'demand_amount', label: 'Monetary Demand ($)', defaultValue: '1,750,000', type: 'currency' },
      { key: 'cure_deadline_days', label: 'Cure / Response Window (Days)', defaultValue: '10', type: 'text' },
      { key: 'lead_attorney', label: 'Signing Attorney', defaultValue: 'Victoria Vance, Esq.', type: 'text' },
      { key: 'effective_date', label: 'Notice Date', defaultValue: '2026-09-28', type: 'date' }
    ],
    clauses: [
      {
        id: 'cl-7',
        title: 'Formal Litigation Hold Notice (Spoliation Warning)',
        category: 'Evidence Preservation',
        defaultIncluded: true,
        content: 'DEMAND FOR EVIDENCE PRESERVATION: You are hereby placed on formal notice of anticipated litigation. You must immediately suspend all automatic document destruction routines, email purges, slack channel expirations, and cloud backup overwrite protocols. Spoliation of evidence will be met with motions for adverse inference sanctions under Federal Rule of Civil Procedure 37(e).'
      },
      {
        id: 'cl-8',
        title: 'Settlement Privilege (FRE 408 Protection)',
        category: 'Confidentiality',
        defaultIncluded: true,
        content: 'This communication constitutes a confidential settlement offer governed strictly by Rule 408 of the Federal Rules of Evidence and state counterparts, and is inadmissible in any proceeding for the purpose of establishing liability or damages.'
      }
    ],
    bodyContent: `# FORMAL LEGAL DEMAND & NOTICE OF PENDING LITIGATION

**DATE:** {{effective_date}}  
**VIA CERTIFIED ELECTRONIC TRANSMISSION & PRIORITY LEGAL COURIER**  

**TO:**  
General Counsel & Board of Directors  
{{opposing_party}}  

**RE:** Formal Pre-Litigation Demand on Behalf of **{{client_name}}**  
**CLAIMS:** {{cause_of_action}}  

---

Dear Counsel:

This firm represents **{{client_name}}** in connection with the unlawful conduct and intentional torts committed by **{{opposing_party}}**.

### I. FACTUAL SUMMARY & LEGAL BASES
As your corporate officers are fully aware, our client has uncovered conclusive forensic proof establishing that {{opposing_party}} engaged in {{cause_of_action}}. Such actions constitute actionable violations causing our client immediate, catastrophic, and continuing irreparable commercial harm.

### II. MONETARY & INJUNCTIVE DEMANDS
To avoid the imminent filing of a formal complaint in federal district court seeking treble damages, attorneys' fees, and preliminary injunctive relief, {{opposing_party}} must:

1. Tender restitution in the liquidated amount of **\${{demand_amount}}** to our firm's client trust account;
2. Cease and desist immediately from any further commercial exploitation of our client's proprietary assets;
3. Respond in writing within **{{cure_deadline_days}} calendar days** of the date hereof.

### III. STATUTORY NOTICES & EVIDENCE PRESERVATION
{{selected_clauses}}

In the event we do not receive substantive confirmation of compliance by the stated deadline, we are instructed to file our verified complaint without further notice.

Respectfully submitted,

**COUNSELFLOW LEGAL PARTNERS LLP**  
_____________________________________  
{{lead_attorney}}, Lead Litigation Counsel  
`
  }
];

export const INITIAL_GENERATED_DOCS: GeneratedDocument[] = [
  {
    id: 'gdoc-1',
    templateId: 'tmpl-1',
    templateTitle: 'Attorney-Client Fee Agreement & Retainer Terms',
    matterId: 'mat-1',
    matterNumber: 'MAT-2026-0082',
    matterTitle: 'Acme Corp v. Apex Dynamics Inc.',
    clientName: 'Acme Technologies Inc.',
    title: 'Acme Technologies - Executed Retainer & Scope Agreement',
    createdDate: '2025-11-14',
    lastModified: '2026-09-10',
    status: 'Executed',
    content: `# LEGAL SERVICES ENGAGEMENT & RETAINER AGREEMENT\n\n**DATE OF EXECUTION:** 2025-11-14\n**GOVERNING JURISDICTION:** State of California\n\n**PARTIES:**\n- **COUNSEL:** CounselFlow Legal Partners LLP, by Victoria Vance, Esq.\n- **CLIENT:** Acme Technologies Inc.\n\n### 1. SCOPE OF REPRESENTATION\nCommercial litigation defense against Apex Dynamics Inc. in Northern District of California (3:25-cv-09142-WHA).\n\n### 2. HOURLY RATES & FEE ALLOCATION\n- Lead Partner: $675/hr\n- Associates: $450/hr\n- Initial Retainer: $57,350.00 in IOLTA Escrow.`
  },
  {
    id: 'gdoc-2',
    templateId: 'tmpl-2',
    templateTitle: 'Mutual Non-Disclosure & Confidentiality Agreement',
    matterId: 'mat-2',
    matterNumber: 'MAT-2026-0104',
    matterTitle: 'Horizon FinTech Series B Preferred Financing',
    clientName: 'Horizon Financial Group',
    title: 'Horizon FinTech / Vanguard Capital Mutual NDA',
    createdDate: '2026-01-12',
    lastModified: '2026-08-14',
    status: 'Finalized',
    content: `# MUTUAL NON-DISCLOSURE AGREEMENT\n\nEffective as of 2026-01-12 between Horizon Financial Group and Vanguard Capital Partners for Series B Preferred Financing.`
  }
];
