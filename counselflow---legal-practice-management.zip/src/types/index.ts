export type PracticeArea = 
  | 'Corporate & M&A'
  | 'Commercial Litigation'
  | 'Intellectual Property'
  | 'Employment & Labor'
  | 'Estate & Trusts'
  | 'Real Estate';

export type MatterStatus = 
  | 'Intake'
  | 'Active'
  | 'Discovery'
  | 'Pre-Trial'
  | 'Settlement / Closing'
  | 'Closed';

export type BillingModel = 
  | 'Hourly'
  | 'Fixed Fee'
  | 'Contingency'
  | 'Retainer';

export interface MatterNote {
  id: string;
  date: string;
  author: string;
  text: string;
  category: 'General' | 'Court Filing' | 'Client Call' | 'Settlement Negotiation';
}

export interface MatterTask {
  id: string;
  title: string;
  dueDate: string;
  assignedTo: string;
  completed: boolean;
  priority: 'High' | 'Medium' | 'Low';
  isCourtDeadline?: boolean;
}

export interface Matter {
  id: string;
  matterNumber: string; // e.g. "MAT-2026-081"
  title: string;
  clientId: string;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  practiceArea: PracticeArea;
  status: MatterStatus;
  billingModel: BillingModel;
  defaultRate: number; // USD per hour
  leadAttorney: string;
  responsibleStaff: string[];
  opposingParty?: string;
  opposingCounsel?: string;
  courtOrJurisdiction?: string;
  docketNumber?: string;
  openDate: string;
  statuteOfLimitationsDate?: string; // YYYY-MM-DD
  trustBalance: number; // Retainer funds in IOLTA for this matter
  operatingRetainerBalance?: number;
  notes: MatterNote[];
  tasks: MatterTask[];
}

export interface UTBMSCode {
  code: string;
  category: 'Litigation' | 'Bankruptcy' | 'Advisory' | 'General';
  description: string;
}

export interface TimeEntry {
  id: string;
  matterId: string;
  matterNumber: string;
  matterTitle: string;
  clientName: string;
  date: string; // YYYY-MM-DD
  durationHours: number; // e.g. 1.3
  rate: number;
  billable: boolean;
  utbmsCode: string; // e.g. "L110 - Fact Investigation"
  description: string;
  attorneyName: string;
  status: 'Unbilled' | 'Invoiced' | 'Written Off';
  invoiceId?: string;
}

export interface InvoiceLineItem {
  id: string;
  description: string;
  hours: number;
  rate: number;
  amount: number;
  utbmsCode?: string;
  date: string;
}

export interface InvoiceExpense {
  id: string;
  description: string;
  amount: number;
  category: string;
  date: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string; // e.g. "INV-2026-0042"
  matterId: string;
  matterNumber: string;
  matterTitle: string;
  clientId: string;
  clientName: string;
  clientEmail: string;
  clientAddress: string;
  issueDate: string;
  dueDate: string;
  lineItems: InvoiceLineItem[];
  expenses: InvoiceExpense[];
  subtotal: number;
  taxAmount: number;
  discountAmount: number;
  total: number;
  amountPaid: number;
  trustApplied: number;
  balanceDue: number;
  status: 'Draft' | 'Sent' | 'Paid' | 'Overdue' | 'Void';
  notes?: string;
  payments: {
    id: string;
    date: string;
    amount: number;
    method: 'Trust Transfer (IOLTA)' | 'Wire Transfer' | 'ACH' | 'Client Check' | 'Credit Card';
    reference: string;
  }[];
}

export interface TrustTransaction {
  id: string;
  transactionNumber: string; // e.g. "TR-2026-104"
  date: string;
  matterId: string;
  matterNumber: string;
  clientName: string;
  type: 'Deposit' | 'Disbursement';
  amount: number;
  paymentMethod: 'Wire' | 'Check' | 'ACH' | 'Trust Transfer';
  referenceNumber: string;
  explanationPurpose: string;
  authorizedBy: string;
  runningBalance: number;
  invoiceId?: string;
  status: 'Cleared' | 'Pending';
}

export interface ReconciliationRecord {
  id: string;
  reconciliationDate: string;
  bankStatementEndingBalance: number;
  generalTrustBookBalance: number;
  clientLedgersSum: number;
  variance: number; // bankStatement - clientLedgersSum (must be 0.00)
  unclearedDeposits: number;
  outstandingDisbursements: number;
  adjustedBankBalance: number;
  status: 'Balanced' | 'Discrepancy';
  reviewedBy: string;
  notes: string;
}

export interface DocumentVariable {
  key: string;
  label: string;
  defaultValue: string;
  type: 'text' | 'date' | 'currency' | 'select';
  options?: string[];
}

export interface DocumentClause {
  id: string;
  title: string;
  content: string;
  defaultIncluded: boolean;
  category: string;
}

export interface DocumentTemplate {
  id: string;
  title: string;
  category: 'Engagement & Fee' | 'Corporate' | 'Litigation' | 'Settlement & Release' | 'Estate';
  description: string;
  variables: DocumentVariable[];
  clauses: DocumentClause[];
  bodyContent: string; // Markdown / styled legal text with {{variable}} placeholders
}

export interface GeneratedDocument {
  id: string;
  templateId: string;
  templateTitle: string;
  matterId: string;
  matterNumber?: string;
  matterTitle: string;
  clientName: string;
  title: string;
  createdDate: string;
  lastModified: string;
  content: string;
  status: 'Draft' | 'Under Review' | 'Finalized' | 'Executed';
}

export interface ConflictResult {
  matchFound: boolean;
  query: string;
  hits: {
    type: 'Client' | 'Matter Opposing Party' | 'Opposing Counsel' | 'Related Entity' | 'Active Matter';
    name: string;
    matterNumber: string;
    matterTitle: string;
    status: MatterStatus;
    leadAttorney: string;
    severity: 'High Conflict' | 'Potential Adversary' | 'Existing Representation';
    notes: string;
  }[];
}
