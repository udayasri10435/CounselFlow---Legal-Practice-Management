import { Invoice } from '../types';

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(amount);
};

export const formatDate = (dateStr: string): string => {
  if (!dateStr) return '';
  const date = new Date(dateStr + 'T00:00:00');
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  }).format(date);
};

export const formatDuration = (seconds: number): string => {
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
};

/**
 * Generates official LEDES 1998B electronic legal billing data format.
 * LEDES 1998B is pipe-delimited (|) standard mandated by Fortune 500 corporate clients
 * and insurance defense carriers.
 */
export const generateLedes1998B = (invoice: Invoice): string => {
  const header = `INVOICE_DATE|INVOICE_NUMBER|CLIENT_ID|LAW_FIRM_MATTER_ID|INVOICE_TOTAL|LINE_ITEM_NUMBER|EXP/FEE/CHG_CODE|LINE_ITEM_NUMBER_OF_UNITS|LINE_ITEM_UNIT_COST|LINE_ITEM_TOTAL|LINE_ITEM_DATE|LINE_ITEM_TASK_CODE|LINE_ITEM_ACTIVITY_CODE|LINE_ITEM_DESCRIPTION|LAW_FIRM_ID|LINE_ITEM_ADJUSTMENT_AMOUNT|CLIENT_MATTER_ID`;

  const dateCompact = invoice.issueDate.replace(/-/g, '');

  const feeLines = invoice.lineItems.map((item, idx) => {
    const itemDate = (item.date || invoice.issueDate).replace(/-/g, '');
    const taskCode = item.utbmsCode || 'L110';
    return `${dateCompact}|${invoice.invoiceNumber}|${invoice.clientId}|${invoice.matterNumber}|${invoice.total.toFixed(2)}|${idx + 1}|F|${item.hours.toFixed(2)}|${item.rate.toFixed(2)}|${item.amount.toFixed(2)}|${itemDate}|${taskCode}|A100|${item.description.replace(/\|/g, '-')}|LAW-FIRM-9941|0.00|${invoice.matterNumber}`;
  });

  const expLines = invoice.expenses.map((exp, idx) => {
    const expDate = (exp.date || invoice.issueDate).replace(/-/g, '');
    return `${dateCompact}|${invoice.invoiceNumber}|${invoice.clientId}|${invoice.matterNumber}|${invoice.total.toFixed(2)}|${invoice.lineItems.length + idx + 1}|E|1.00|${exp.amount.toFixed(2)}|${exp.amount.toFixed(2)}|${expDate}|E100||${exp.description.replace(/\|/g, '-')}|LAW-FIRM-9941|0.00|${invoice.matterNumber}`;
  });

  return [header, ...feeLines, ...expLines].join('\n');
};
